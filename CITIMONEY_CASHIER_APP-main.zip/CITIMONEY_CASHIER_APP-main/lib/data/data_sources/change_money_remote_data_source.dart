import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:change_money_cashier_app/data/core/api_client.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/change_pin_request_dto.dart';
import 'package:change_money_cashier_app/data/models/change_pin_result_model.dart';
import 'package:change_money_cashier_app/data/models/check_customer_result_model.dart';
import 'package:change_money_cashier_app/data/models/check_teller_result_model.dart';
import 'package:change_money_cashier_app/data/models/login_request_dto.dart';
import 'package:change_money_cashier_app/data/models/login_result_model.dart';
import 'package:change_money_cashier_app/data/models/recent_transactions_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashin_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/reset_pin_result_model.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashin_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_issue_change_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_withdrawal_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/transaction_paged_response.dart';
import 'package:change_money_cashier_app/data/models/transaction_model.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:dartz/dartz.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:sms_autofill/sms_autofill.dart';
import '../models/requests/change_password_request_dto.dart';
import '../models/requests/instant_change_password_request_dto.dart';
import '../models/requests/update_notifications_read_status_request.dart';
import '../models/requests/update_profile_request.dart';
import '../models/responses/chat_message_paged_response.dart';
import '../models/responses/notification_paged_response.dart';
import '../models/signup_request.dart';

abstract class ChangeMoneyRemoteDataSource {
  Future<Either<AppError, NoResponse>> updateSingleNotificationReadStatus(
      int notificationId);
  Future<Either<AppError, ChatMessagePagedResponse>> getAllChatMessages(
      int pageNumber);
  Future<Either<AppError, NotificationPagedResponse>> getAllNotifications(
      int pageNumber);
  Future<Either<AppError, NoResponse>> updateReadStatus(
      UpdateNotificationsReadStatusRequest request);

  Future<Either<AppError, LoginResultModel>> login(LoginRequestDTO request);
  Future<Either<AppError, LoginResultModel>> changePassword(
      ChangePasswordRequestDTO request);
  Future<Either<AppError, LoginResultModel>> instantChangePassword(
      InstantChangePasswordRequestDTO request);
  Future<Either<AppError, NoResponse>> resetPassword(String phonenumber);
  Future<Either<AppError, NoResponse>> resendOtp(String phonenumber);
  Future<Either<AppError, LoginResultModel>> verifyOtp(String otp);
  Future<Either<AppError, LoginResultModel>> resetPasswordVerifyOtp(String otp);
  Future<Either<AppError, NoResponse>> signup(SignupRequestDTO phonenumber);

  Future<Either<AppError, NoResponse>> updateProfile(
      UpdateProfileRequestDTO request);
  Future<Either<AppError, LoginResultModel>> fetchProfile();
  Future<Either<AppError, List<CurrencyResponse>>> getCurrencies();
  Future<Either<AppError, List<TransactionModel>>> getRecentTrasactions();
  Future<Either<AppError, List<TransactionModel>>>
      getTellerRecentTransactions();
  Future<Either<AppError, CheckCashierResultModel>> checkCashier();
  Future<Either<AppError, CheckTellerResultModel>> checkTeller();
  Future<Either<AppError, CheckCashoutResponse>> checkCashout(
      CheckCashoutRequestDTO request);
  Future<Either<AppError, CheckIssueChangeResponse>> checkIssueChange(
      CheckIssueChangeRequestDTO request);
  Future<Either<AppError, CheckCashinResponse>> checkCashin(
      CheckCashinRequestDTO request);
  Future<Either<AppError, CheckWithdrawalResponse>> checkWithdrawal(
      CheckWithdrawalRequestDTO request);
  Future<Either<AppError, CheckWithdrawalResponse>> confirmWithdrawal(
      ConfirmWithdrawalRequestDTO request);
  Future<Either<AppError, ConfirmCashoutResponse>> confirmCashout(
      ConfirmCashoutRequestDTO request);
  Future<Either<AppError, CheckIssueChangeResponse>> confirmIssueChange(
      ConfirmIssueChangeRequestDTO request);
  Future<Either<AppError, CheckCashinResponse>> confirmCashin(
      ConfirmCashinRequestDTO request);

  Future<Either<AppError, TransactionPagedResponse>> getCashins(int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getWithdrawals(
      int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getCashouts(
      int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getPayments(
      int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getIssueChanges(
      int pageNumber);
}

class ChangeMoneyRemoteDataSourceImpl extends ChangeMoneyRemoteDataSource {
  final ApiClient _client;
  ChangeMoneyRemoteDataSourceImpl(this._client);

  @override
  Future<Either<AppError, LoginResultModel>> changePassword(
      ChangePasswordRequestDTO request) async {
    final response = await _client.post(
      path: '/auth/passwords/change',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = LoginResultModel.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, LoginResultModel>> login(
      LoginRequestDTO request) async {
    final response = await _client.post(
      path: '/auth/login',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = LoginResultModel.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, NoResponse>> resendOtp(String phonenumber) async {
    String appSignature = await SmsAutoFill().getAppSignature;
    final response = await _client.post(
        path: '/auth/client/resendOtp',
        body: {'mobileNumber': phonenumber, 'appSignature': appSignature});
    if (response is AppError) {
      return Left(response);
    } else {
      final result = NoResponse.fromJson(response);
      return Right(result);
    }
  }

  @override
  Future<Either<AppError, NoResponse>> resetPassword(String phonenumber) async {
    String appSignature = await SmsAutoFill().getAppSignature;
    final response = await _client.post(
        path: '/auth/client/resetPassword',
        body: {'mobileNumber': phonenumber, 'appSignature': appSignature});
    if (response is AppError) {
      return Left(response);
    } else {
      final result = NoResponse.fromJson(response);
      return Right(result);
    }
  }

  @override
  Future<Either<AppError, NoResponse>> signup(SignupRequestDTO request) async {
    final response = await _client.post(
      path: '/auth/customer/signUp',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      return Right(NoResponse.fromJson(response));
    }
  }

  @override
  Future<Either<AppError, LoginResultModel>> verifyOtp(String otp) async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String mobileNumber = await sharedPreferencesUtil.getMobileNumber();

    final response = await _client
        .get('/auth/backend/registrationConfirmOtp/$mobileNumber/$otp');
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = LoginResultModel.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, LoginResultModel>> resetPasswordVerifyOtp(
      String otp) async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String mobileNumber = await sharedPreferencesUtil.getMobileNumber();

    // return Left(
    //   AppError(
    //     appErrorType: AppErrorType.other,
    //     message: 'Break Point',
    //     status: 201,
    //   ),
    // );
    final response = await _client
        .get('/auth/backend/resetPasswordConfirmOtp/$mobileNumber/$otp');
    if (response is AppError) {
      return Left(response);
    } else {
      inspect(response);
      final loginResult = LoginResultModel.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, LoginResultModel>> instantChangePassword(
      InstantChangePasswordRequestDTO request) async {
    final response = await _client.post(
      path: '/auth/passwords/update',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = LoginResultModel.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, LoginResultModel>> fetchProfile() async {
    final response = await _client.get('/users/me');
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = LoginResultModel.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, NoResponse>> updateProfile(
      UpdateProfileRequestDTO request) async {
    final response = await _client.post(
      path: '/users/profile/client/update',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      return Right(NoResponse.fromJson(response));
    }
  }

  @override
  Future<Either<AppError, NotificationPagedResponse>> getAllNotifications(
      int pageNumber) async {
    final response =
        await _client.get('/notifications/view/me/?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = NotificationPagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, NoResponse>> updateReadStatus(
      UpdateNotificationsReadStatusRequest request) async {
    final response = await _client.post(
      path: '/notifications/markAsRead/multiple',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      return Right(NoResponse.fromJson(response));
    }
  }

  @override
  Future<Either<AppError, ChatMessagePagedResponse>> getAllChatMessages(
      int pageNumber) async {
    final response =
        await _client.get('/chatMessages/view/me?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = ChatMessagePagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, NoResponse>> updateSingleNotificationReadStatus(
      int notificationId) async {
    final response =
        await _client.get('/notifications/markAsRead/single/$notificationId');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = NoResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, CheckCashierResultModel>> checkCashier() async {
    final response = await _client.get('/transactions/check-cashier');
    if (response is AppError) {
      return Left(response);
    } else {
      final checkCashierResultModel =
          CheckCashierResultModel.fromJson(response);

      return Right(checkCashierResultModel);
    }
  }

  @override
  Future<Either<AppError, CheckTellerResultModel>> checkTeller() async {
    final response = await _client.get('/transactions/check-teller');
    if (response is AppError) {
      return Left(response);
    } else {
      final checkCashierResultModel = CheckTellerResultModel.fromJson(response);

      return Right(checkCashierResultModel);
    }
  }

  @override
  Future<Either<AppError, List<TransactionModel>>>
      getTellerRecentTransactions() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String username = await sharedPreferencesUtil.getUsername();

    final response = await _client.get('/transactions/tellerTransactions');

    if (response is AppError) {
      return Left(response);
    } else {
      List<TransactionModel> _foods = [];

      if (response != null) {
        var list = response as List;

        _foods = list.map((i) => TransactionModel.fromJson(i)).toList();
      }
      return Right(_foods);
    }
  }

  @override
  Future<Either<AppError, List<TransactionModel>>>
      getRecentTrasactions() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String username = await sharedPreferencesUtil.getUsername();

    final response = await _client.get('/transactions/cashierTransactions');

    if (response is AppError) {
      return Left(response);
    } else {
      List<TransactionModel> _foods = [];

      if (response != null) {
        var list = response as List;

        _foods = list.map((i) => TransactionModel.fromJson(i)).toList();
      }
      return Right(_foods);
    }
  }

  @override
  Future<Either<AppError, List<CurrencyResponse>>> getCurrencies() async {
    final response = await _client.get('/currencies/view/active');

    if (response is AppError) {
      return Left(response);
    } else {
      List<CurrencyResponse> _foods = [];

      if (response != null) {
        var list = response as List;

        _foods = list.map((i) => CurrencyResponse.fromJson(i)).toList();
      }
      return Right(_foods);
    }
  }

  @override
  Future<Either<AppError, CheckCashoutResponse>> checkCashout(
      CheckCashoutRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/checkCashoutRequest',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckCashoutResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, CheckCashinResponse>> checkCashin(
      CheckCashinRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/checkCashIn',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckCashinResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, CheckWithdrawalResponse>> checkWithdrawal(
      CheckWithdrawalRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/withdrawalRequests/checkWithdrawal',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckWithdrawalResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, CheckWithdrawalResponse>> confirmWithdrawal(
      ConfirmWithdrawalRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/withdrawalRequests/complete',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckWithdrawalResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, CheckIssueChangeResponse>> checkIssueChange(
      CheckIssueChangeRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/checkIssueChange',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckIssueChangeResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, ConfirmCashoutResponse>> confirmCashout(
      ConfirmCashoutRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/cashOut',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = ConfirmCashoutResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, CheckCashinResponse>> confirmCashin(
      ConfirmCashinRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/cashIn',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckCashinResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, CheckIssueChangeResponse>> confirmIssueChange(
      ConfirmIssueChangeRequestDTO request) async {
    final response = await _client.post(
      path: '/transactions/issueChange',
      body: request.toJson(),
    );
    if (response is AppError) {
      return Left(response);
    } else {
      final loginResult = CheckIssueChangeResponse.fromJson(response);
      return Right(loginResult);
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getPayments(
      int pageNumber) async {
    final response = await _client.get(
        '/transactions/cashier/view/me/payments/?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = TransactionPagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getIssueChanges(
      int pageNumber) async {
    final response = await _client.get(
        '/transactions/cashier/view/me/changeIssued/?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = TransactionPagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getCashouts(
      int pageNumber) async {
    final response = await _client.get(
        '/transactions/cashier/view/me/cashouts/?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = TransactionPagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getWithdrawals(
      int pageNumber) async {
    final response = await _client.get(
        '/transactions/teller/view/me/withdrawals/?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = TransactionPagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getCashins(
      int pageNumber) async {
    final response = await _client.get(
        '/transactions/cashier/view/me/cashins/?page=$pageNumber&size=100');
    if (response is AppError) {
      return Left(response);
    } else {
      final orderResult = TransactionPagedResponse.fromJson(response);
      return Right(orderResult);
    }
  }
}
