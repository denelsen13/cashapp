import 'dart:convert';
import 'dart:ffi';

import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferenceUtil {
  String _totalWithdrawalIssued = '_total_withdrawal_issued';
  String _totalChangeIssued = '_total_change_issued';
  String _accessToken = 'access_token';
  String _currentBalance = 'current_balance';
  String _refreshToken = 'refresh_token';
  String _firstName = 'first_name';
  String _lastName = 'last_name';
  String _username = 'username';
  String _email = 'email';
  String _currencies = 'currencies';
  String _merchantId = 'merchant_id';
  String _mobileNumber = 'mobile_number';
  String _mobileNumberCountryCode = 'mobile_number_country_code';
  String _resetPin = 'should_reset_pin';
  String _role = 'role';
  String _verified = 'is_verified';
  String _enabled = 'is_enabled';
  String _userId = 'user_id';
  final SharedPreferences _pref;

  SharedPreferenceUtil(this._pref);

  Future<bool> clearStorage() async {
    return _pref.clear();
  }

  Future<double> getCurrentBalance() async {
    return _pref.getDouble(_currentBalance) ?? 0;
  }

  Future<double> getTotalChangeIssued() async {
    return _pref.getDouble(_totalChangeIssued) ?? 0;
  }

  Future<double> getTotalWithdrawalIssued() async {
    return _pref.getDouble(_totalWithdrawalIssued) ?? 0;
  }

  Future<String> getAccessToken() async {
    return _pref.getString(_accessToken) ?? '';
  }

  Future<String> getRefreshToken() async {
    return _pref.getString(_refreshToken) ?? '';
  }

  Future<String> getFirstName() async {
    return _pref.getString(_firstName) ?? '';
  }

  Future<String> getLastName() async {
    return _pref.getString(_lastName) ?? '';
  }

  Future<bool> getVerified() async {
    return _pref.getBool(_verified) ?? false;
  }

  Future<String> getRole() async {
    return _pref.getString(_role) ?? '';
  }

  Future<String> getUsername() async {
    return _pref.getString(_username) ?? '';
  }

  Future<String> getMobileNumberCountryCode() async {
    return _pref.getString(_mobileNumberCountryCode) ?? '';
  }

  Future<String> getEmail() async {
    return _pref.getString(_email) ?? '';
  }

  Future<String> getMobileNumber() async {
    return _pref.getString(_mobileNumber) ?? '';
  }

  Future<void> setEmail(String email) async {
    await _pref.setString(_email, email);
  }

  Future<bool> getEnabled() async {
    return _pref.getBool(_enabled) ?? false;
  }

  Future<bool> getResetPin() async {
    return _pref.getBool(_resetPin) ?? false;
  }

  Future<String> getUserId() async {
    return _pref.getString(_userId) ?? '';
  }

  Future<String> getMerchantId() async {
    return _pref.getString(_merchantId) ?? '';
  }

  Future<void> setAccessToken(String token) async {
    await _pref.setString(_accessToken, token);
  }

  Future<void> setUserId(String userId) async {
    await _pref.setString(_userId, userId);
  }

  Future<void> setVerified(bool isVerified) async {
    await _pref.setBool(_verified, isVerified);
  }

  Future<void> setCurrentBalance(double balance) async {
    await _pref.setDouble(_currentBalance, balance);
  }

  Future<void> setRefreshToken(String token) async {
    await _pref.setString(_refreshToken, token);
  }

  Future<void> setResetPin(bool resetPin) async {
    await _pref.setBool(_resetPin, resetPin);
  }

  Future<void> setEnabled(bool enabled) async {
    await _pref.setBool(_enabled, enabled);
  }

  Future<void> setMobileNumberCountryCode(
      String mobileNumberCountryCode) async {
    await _pref.setString(_mobileNumberCountryCode, mobileNumberCountryCode);
  }

  Future<void> setMobileNumber(String mobileNumber) async {
    await _pref.setString(_mobileNumber, mobileNumber);
  }

  Future<void> setRole(String role) async {
    await _pref.setString(_role, role);
  }

  Future<void> setTotalWithdrawalIssued(double totalWithdrawalIssued) async {
    await _pref.setDouble(_totalWithdrawalIssued, totalWithdrawalIssued);
  }

  Future<void> setTotalChangeIssued(double totalChangeIssued) async {
    await _pref.setDouble(_totalChangeIssued, totalChangeIssued);
  }

  Future<void> setFirstName(String firstName) async {
    await _pref.setString(_firstName, firstName);
  }

  Future<void> setUsername(String username) async {
    await _pref.setString(_username, username);
  }

  Future<void> setMerchantId(String merchantId) async {
    await _pref.setString(_merchantId, merchantId);
  }

  Future<void> setLastName(String lastName) async {
    await _pref.setString(_lastName, lastName);
  }
}
