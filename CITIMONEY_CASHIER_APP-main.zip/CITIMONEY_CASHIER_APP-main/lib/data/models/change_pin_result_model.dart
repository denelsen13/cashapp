class ChangePinResultModel {
  late AdditionalData additionalData;
  late bool success;
  late String narrative;
  late Dto dto;
  late String responseCode;

  ChangePinResultModel(
      {required this.additionalData,
      required this.success,
      required this.narrative,
      required this.dto,
      required this.responseCode});

  ChangePinResultModel.fromJson(Map<String, dynamic> json) {
    additionalData = json['additionalData'] != null
        ? new AdditionalData.fromJson(json['additionalData'])
        : AdditionalData.empty();
    success = json['success'];
    narrative = json['narrative'];
    dto = json['dto'] != null ? new Dto.fromJson(json['dto']) : Dto.empty();
    responseCode = json['responseCode'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.additionalData != null) {
      data['additionalData'] = this.additionalData.toJson();
    }
    data['success'] = this.success;
    data['narrative'] = this.narrative;
    if (this.dto != null) {
      data['dto'] = this.dto.toJson();
    }
    data['responseCode'] = this.responseCode;
    return data;
  }
}

class AdditionalData {
  late String confirmPin;
  late String oldPin;
  late String uSECASE;
  late String msisdn;
  late String newPin;
  AdditionalData.empty();
  AdditionalData(
      {required this.confirmPin,
      required this.oldPin,
      required this.uSECASE,
      this.msisdn = '',
      required this.newPin});

  AdditionalData.fromJson(Map<String, dynamic> json) {
    confirmPin = json['confirmPin'];
    oldPin = json['oldPin'];
    uSECASE = json['USE_CASE'];
    msisdn = json['msisdn'];
    newPin = json['newPin'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['confirmPin'] = this.confirmPin;
    data['oldPin'] = this.oldPin;
    data['USE_CASE'] = this.uSECASE;
    data['msisdn'] = this.msisdn;
    data['newPin'] = this.newPin;
    return data;
  }
}

class Dto {
  late String id;
  late String dateCreated;
  late String dateUpdated;
  late AdditionalData additionalData;
  late String msisdn;
  late String name;
  late bool active;
  late MerchantBranch merchantBranch;
  Dto.empty();
  Dto(
      {this.id = '',
      this.dateCreated = '',
      this.dateUpdated = '',
      required this.additionalData,
      this.msisdn = '',
      this.name = '',
      this.active = true,
      required this.merchantBranch});

  Dto.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreated = json['dateCreated'];
    dateUpdated = json['dateUpdated'];
    additionalData = json['additionalData'] != null
        ? new AdditionalData.fromJson(json['additionalData'])
        : AdditionalData.empty();
    msisdn = json['msisdn'];
    name = json['name'];
    active = json['active'];
    merchantBranch = json['merchantBranch'] != null
        ? new MerchantBranch.fromJson(json['merchantBranch'])
        : MerchantBranch.empty();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateCreated'] = this.dateCreated;
    data['dateUpdated'] = this.dateUpdated;
    if (this.additionalData != null) {
      data['additionalData'] = this.additionalData.toJson();
    }
    data['msisdn'] = this.msisdn;
    data['name'] = this.name;
    data['active'] = this.active;
    if (this.merchantBranch != null) {
      data['merchantBranch'] = this.merchantBranch.toJson();
    }
    return data;
  }
}

class MerchantBranch {
  late String id;
  late String dateCreated;
  late String dateUpdated;
  late String branchName;
  late String branchManagerName;
  late String branchEmail;
  late String contactNumber;
  late Merchant merchant = Merchant.empty();
  MerchantBranch.empty();
  MerchantBranch(
      {this.id = '',
      this.dateCreated = '',
      this.dateUpdated = '',
      this.branchName = '',
      this.branchManagerName = '',
      this.branchEmail = '',
      this.contactNumber = '',
      required this.merchant});

  MerchantBranch.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreated = json['dateCreated'];
    dateUpdated = json['dateUpdated'];
    branchName = json['branchName'];
    branchManagerName = json['branchManagerName'];
    branchEmail = json['branchEmail'];
    contactNumber = json['contactNumber'];
    merchant = json['merchant'] != null
        ? new Merchant.fromJson(json['merchant'])
        : Merchant.empty();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateCreated'] = this.dateCreated;
    data['dateUpdated'] = this.dateUpdated;
    data['branchName'] = this.branchName;
    data['branchManagerName'] = this.branchManagerName;
    data['branchEmail'] = this.branchEmail;
    data['contactNumber'] = this.contactNumber;
    if (this.merchant != null) {
      data['merchant'] = this.merchant.toJson();
    }
    return data;
  }
}

class Merchant {
  late String id;
  late String dateUpdated;
  late String merchantName;
  late String officeAddress;
  late String contactPersonName;
  late String contactPersonEmail;
  late String contactPersonDesignation;
  late double floatLimit;
  late int numberOfBranches;
  late int projectedCashiers;
  late List<Accounts> accounts = [];
  late List<Currencies> currencies = [];
  late bool active;
  Merchant.empty();
  Merchant(
      {this.id = '',
      this.dateUpdated = '',
      this.merchantName = '',
      this.officeAddress = '',
      this.contactPersonName = '',
      this.contactPersonEmail = '',
      this.contactPersonDesignation = '',
      this.floatLimit = 0,
      this.numberOfBranches = 0,
      this.projectedCashiers = 0,
      required this.accounts,
      required this.currencies,
      this.active = false});

  Merchant.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateUpdated = json['dateUpdated'];
    merchantName = json['merchantName'];
    officeAddress = json['officeAddress'];
    contactPersonName = json['contactPersonName'];
    contactPersonEmail = json['contactPersonEmail'];
    contactPersonDesignation = json['contactPersonDesignation'];
    floatLimit = json['floatLimit'].toDouble() ?? 0.0;
    numberOfBranches = json['numberOfBranches'];
    projectedCashiers = json['projectedCashiers'];
    if (json['accounts'] != null) {
      accounts = List<Accounts>.empty(growable: true);
      json['accounts'].forEach((v) {
        accounts.add(Accounts.fromJson(v));
      });
    }
    if (json['currencies'] != null) {
      currencies = List<Currencies>.empty(growable: true);
      json['currencies'].forEach((v) {
        currencies.add(Currencies.fromJson(v));
      });
    }
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateUpdated'] = this.dateUpdated;
    data['merchantName'] = this.merchantName;
    data['officeAddress'] = this.officeAddress;
    data['contactPersonName'] = this.contactPersonName;
    data['contactPersonEmail'] = this.contactPersonEmail;
    data['contactPersonDesignation'] = this.contactPersonDesignation;
    data['floatLimit'] = this.floatLimit;
    data['numberOfBranches'] = this.numberOfBranches;
    data['projectedCashiers'] = this.projectedCashiers;
    if (this.accounts != null) {
      data['accounts'] = this.accounts.map((v) => v.toJson()).toList();
    }
    if (this.currencies != null) {
      data['currencies'] = this.currencies.map((v) => v.toJson()).toList();
    }
    data['active'] = this.active;
    return data;
  }
}

class Accounts {
  late String id;
  late String dateUpdated;
  double accountBalance = 0;
  late String accountAlias;

  Accounts(
      {required this.id,
      this.dateUpdated = '',
      this.accountBalance = 0,
      this.accountAlias = ''});

  Accounts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateUpdated = json['dateUpdated'];
    accountBalance = json['accountBalance'].toDouble() ?? 0.0;
    accountAlias = json['accountAlias'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateUpdated'] = this.dateUpdated;
    data['accountBalance'] = this.accountBalance;
    data['accountAlias'] = this.accountAlias;
    return data;
  }
}

class Currencies {
  late String id = '';
  late String dateUpdated;
  late String currencyCode;
  late String currencyName;
  double exchangeRate = 0;

  Currencies(
      {this.id = '',
      this.dateUpdated = '',
      this.currencyCode = '',
      this.currencyName = '',
      this.exchangeRate = 0});

  Currencies.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateUpdated = json['dateUpdated'];
    currencyCode = json['currencyCode'];
    currencyName = json['currencyName'];
    exchangeRate = json['exchangeRate'].toDouble() ?? 0.0;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateUpdated'] = this.dateUpdated;
    data['currencyCode'] = this.currencyCode;
    data['currencyName'] = this.currencyName;
    data['exchangeRate'] = this.exchangeRate;
    return data;
  }
}
