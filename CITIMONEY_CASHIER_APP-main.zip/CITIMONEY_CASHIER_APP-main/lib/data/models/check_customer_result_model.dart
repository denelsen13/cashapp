import 'package:change_money_cashier_app/data/models/responses/wallet_response.dart';
import 'package:change_money_cashier_app/domain/entities/check_customer_entity.dart';

class CheckCashierResultModel extends CheckCashierEntity {
  late String msisdn = '';
  late String id = '';
  late double currentBalance = 0;
  late double totalChangeIssuedBalance = 0;
  CheckCashierResultModel({
    required this.totalChangeIssuedBalance,
    required this.id,
    required this.currentBalance,
    required this.msisdn,
  }) : super(
          id: id,
          msisdn: msisdn,
          currentBalance: currentBalance,
          totalChangeIssuedBalance: totalChangeIssuedBalance,
        );

  factory CheckCashierResultModel.fromJson(Map<String, dynamic> map) {
    return CheckCashierResultModel(
      id: map['id'],
      msisdn: map['msisdn'] as String,
      currentBalance: map['currentBalance'] as double,
      totalChangeIssuedBalance: map['totalChangeIssuedBalance'] as double,
    );
  }
}
