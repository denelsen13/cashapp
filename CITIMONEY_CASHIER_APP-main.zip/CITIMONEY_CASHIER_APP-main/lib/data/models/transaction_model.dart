import 'package:change_money_cashier_app/data/models/enums/transaction_status.dart';
import 'package:change_money_cashier_app/data/models/enums/transaction_type.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/financial_institution_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_branch_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_cashier_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_response.dart';
import 'package:change_money_cashier_app/data/models/responses/teller_response.dart';
import 'package:change_money_cashier_app/data/models/responses/user_customer_response.dart';
import 'package:change_money_cashier_app/domain/entities/transaction_entity.dart';

class TransactionModel extends TransactionEntity {
  final String id;
  final String reference;
  final String dateCreated;
  final String dateUpdated;
  final double amount;
  final double amountInUsd;
  final double baseExchangeRateUsed;
  final double merchantIncentiveUsed;
  final double totalExchangeRateUsed;
  final double changeAlreadyIssued;
  final double changeAlreadyIssuedInUsd;
  final double requiredChange;
  final double requiredChangeInUsd;
  final String destinationAccount;
  final String dateOfTransaction;
  final String notificationMsisdn;
  final double transactionCharge;
  final double transactionChargeInUsd;
  final TransactionType transactionType;
  final TransactionStatus status;
  final MerchantResponse merchant;
  final MerchantCashierResponse cashier;
  final TellerResponse teller;
  final MerchantBranchResponse merchantBranch;
  final UserCustomerResponse customer;
  final UserCustomerResponse receiver;
  final CurrencyResponse currency;
  final FinancialInstitutionResponse financialInstitution;

  TransactionModel({
    required this.id,
    required this.dateCreated,
    required this.dateUpdated,
    required this.reference,
    required this.amount,
    required this.transactionCharge,
    required this.financialInstitution,
    required this.currency,
    required this.teller,
    required this.customer,
    required this.receiver,
    required this.merchantBranch,
    required this.cashier,
    required this.merchant,
    required this.status,
    required this.transactionType,
    required this.transactionChargeInUsd,
    required this.notificationMsisdn,
    required this.dateOfTransaction,
    required this.destinationAccount,
    required this.requiredChangeInUsd,
    required this.requiredChange,
    required this.changeAlreadyIssuedInUsd,
    required this.changeAlreadyIssued,
    required this.totalExchangeRateUsed,
    required this.merchantIncentiveUsed,
    required this.baseExchangeRateUsed,
    required this.amountInUsd,
  }) : super(
          id: id,
          dateCreated: dateCreated,
          dateUpdated: dateUpdated,
          reference: reference,
          amount: amount,
          transactionCharge: transactionCharge,
          financialInstitution: financialInstitution,
          currency: currency,
          customer: customer,
          receiver: receiver,
          merchantBranch: merchantBranch,
          cashier: cashier,
          merchant: merchant,
          status: status,
          transactionType: transactionType,
          transactionChargeInUsd: transactionChargeInUsd,
          notificationMsisdn: notificationMsisdn,
          dateOfTransaction: dateOfTransaction,
          destinationAccount: destinationAccount,
          requiredChangeInUsd: requiredChangeInUsd,
          requiredChange: requiredChange,
          changeAlreadyIssuedInUsd: changeAlreadyIssuedInUsd,
          changeAlreadyIssued: changeAlreadyIssued,
          totalExchangeRateUsed: totalExchangeRateUsed,
          merchantIncentiveUsed: merchantIncentiveUsed,
          baseExchangeRateUsed: baseExchangeRateUsed,
          amountInUsd: amountInUsd,
        );

  factory TransactionModel.fromJson(Map<String, dynamic> json) {
    return TransactionModel(
      id: json['id'] != null ? json['id'] as String : '',
      dateCreated:
          json['dateCreated'] != null ? json['dateCreated'] as String : '',
      dateUpdated:
          json['dateUpdated'] != null ? json['dateUpdated'] as String : '',
      reference: json['reference'] != null ? json['reference'] as String : '',
      amount: json['amount'].toDouble() ?? 0.0,
      destinationAccount: json['destinationAccount'] != null
          ? json['destinationAccount'] as String
          : '',
      transactionCharge: json['transactionCharge'].toDouble() ?? 0.0,
      amountInUsd: json['amountInUsd'] as double,
      baseExchangeRateUsed: json['baseExchangeRateUsed'] as double,
      merchantIncentiveUsed: json['merchantIncentiveUsed'] as double,
      totalExchangeRateUsed: json['totalExchangeRateUsed'] as double,
      changeAlreadyIssued: json['changeAlreadyIssued'] as double,
      changeAlreadyIssuedInUsd: json['changeAlreadyIssuedInUsd'] as double,
      requiredChange: json['requiredChange'] as double,
      requiredChangeInUsd: json['requiredChangeInUsd'] as double,
      dateOfTransaction: json['dateOfTransaction'] != null
          ? json['dateOfTransaction'] as String
          : '',
      notificationMsisdn: json['notificationMsisdn'] != null
          ? json['notificationMsisdn'] as String
          : '',
      transactionChargeInUsd: json['transactionChargeInUsd'] as double,
      transactionType: json['transactionType'] != null
          ? TransactionType.values.firstWhere((element) =>
              element.toString() ==
              'TransactionType.${json['transactionType']}')
          : TransactionType.PAYMENT,
      status: json['status'] != null
          ? TransactionStatus.values.firstWhere((element) =>
              element.toString() == 'TransactionStatus.${json['status']}')
          : TransactionStatus.PENDING,
      merchant: json['merchant'] != null
          ? MerchantResponse.fromJson(json['merchant'])
          : MerchantResponse.empty(),
      cashier: json['cashier'] != null
          ? MerchantCashierResponse.fromJson(json['cashier'])
          : MerchantCashierResponse.empty(),
      merchantBranch: json['merchantBranch'] != null
          ? MerchantBranchResponse.fromJson(json['merchantBranch'])
          : MerchantBranchResponse.empty(),
      receiver: json['receiver'] != null
          ? UserCustomerResponse.fromJson(json['receiver'])
          : UserCustomerResponse.empty(),
      customer: json['customer'] != null
          ? UserCustomerResponse.fromJson(json['customer'])
          : UserCustomerResponse.empty(),
      teller: json['teller'] != null
          ? TellerResponse.fromJson(json['teller'])
          : TellerResponse.empty(),
      currency: json['currency'] != null
          ? CurrencyResponse.fromJson(json['currency'])
          : CurrencyResponse.empty(),
      financialInstitution: json['financialInstitution'] != null
          ? FinancialInstitutionResponse.fromJson(json['financialInstitution'])
          : FinancialInstitutionResponse.empty(),
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateCreated'] = this.dateCreated;
    data['dateUpdated'] = this.dateUpdated;
    data['reference'] = this.reference;
    data['amount'] = this.amount;
    data['destinationAccount'] = this.destinationAccount;
    data['transactionCharge'] = this.transactionCharge;
    return data;
  }
}
