import 'package:change_money_cashier_app/data/models/enums/gender.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_branch_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_response.dart';
import 'package:change_money_cashier_app/data/models/responses/privilege_response.dart';
import 'package:change_money_cashier_app/data/models/responses/role_response.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';

import 'enums/socket_group.dart';

class LoginResultModel extends LoginEntity {
  late String userId = '';
  late String firstName = '';
  late bool verified = false;
  late String mobileNumber = '';
  late bool available = true;
  late String mobileNumberCountryCode = '';
  late String username = '';
  late bool enabled = true;
  late bool resetPin = false;
  late String surname = '';
  late String dateCreated = '';
  late String dateUpdated = '';
  late String email = '';
  late String userGroup = '';
  late WebSocketMessageGroup webSocketMessageGroup =
      WebSocketMessageGroup.CUSTOMERS;
  late String avatar = "default";
  late Gender gender = Gender.NOT_SET;
  late MerchantResponse merchant = MerchantResponse.empty();
  late MerchantBranchResponse merchantBranch = MerchantBranchResponse.empty();
  late List<RoleResponse> userRoles = [];
  late List<PrivilegeResponse> privileges = [];
  late String message = "success";
  late String accessToken = '';

  LoginResultModel({
    required this.accessToken,
    required this.userId,
    required this.firstName,
    required this.verified,
    required this.mobileNumber,
    required this.available,
    required this.email,
    required this.mobileNumberCountryCode,
    required this.enabled,
    required this.username,
    required this.resetPin,
    required this.surname,
    required this.dateCreated,
    required this.dateUpdated,
    required this.userGroup,
    required this.webSocketMessageGroup,
    required this.avatar,
    required this.gender,
    required this.merchant,
    required this.merchantBranch,
    required this.userRoles,
    required this.privileges,
    required this.message,
  }) : super(
          accessToken: accessToken,
          userId: userId,
          firstName: firstName,
          verified: verified,
          mobileNumber: mobileNumber,
          available: available,
          email: email,
          mobileNumberCountryCode: mobileNumberCountryCode,
          enabled: enabled,
          username: username,
          resetPin: resetPin,
          surname: surname,
          dateCreated: dateCreated,
          dateUpdated: dateUpdated,
          userGroup: userGroup,
          webSocketMessageGroup: webSocketMessageGroup,
          gender: gender,
          merchant: merchant,
          merchantBranch: merchantBranch,
          userRoles: userRoles,
          privileges: privileges,
        );

  factory LoginResultModel.fromJson(Map<String, dynamic> json) {
    List<RoleResponse> roles = [];
    if (json['userRoles'] != null) {
      var list = json['userRoles'] as List;

      roles = list.map((i) => RoleResponse.fromJson(i)).toList();
    }
    List<PrivilegeResponse> privileges = [];
    if (json['privileges'] != null) {
      var list = json['privileges'] as List;

      privileges = list.map((i) => PrivilegeResponse.fromJson(i)).toList();
    }
    return LoginResultModel(
      accessToken:
          json['accessToken'] != null ? json['accessToken'] as String : '',
      userId: json['userId'] != null ? json['userId'] as String : '',
      verified: json['verified'] as bool,
      mobileNumber:
          json['mobileNumber'] != null ? json['mobileNumber'] as String : '',
      available: json['available'] as bool,
      email: json['email'] != null ? json['email'] as String : '',
      firstName: json['firstName'],
      mobileNumberCountryCode: json['mobileNumberCountryCode'] != null
          ? json['mobileNumberCountryCode'] as String
          : '',
      enabled: json['enabled'] as bool,
      username: json['username'] != null ? json['username'] as String : '',
      resetPin: json['resetPin'] as bool,
      surname: json['surname'] != null ? json['surname'] as String : '',
      dateCreated:
          json['dateCreated'] != null ? json['dateCreated'] as String : '',
      dateUpdated:
          json['dateUpdated'] != null ? json['dateUpdated'] as String : '',
      userGroup: json['userGroup'] != null ? json['userGroup'] as String : '',
      webSocketMessageGroup: json['webSocketMessageGroup'] != null
          ? WebSocketMessageGroup.values.firstWhere((element) =>
              element.toString() ==
              'WebSocketMessageGroup.${json['webSocketMessageGroup']}')
          : WebSocketMessageGroup.CUSTOMERS,
      avatar: json['avatar'] != null ? json['avatar'] as String : '',
      gender: json['gender'] != null
          ? Gender.values.firstWhere(
              (element) => element.toString() == 'Gender.${json['gender']}')
          : Gender.NOT_SET,
      merchant: json['merchant'] != null
          ? MerchantResponse.fromJson(json['merchant'])
          : MerchantResponse.empty(),
      merchantBranch: json['merchantBranch'] != null
          ? MerchantBranchResponse.fromJson(json['merchantBranch'])
          : MerchantBranchResponse.empty(),
      message: json['message'] != null ? json['message'] as String : '',
      userRoles: roles,
      privileges: privileges,
    );
  }

  Map<String, dynamic> toJson() {
    late Map<String, dynamic> data = new Map<String, dynamic>();
    data['access_token'] = this.accessToken;
    data['email'] = this.email;
    data['firstName'] = this.firstName;
    data['lastName'] = this.surname;
    data['username'] = this.username;
    data['id'] = this.userId;
    data['roles'] = this.userRoles;
    data['permissions'] = this.privileges;
    return data;
  }
}
