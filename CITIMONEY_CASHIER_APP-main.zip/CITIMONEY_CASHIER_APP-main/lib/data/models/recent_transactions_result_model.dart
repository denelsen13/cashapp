import 'package:change_money_cashier_app/data/models/transaction_model.dart';

class RecentTrasactionsResultModel {
  AdditionalData? additionalData;
  late bool success;
  late String narrative;
  List<TransactionModel>? dtos;
  late String responseCode;
  PageResponseDto? pageResponseDto;

  RecentTrasactionsResultModel(
      {required this.additionalData,
      required this.success,
      required this.narrative,
      required this.dtos,
      required this.responseCode,
      required this.pageResponseDto});

  RecentTrasactionsResultModel.fromJson(Map<String, dynamic> json) {
    additionalData = json['additionalData'] != null
        ? AdditionalData.fromJson(json['additionalData'])
        : AdditionalData.empty();
    success = json['success'];
    narrative = json['narrative'];
    if (json['dtos'] != null) {
      dtos = List<TransactionModel>.empty(growable: true);
      json['dtos'].forEach((v) {
        dtos!.add(TransactionModel.fromJson(v));
      });
    }
    responseCode = json['responseCode'];
    pageResponseDto = json['pageResponseDto'] != null
        ? PageResponseDto.fromJson(json['pageResponseDto'])
        : PageResponseDto.empty();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.additionalData != null) {
      data['additionalData'] = this.additionalData!.toJson();
    }
    data['success'] = this.success;
    data['narrative'] = this.narrative;
    if (this.dtos != null) {
      data['dtos'] = this.dtos!.map((v) => v.toJson()).toList();
    }
    data['responseCode'] = this.responseCode;
    if (this.pageResponseDto != null) {
      data['pageResponseDto'] = this.pageResponseDto!.toJson();
    }
    return data;
  }
}

class AdditionalData {
  late String total;
  AdditionalData.empty();
  AdditionalData({required this.total});

  AdditionalData.fromJson(Map<String, dynamic> json) {
    total = json['total'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['total'] = this.total;
    return data;
  }
}

class Account {
  late String id;
  late String dateUpdated;
  double accountBalance = 0;
  late String accountAlias;
  Account.empty();
  Account(
      {required this.id,
      required this.dateUpdated,
      required this.accountBalance,
      required this.accountAlias});

  Account.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateUpdated = json['dateUpdated'];
    accountBalance = json['accountBalance'].toDouble() ?? 0.0;
    accountAlias = json['accountAlias'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateUpdated'] = this.dateUpdated;
    data['accountBalance'] = this.accountBalance;
    data['accountAlias'] = this.accountAlias;
    return data;
  }
}

class Currency {
  late String id;
  late String dateUpdated;
  late String currencyCode;
  late String currencyName;
  double exchangeRate = 0;
  Currency.empty();
  Currency(
      {required this.id,
      required this.dateUpdated,
      required this.currencyCode,
      required this.currencyName,
      required this.exchangeRate});

  Currency.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateUpdated = json['dateUpdated'];
    currencyCode = json['currencyCode'];
    currencyName = json['currencyName'];
    exchangeRate = json['exchangeRate'].toDouble() ?? 0.0;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateUpdated'] = this.dateUpdated;
    data['currencyCode'] = this.currencyCode;
    data['currencyName'] = this.currencyName;
    data['exchangeRate'] = this.exchangeRate;
    return data;
  }
}

class Merchant {
  late String id;
  late String dateUpdated;
  late String merchantName;
  late String officeAddress;
  late String contactPersonName;
  late String contactPersonEmail;
  late String contactPersonDesignation;
  late double floatLimit;
  late int numberOfBranches;
  late int projectedCashiers;
  List<Account> accounts = [];
  List<Currency> currencies = [];
  late bool active;
  Merchant.empty();
  Merchant(
      {required this.id,
      required this.dateUpdated,
      required this.merchantName,
      required this.officeAddress,
      required this.contactPersonName,
      required this.contactPersonEmail,
      required this.contactPersonDesignation,
      required this.floatLimit,
      required this.numberOfBranches,
      required this.projectedCashiers,
      required this.accounts,
      required this.currencies,
      required this.active});

  Merchant.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateUpdated = json['dateUpdated'];
    merchantName = json['merchantName'];
    officeAddress = json['officeAddress'];
    contactPersonName = json['contactPersonName'];
    contactPersonEmail = json['contactPersonEmail'];
    contactPersonDesignation = json['contactPersonDesignation'];
    floatLimit = json['floatLimit'].toDouble() ?? 0.0;
    numberOfBranches = json['numberOfBranches'];
    projectedCashiers = json['projectedCashiers'];
    if (json['accounts'] != null) {
      accounts = List<Account>.empty(growable: true);
      json['accounts'].forEach((v) {
        accounts.add(new Account.fromJson(v));
      });
    }
    if (json['currencies'] != null) {
      currencies = List<Currency>.empty(growable: true);
      json['currencies'].forEach((v) {
        currencies.add(new Currency.fromJson(v));
      });
    }
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateUpdated'] = this.dateUpdated;
    data['merchantName'] = this.merchantName;
    data['officeAddress'] = this.officeAddress;
    data['contactPersonName'] = this.contactPersonName;
    data['contactPersonEmail'] = this.contactPersonEmail;
    data['contactPersonDesignation'] = this.contactPersonDesignation;
    data['floatLimit'] = this.floatLimit;
    data['numberOfBranches'] = this.numberOfBranches;
    data['projectedCashiers'] = this.projectedCashiers;
    if (this.accounts != null) {
      data['accounts'] = this.accounts.map((v) => v.toJson()).toList();
    }
    if (this.currencies != null) {
      data['currencies'] = this.currencies.map((v) => v.toJson()).toList();
    }
    data['active'] = this.active;
    return data;
  }
}

class MerchantUser {
  late String id;
  late String dateCreated;
  late String dateUpdated;
  late String msisdn;
  late String name;
  late bool active;
  MerchantBranch? merchantBranch;

  MerchantUser(
      {required this.id,
      required this.dateCreated,
      required this.dateUpdated,
      required this.msisdn,
      required this.name,
      required this.active,
      required this.merchantBranch});

  MerchantUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreated = json['dateCreated'];
    dateUpdated = json['dateUpdated'];
    msisdn = json['msisdn'];
    name = json['name'];
    active = json['active'];
    merchantBranch = json['merchantBranch'] != null
        ? new MerchantBranch.fromJson(json['merchantBranch'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateCreated'] = this.dateCreated;
    data['dateUpdated'] = this.dateUpdated;
    data['msisdn'] = this.msisdn;
    data['name'] = this.name;
    data['active'] = this.active;
    if (this.merchantBranch != null) {
      data['merchantBranch'] = this.merchantBranch!.toJson();
    }
    return data;
  }
}

class MerchantBranch {
  late String id;
  late String dateCreated;
  late String dateUpdated;
  late String branchName;
  late String branchManagerName;
  late String branchEmail;
  late String contactNumber;
  Merchant? merchant;

  MerchantBranch(
      {required this.id,
      required this.dateCreated,
      required this.dateUpdated,
      required this.branchName,
      required this.branchManagerName,
      required this.branchEmail,
      required this.contactNumber,
      required this.merchant});

  MerchantBranch.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    dateCreated = json['dateCreated'];
    dateUpdated = json['dateUpdated'];
    branchName = json['branchName'];
    branchManagerName = json['branchManagerName'];
    branchEmail = json['branchEmail'];
    contactNumber = json['contactNumber'];
    merchant = json['merchant'] != null
        ? new Merchant.fromJson(json['merchant'])
        : Merchant.empty();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['dateCreated'] = this.dateCreated;
    data['dateUpdated'] = this.dateUpdated;
    data['branchName'] = this.branchName;
    data['branchManagerName'] = this.branchManagerName;
    data['branchEmail'] = this.branchEmail;
    data['contactNumber'] = this.contactNumber;
    if (this.merchant != null) {
      data['merchant'] = this.merchant!.toJson();
    }
    return data;
  }
}

class PageResponseDto {
  late bool last;
  late int totalPages = 0;
  late int totalElements;
  int size = 0;
  late int number = 0;
  late bool first;
  late int numberOfElements = 0;
  PageResponseDto.empty();
  PageResponseDto(
      {required this.last,
      required this.totalPages,
      required this.totalElements,
      required this.size,
      required this.number,
      required this.first,
      required this.numberOfElements});

  PageResponseDto.fromJson(Map<String, dynamic> json) {
    last = json['last'];
    totalPages = json['totalPages'];
    totalElements = json['totalElements'];
    size = json['size'];
    number = json['number'];
    first = json['first'];
    numberOfElements = json['numberOfElements'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['last'] = this.last;
    data['totalPages'] = this.totalPages;
    data['totalElements'] = this.totalElements;
    data['size'] = this.size;
    data['number'] = this.number;
    data['first'] = this.first;
    data['numberOfElements'] = this.numberOfElements;
    return data;
  }
}
