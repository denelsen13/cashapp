class ChangePinRequestDTO {
  final String confirmPin;
  final String msisdn;
  final String newPin;
  final String oldPin;
  ChangePinRequestDTO(
      {required this.confirmPin,
      required this.msisdn,
      required this.newPin,
      required this.oldPin});
}
