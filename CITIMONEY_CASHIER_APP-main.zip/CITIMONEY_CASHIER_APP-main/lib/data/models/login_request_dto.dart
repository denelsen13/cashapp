class LoginRequestDTO {
  final String mobileNumberOrEmail;
  final String password;
  final String channel;

  LoginRequestDTO(
      {required this.mobileNumberOrEmail,
      required this.password,
      required this.channel});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['mobileNumberOrEmail'] = mobileNumberOrEmail;
    data['password'] = password;
    data['channel'] = channel;
    return data;
  }
}
