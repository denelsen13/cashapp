enum MerchantAccountStatus { ACTIVE, CLOSED, BLOCKED }
