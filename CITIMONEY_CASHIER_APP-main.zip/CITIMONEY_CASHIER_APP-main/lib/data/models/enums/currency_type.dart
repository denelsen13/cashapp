enum CurrencyType { USD, ZWL }
