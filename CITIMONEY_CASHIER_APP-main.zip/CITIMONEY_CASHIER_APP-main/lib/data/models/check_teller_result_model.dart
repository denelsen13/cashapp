import 'package:change_money_cashier_app/domain/entities/check_teller_entity.dart';

class CheckTellerResultModel extends CheckTellerEntity {
  late String msisdn = '';
  late String id = '';
  late double totalWithdrawal = 0;
  CheckTellerResultModel({
    required this.totalWithdrawal,
    required this.id,
    required this.msisdn,
  }) : super(
          id: id,
          msisdn: msisdn,
          totalWithdrawal: totalWithdrawal,
        );

  factory CheckTellerResultModel.fromJson(Map<String, dynamic> map) {
    return CheckTellerResultModel(
      id: map['id'],
      msisdn: map['msisdn'] as String,
      totalWithdrawal: map['totalWithdrawal'] as double,
    );
  }
}
