import 'package:equatable/equatable.dart';

import 'enums/notification_type.dart';

class NotificationResultModel extends Equatable {
  late int id = 0;
  late String userId = '';
  late String time = '';
  late String message = '';
  late NotificationType responseType = NotificationType.NONE;
  late bool readStatus = false;
  late String title = '';
  NotificationResultModel.empty();
  NotificationResultModel({
    required this.id,
    required this.userId,
    required this.time,
    required this.message,
    required this.responseType,
    required this.readStatus,
    required this.title,
  });

  factory NotificationResultModel.fromJson(Map<String, dynamic> map) {
    return NotificationResultModel(
      id: map['id'],
      responseType: map['responseType'] != null
          ? NotificationType.values.firstWhere((element) =>
              element.toString() == 'NotificationType.${map['responseType']}')
          : NotificationType.NONE,
      userId: map['userId'] as String,
      time: map['time'] as String,
      message: map['message'] as String,
      readStatus: map['readStatus'] as bool,
      title: map['title'] as String,
    );
  }
  @override
  List<Object?> get props => [
        id,
        message,
        readStatus,
      ];
}
