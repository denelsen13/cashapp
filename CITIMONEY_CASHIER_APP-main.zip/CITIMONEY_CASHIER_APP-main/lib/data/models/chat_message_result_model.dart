import 'package:equatable/equatable.dart';

class ChatMessageResultModel extends Equatable {
  late int id = 0;
  late String message = '';
  late bool isFromCustomer = false;
  late bool readStatus = false;
  late String senderName = '';
  late String senderId = '';
  late String receiverName = '';
  late String receiverId = '';
  late String time = '';
  ChatMessageResultModel.empty();
  ChatMessageResultModel({
    required this.id,
    required this.message,
    required this.isFromCustomer,
    required this.readStatus,
    required this.senderName,
    required this.senderId,
    required this.receiverName,
    required this.receiverId,
    required this.time,
  });

  factory ChatMessageResultModel.fromJson(Map<String, dynamic> map) {
    return ChatMessageResultModel(
      id: map['id'],
      isFromCustomer: map['fromCustomer'] as bool,
      time: map['time'] as String,
      message: map['message'] as String,
      readStatus: map['readStatus'] as bool,
      senderName: map['senderName'] as String,
      senderId: map['senderId'] as String,
      receiverName: map['receiverName'] as String,
      receiverId: map['receiverId'] as String,
    );
  }
  @override
  List<Object?> get props => [
        id,
        message,
        readStatus,
      ];
}
