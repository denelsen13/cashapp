class CheckWithdrawalRequestDTO {
  final String approval;
  final String code;
  CheckWithdrawalRequestDTO({
    required this.approval,
    required this.code,
  });
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['approval'] = this.approval;
    data['code'] = this.code;
    return data;
  }
}
