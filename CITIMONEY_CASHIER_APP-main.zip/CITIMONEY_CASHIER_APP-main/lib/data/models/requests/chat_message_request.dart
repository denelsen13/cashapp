import 'package:equatable/equatable.dart';

class ChatMessageRequest extends Equatable {
  final String message;
  final bool isFromCustomer;
  final String senderId;
  final String receiverId;
  ChatMessageRequest({
    required this.isFromCustomer,
    required this.message,
    required this.senderId,
    required this.receiverId,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fromCustomer'] = this.isFromCustomer;
    data['message'] = this.message;
    data['senderId'] = this.senderId;
    data['receiverId'] = this.receiverId;
    return data;
  }

  @override
  List<Object?> get props => [
        isFromCustomer,
        message,
        senderId,
      ];
}
