class CheckPaymentRequestDTO {
  final String cashierCode;
  final String currencyCode;
  final double amount;
  CheckPaymentRequestDTO(
      {required this.cashierCode,
      required this.currencyCode,
      required this.amount});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['cashierCode'] = this.cashierCode;
    data['currencyCode'] = this.currencyCode;
    data['amount'] = this.amount;
    return data;
  }
}
