class ChangePasswordRequestDTO {
  final String oldPassword;
  final String newPassword;
  ChangePasswordRequestDTO(
      {required this.oldPassword, required this.newPassword});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['oldPassword'] = this.oldPassword;
    data['newPassword'] = this.newPassword;
    return data;
  }
}
