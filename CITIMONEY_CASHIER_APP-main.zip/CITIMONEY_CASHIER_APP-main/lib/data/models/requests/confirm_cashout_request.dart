class ConfirmCashoutRequestDTO {
  final String cashierCode;
  final String currencyCode;
  final double amount;
  final String pin;
  ConfirmCashoutRequestDTO(
      {required this.cashierCode,
      required this.currencyCode,
      required this.amount,
      required this.pin});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['cashierCode'] = this.cashierCode;
    data['currencyCode'] = this.currencyCode;
    data['amount'] = this.amount;
    data['pin'] = this.pin;
    return data;
  }
}
