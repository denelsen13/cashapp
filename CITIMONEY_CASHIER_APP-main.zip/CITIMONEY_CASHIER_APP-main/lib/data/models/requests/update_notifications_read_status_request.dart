class UpdateNotificationsReadStatusRequest {
  final List<int> notificationIds;
  UpdateNotificationsReadStatusRequest({required this.notificationIds});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['notificationIds'] = this.notificationIds;
    return data;
  }
}
