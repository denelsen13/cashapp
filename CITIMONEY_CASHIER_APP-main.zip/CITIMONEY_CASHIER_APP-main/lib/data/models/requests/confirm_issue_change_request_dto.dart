class ConfirmIssueChangeRequestDTO {
  final String pin;
  final String currencyCode;
  final String issueChangeType;
  final String destinationAccount;
  final String accountPhoneNumber;
  final String receiptNumber;
  final String acquiringFinancialInstitutionNumber;
  final String notificationMsisdn;
  final double tenderedAmount;
  final double changeAlreadyIssued;
  final double changeRequired;
  ConfirmIssueChangeRequestDTO(
      {required this.pin,
      required this.currencyCode,
      required this.accountPhoneNumber,
      required this.acquiringFinancialInstitutionNumber,
      required this.changeAlreadyIssued,
      required this.changeRequired,
      required this.destinationAccount,
      required this.issueChangeType,
      required this.notificationMsisdn,
      required this.receiptNumber,
      required this.tenderedAmount});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['pin'] = this.pin;
    data['accountPhoneNumber'] = this.accountPhoneNumber;
    data['acquiringFinancialInstitutionNumber'] =
        this.acquiringFinancialInstitutionNumber;
    data['changeAlreadyIssued'] = this.changeAlreadyIssued;
    data['changeRequired'] = this.changeRequired;
    data['destinationAccount'] = this.destinationAccount;
    data['issueChangeType'] = this.issueChangeType;
    data['notificationMsisdn'] = this.notificationMsisdn;
    data['receiptNumber'] = this.receiptNumber;
    data['currencyCode'] = this.currencyCode;
    data['tenderedAmount'] = this.tenderedAmount;
    return data;
  }
}
