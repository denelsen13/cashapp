class ConfirmWithdrawalRequestDTO {
  final String approval;
  final String code;
  final String pin;
  ConfirmWithdrawalRequestDTO({
    required this.approval,
    required this.code,
    required this.pin,
  });
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['approval'] = this.approval;
    data['code'] = this.code;
    data['pin'] = this.pin;
    return data;
  }
}
