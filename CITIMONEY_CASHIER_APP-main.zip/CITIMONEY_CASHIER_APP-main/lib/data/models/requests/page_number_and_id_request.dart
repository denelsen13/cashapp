class PageNumberAndIdRequest {
  late int pageNumber;
  late int id;
  PageNumberAndIdRequest({
    required this.pageNumber,
    required this.id,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['pageNumber'] = this.pageNumber;
    data['id'] = this.id;
    return data;
  }
}
