class ConfirmCashinRequestDTO {
  final String receiverPhoneNumber;
  final String pin;
  final double amount;
  ConfirmCashinRequestDTO(
      {required this.receiverPhoneNumber,
      required this.amount,
      required this.pin});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['receiverPhoneNumber'] = this.receiverPhoneNumber;
    data['amount'] = this.amount;
    data['pin'] = this.pin;
    return data;
  }
}
