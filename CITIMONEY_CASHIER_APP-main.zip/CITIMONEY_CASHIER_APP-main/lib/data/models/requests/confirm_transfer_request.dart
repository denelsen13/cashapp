class ConfirmTransferRequestDTO {
  final String receiverNumber;
  final String reference;
  final double amount;
  final String pin;
  ConfirmTransferRequestDTO(
      {required this.receiverNumber,
      required this.amount,
      required this.reference,
      required this.pin});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['receiverNumber'] = this.receiverNumber;
    data['amount'] = this.amount;
    data['reference'] = this.reference;
    data['pin'] = this.pin;
    return data;
  }
}
