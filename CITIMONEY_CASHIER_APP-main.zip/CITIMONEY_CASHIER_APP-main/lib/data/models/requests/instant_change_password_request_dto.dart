class InstantChangePasswordRequestDTO {
  final String newPassword;
  InstantChangePasswordRequestDTO({required this.newPassword});
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['newPassword'] = this.newPassword;
    return data;
  }
}
