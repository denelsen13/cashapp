class UpdateProfileRequestDTO {
  final String email;
  final String firstName;
  final String mobileNumber;
  final String mobileNumberCountryCode;
  final String surname;
  UpdateProfileRequestDTO(
      {required this.email,
      required this.firstName,
      required this.mobileNumberCountryCode,
      required this.surname,
      required this.mobileNumber});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['email'] = this.email;
    data['firstName'] = this.firstName;
    data['surname'] = this.surname;
    data['mobileNumber'] = this.mobileNumber;
    data['mobileNumberCountryCode'] = this.mobileNumberCountryCode;
    return data;
  }
}
