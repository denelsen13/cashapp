import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_cashier_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_response.dart';

class CheckWithdrawalResponse {
  late MerchantResponse merchant = MerchantResponse.empty();
  late double amount = 0;
  late String approvalCode = '';
  late String code = '';
  late double amountInUsd = 0;
  CheckWithdrawalResponse.empty();
  CheckWithdrawalResponse({
    required this.merchant,
    required this.amount,
    required this.approvalCode,
    required this.code,
    required this.amountInUsd,
  });
  factory CheckWithdrawalResponse.fromJson(Map<String, dynamic> json) {
    return CheckWithdrawalResponse(
      merchant: json['merchant'] != null
          ? MerchantResponse.fromJson(json['merchant'])
          : MerchantResponse.empty(),
      amount: json['amount'] as double,
      amountInUsd: json['amountInUsd'] as double,
      approvalCode:
          json['approvalCode'] != null ? json['approvalCode'] as String : '',
      code: json['code'] != null ? json['code'] as String : '',
    );
  }
}
