import '../chat_message_result_model.dart';

class ChatMessagePagedResponse {
  late int? page;
  late int? size;
  late int? totalElements;
  late int? totalPages;
  late bool last;
  late List<ChatMessageResultModel>? messages = [];
  ChatMessagePagedResponse.empty({
    this.page = 0,
    this.size = 0,
    this.totalElements = 0,
    this.totalPages = 0,
    this.last = false,
  });
  ChatMessagePagedResponse({
    required this.page,
    required this.size,
    required this.totalElements,
    required this.totalPages,
    required this.last,
    required this.messages,
  });
  factory ChatMessagePagedResponse.fromJson(Map<String, dynamic> json) {
    List<ChatMessageResultModel> dataList = [];
    if (json['content'] != null) {
      var list = json['content'] as List;

      dataList = list.map((i) => ChatMessageResultModel.fromJson(i)).toList();
    }

    return ChatMessagePagedResponse(
      messages: dataList,
      page: json['page'] as int,
      size: json['size'] as int,
      totalElements: json['totalElements'] as int,
      totalPages: json['totalPages'] as int,
      last: json['last'] as bool,
    );
  }
  @override
  List<Object?> get props =>
      [page, size, totalElements, totalPages, last, messages];
}
