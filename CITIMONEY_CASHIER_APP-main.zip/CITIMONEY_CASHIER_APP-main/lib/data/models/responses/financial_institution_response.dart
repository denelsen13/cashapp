class FinancialInstitutionResponse {
  late int id;
  late String institutionNumber;
  late String name;
  late String displayName;
  late bool active;
  late bool isMobileMoney;
  late String url;
  FinancialInstitutionResponse.empty();
  FinancialInstitutionResponse({
    required this.id,
    required this.institutionNumber,
    required this.name,
    required this.displayName,
    required this.active,
    required this.isMobileMoney,
    required this.url,
  });
  factory FinancialInstitutionResponse.fromJson(Map<String, dynamic> json) {
    return FinancialInstitutionResponse(
      id: json['id'] as int,
      institutionNumber: json['institutionNumber'] != null
          ? json['institutionNumber'] as String
          : '',
      name: json['name'] != null ? json['name'] as String : '',
      displayName:
          json['displayName'] != null ? json['displayName'] as String : '',
      active: json['active'] as bool,
      isMobileMoney: json['isMobileMoney'] as bool,
      url: json['url'] != null ? json['url'] as String : '',
    );
  }
}
