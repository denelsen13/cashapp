import 'package:change_money_cashier_app/data/models/enums/gender.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_branch_response.dart';

class MerchantCashierResponse {
  late String userId = '';
  late String firstName = '';
  late String code = '';
  late bool active = false;
  late String surname = '';
  late String email = '';
  late Gender gender = Gender.NOT_SET;
  late MerchantBranchResponse merchantBranch = MerchantBranchResponse.empty();
  MerchantCashierResponse.empty();
  MerchantCashierResponse({
    required this.userId,
    required this.firstName,
    required this.code,
    required this.active,
    required this.surname,
    required this.email,
    required this.gender,
    required this.merchantBranch,
  });
  factory MerchantCashierResponse.fromJson(Map<String, dynamic> json) {
    return MerchantCashierResponse(
      userId: json['userId'] != null ? json['userId'] as String : '',
      firstName: json['firstName'] != null ? json['firstName'] as String : '',
      code: json['code'] != null ? json['code'] as String : '',
      active: json['active'] as bool,
      surname: json['surname'] != null ? json['surname'] as String : '',
      email: json['email'] != null ? json['email'] as String : '',
      gender: json['gender'] != null
          ? Gender.values.firstWhere(
              (element) => element.toString() == 'Gender.${json['gender']}')
          : Gender.NOT_SET,
      merchantBranch: json['merchantBranch'] != null
          ? MerchantBranchResponse.fromJson(json['merchantBranch'])
          : MerchantBranchResponse.empty(),
    );
  }
}
