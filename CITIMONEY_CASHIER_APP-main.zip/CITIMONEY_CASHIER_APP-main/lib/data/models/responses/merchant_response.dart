import 'merchant_account_response.dart';

class MerchantResponse {
  late String id = '';
  late String name = '';
  late String tradingAs = '';
  late String companyRegNumber = '';
  late String officeAddress = '';
  late String contactPersonName = '';
  late String contactPersonSurname = '';
  late String contactPersonNumber = '';
  late String contactPersonEmail = '';
  late String contactPersonDesignation = '';
  late double minFloatLimit = 0;
  late int numberOfBranches = 0;
  late int projectedCashiers = 0;
  late int projectedAdmins = 0;
  late double projectedDailyFloatBalance = 0;
  late double projectedNumberOfProducts = 0;
  late bool active = false;
  late MerchantAccountResponse account = MerchantAccountResponse.empty();

  MerchantResponse.empty();
  MerchantResponse({
    required this.id,
    required this.name,
    required this.tradingAs,
    required this.companyRegNumber,
    required this.officeAddress,
    required this.contactPersonName,
    required this.contactPersonSurname,
    required this.contactPersonNumber,
    required this.contactPersonEmail,
    required this.contactPersonDesignation,
    required this.minFloatLimit,
    required this.numberOfBranches,
    required this.projectedCashiers,
    required this.projectedDailyFloatBalance,
    required this.projectedNumberOfProducts,
    required this.active,
    required this.account,
  });
  factory MerchantResponse.fromJson(Map<String, dynamic> json) {
    return MerchantResponse(
      name: json['name'] != null ? json['name'] as String : '',
      id: json['id'] != null ? json['id'] as String : '',
      tradingAs: json['tradingAs'] != null ? json['tradingAs'] as String : '',
      companyRegNumber: json['companyRegNumber'] != null
          ? json['companyRegNumber'] as String
          : '',
      officeAddress:
          json['officeAddress'] != null ? json['officeAddress'] as String : '',
      contactPersonName: json['contactPersonName'] != null
          ? json['contactPersonName'] as String
          : '',
      contactPersonSurname: json['contactPersonSurname'] != null
          ? json['contactPersonSurname'] as String
          : '',
      contactPersonNumber: json['contactPersonNumber'] != null
          ? json['contactPersonNumber'] as String
          : '',
      contactPersonEmail: json['contactPersonEmail'] != null
          ? json['contactPersonEmail'] as String
          : '',
      contactPersonDesignation: json['contactPersonDesignation'] != null
          ? json['contactPersonDesignation'] as String
          : '',
      minFloatLimit: json['minFloatLimit'] as double,
      numberOfBranches: json['numberOfBranches'] as int,
      projectedCashiers: json['projectedCashiers'] as int,
      projectedDailyFloatBalance: json['projectedDailyFloatBalance'] as double,
      projectedNumberOfProducts: json['projectedNumberOfProducts'] as double,
      active: json['active'] as bool,
      account: json['account'] != null
          ? MerchantAccountResponse.fromJson(json['account'])
          : MerchantAccountResponse.empty(),
    );
  }
}
