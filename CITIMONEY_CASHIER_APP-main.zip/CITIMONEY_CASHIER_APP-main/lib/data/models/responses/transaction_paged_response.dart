import 'package:change_money_cashier_app/data/models/transaction_model.dart';

class TransactionPagedResponse {
  late int? page;
  late int? size;
  late int? totalElements;
  late int? totalPages;
  late bool last;
  late List<TransactionModel>? transactions = [];
  TransactionPagedResponse.empty({
    this.page = 0,
    this.size = 0,
    this.totalElements = 0,
    this.totalPages = 0,
    this.last = false,
  });
  TransactionPagedResponse({
    required this.page,
    required this.size,
    required this.totalElements,
    required this.totalPages,
    required this.last,
    required this.transactions,
  });
  factory TransactionPagedResponse.fromJson(Map<String, dynamic> json) {
    List<TransactionModel> dataList = [];
    if (json['content'] != null) {
      var list = json['content'] as List;

      dataList = list.map((i) => TransactionModel.fromJson(i)).toList();
    }

    return TransactionPagedResponse(
      transactions: dataList,
      page: json['page'] as int,
      size: json['size'] as int,
      totalElements: json['totalElements'] as int,
      totalPages: json['totalPages'] as int,
      last: json['last'] as bool,
    );
  }
  @override
  List<Object?> get props =>
      [page, size, totalElements, totalPages, last, transactions];
}
