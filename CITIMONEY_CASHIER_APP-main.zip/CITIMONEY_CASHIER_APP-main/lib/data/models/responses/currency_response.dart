class CurrencyResponse {
  late int id;
  late String code;
  late String name;
  late double exchangeRate;
  late bool active;
  CurrencyResponse.empty();
  CurrencyResponse({
    required this.code,
    required this.id,
    required this.name,
    required this.exchangeRate,
    required this.active,
  });
  factory CurrencyResponse.fromJson(Map<String, dynamic> json) {
    return CurrencyResponse(
      code: json['code'] != null ? json['code'] as String : '',
      id: json['id'] as int,
      name: json['name'] != null ? json['name'] as String : '',
      exchangeRate: json['exchangeRate'] as double,
      active: json['active'] as bool,
    );
  }
}
