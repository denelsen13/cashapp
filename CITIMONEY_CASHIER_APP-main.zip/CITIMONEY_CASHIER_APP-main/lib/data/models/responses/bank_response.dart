class BankResponse {
  late int id;
  late String name;
  late bool active;
  BankResponse({
    required this.id,
    required this.name,
    required this.active,
  });

  factory BankResponse.fromJson(Map<String, dynamic> json) {
    return BankResponse(
      id: json['id'] as int,
      name: json['name'] != null ? json['name'] as String : '',
      active: json['active'] as bool,
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['active'] = this.active;
    return data;
  }
}
