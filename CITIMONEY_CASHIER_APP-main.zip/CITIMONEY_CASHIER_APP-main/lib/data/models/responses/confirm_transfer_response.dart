import 'package:change_money_cashier_app/data/models/responses/user_customer_response.dart';

class ConfirmTransferResponse {
  late UserCustomerResponse receiver = UserCustomerResponse.empty();
  late double amount = 0;
  late String reference = '';
  ConfirmTransferResponse.empty();
  ConfirmTransferResponse({
    required this.receiver,
    required this.reference,
    required this.amount,
  });
  factory ConfirmTransferResponse.fromJson(Map<String, dynamic> json) {
    return ConfirmTransferResponse(
      receiver: json['receiver'] != null
          ? UserCustomerResponse.fromJson(json['receiver'])
          : UserCustomerResponse.empty(),
      amount: json['amount'] as double,
      reference: json['reference'] != null ? json['reference'] as String : '',
    );
  }
}
