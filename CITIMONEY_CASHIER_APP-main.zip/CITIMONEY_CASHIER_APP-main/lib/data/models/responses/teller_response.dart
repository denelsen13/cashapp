import 'package:equatable/equatable.dart';

class TellerResponse extends Equatable {
  late String firstName;
  late String userId;
  late bool active;
  late String surname;
  late String mobileNumber;
  late String mobileNumberCountryCode;
  late String email;
  TellerResponse.empty({
    this.firstName = '',
    this.userId = '',
    this.surname = '',
    this.active = false,
    this.mobileNumber = '',
    this.mobileNumberCountryCode = '',
    this.email = '',
  });
  TellerResponse({
    required this.firstName,
    required this.userId,
    required this.surname,
    required this.active,
    required this.mobileNumber,
    required this.mobileNumberCountryCode,
    required this.email,
  });

  factory TellerResponse.fromJson(Map<String, dynamic> json) {
    if (json == null) {
      return TellerResponse(
          active: false,
          userId: '',
          email: '',
          firstName: '',
          mobileNumber: '',
          mobileNumberCountryCode: '',
          surname: '');
    } else {
      return TellerResponse(
        firstName: json['firstName'] != null ? json['firstName'] as String : '',
        active: json['active'] as bool,
        userId: json['userId'] != null ? json['userId'] as String : '',
        surname: json['surname'] != null ? json['surname'] as String : '',
        mobileNumber:
            json['mobileNumber'] != null ? json['mobileNumber'] as String : '',
        mobileNumberCountryCode: json['mobileNumberCountryCode'] != null
            ? json['mobileNumberCountryCode'] as String
            : '',
        email: json['email'] != null ? json['email'] as String : '',
      );
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = firstName;
    data['userId'] = userId;
    data['active'] = active;
    data['surname'] = surname;
    data['mobileNumber'] = mobileNumber;
    data['mobileNumberCountryCode'] = mobileNumberCountryCode;
    data['email'] = email;
    return data;
  }

  @override
  List<Object?> get props {
    return [this.firstName, this.surname, this.active, this.mobileNumber];
  }
}
