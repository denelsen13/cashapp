class MerchantBranchResponse {
  late int id = 0;
  late String name = '';
  late String branchManagerName = '';
  late String branchEmail = '';
  late String contactNumber = '';
  late bool active = false;
  MerchantBranchResponse.empty();
  MerchantBranchResponse({
    required this.id,
    required this.name,
    required this.branchManagerName,
    required this.branchEmail,
    required this.contactNumber,
    required this.active,
  });
  factory MerchantBranchResponse.fromJson(Map<String, dynamic> json) {
    return MerchantBranchResponse(
      id: json['id'] as int,
      name: json['name'] != null ? json['name'] as String : '',
      branchManagerName: json['branchManagerName'] != null
          ? json['branchManagerName'] as String
          : '',
      branchEmail:
          json['branchEmail'] != null ? json['branchEmail'] as String : '',
      contactNumber:
          json['contactNumber'] != null ? json['contactNumber'] as String : '',
      active: json['active'] as bool,
    );
  }
}
