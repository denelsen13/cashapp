import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_cashier_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_response.dart';

class CheckCashoutResponse {
  late MerchantResponse merchant = MerchantResponse.empty();
  late MerchantCashierResponse cashier = MerchantCashierResponse.empty();
  late CurrencyResponse currency = CurrencyResponse.empty();
  late double amount = 0;
  late double amountInUsd = 0;
  CheckCashoutResponse.empty();
  CheckCashoutResponse({
    required this.merchant,
    required this.cashier,
    required this.currency,
    required this.amount,
    required this.amountInUsd,
  });
  factory CheckCashoutResponse.fromJson(Map<String, dynamic> json) {
    return CheckCashoutResponse(
      merchant: json['merchant'] != null
          ? MerchantResponse.fromJson(json['merchant'])
          : MerchantResponse.empty(),
      cashier: json['cashier'] != null
          ? MerchantCashierResponse.fromJson(json['cashier'])
          : MerchantCashierResponse.empty(),
      currency: json['currency'] != null
          ? CurrencyResponse.fromJson(json['currency'])
          : CurrencyResponse.empty(),
      amount: json['amount'] as double,
      amountInUsd: json['amountInUsd'] as double,
    );
  }
}
