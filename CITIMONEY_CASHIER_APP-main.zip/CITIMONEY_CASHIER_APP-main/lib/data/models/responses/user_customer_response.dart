import 'package:equatable/equatable.dart';

class UserCustomerResponse extends Equatable {
  late String firstName;
  late String customerId;
  late bool active;
  late String surname;
  late String mobileNumber;
  late String mobileNumberCountryCode;
  late String email;
  UserCustomerResponse.empty({
    this.firstName = '',
    this.customerId = '',
    this.surname = '',
    this.active = false,
    this.mobileNumber = '',
    this.mobileNumberCountryCode = '',
    this.email = '',
  });
  UserCustomerResponse({
    required this.firstName,
    required this.customerId,
    required this.surname,
    required this.active,
    required this.mobileNumber,
    required this.mobileNumberCountryCode,
    required this.email,
  });

  factory UserCustomerResponse.fromJson(Map<String, dynamic> json) {
    if (json == null) {
      return UserCustomerResponse(
          active: false,
          customerId: '',
          email: '',
          firstName: '',
          mobileNumber: '',
          mobileNumberCountryCode: '',
          surname: '');
    } else {
      return UserCustomerResponse(
        firstName: json['firstName'] != null ? json['firstName'] as String : '',
        active: json['active'] as bool,
        customerId:
            json['customerId'] != null ? json['customerId'] as String : '',
        surname: json['surname'] != null ? json['surname'] as String : '',
        mobileNumber:
            json['mobileNumber'] != null ? json['mobileNumber'] as String : '',
        mobileNumberCountryCode: json['mobileNumberCountryCode'] != null
            ? json['mobileNumberCountryCode'] as String
            : '',
        email: json['email'] != null ? json['email'] as String : '',
      );
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = firstName;
    data['customerId'] = customerId;
    data['active'] = active;
    data['surname'] = surname;
    data['mobileNumber'] = mobileNumber;
    data['mobileNumberCountryCode'] = mobileNumberCountryCode;
    data['email'] = email;
    return data;
  }

  @override
  List<Object?> get props {
    return [this.firstName, this.surname, this.active, this.mobileNumber];
  }
}
