import 'package:change_money_cashier_app/data/models/responses/user_customer_response.dart';

class CheckTransferResponse {
  late UserCustomerResponse receiver = UserCustomerResponse.empty();
  late double amount = 0;
  late String reference = '';
  CheckTransferResponse.empty();
  CheckTransferResponse({
    required this.receiver,
    required this.reference,
    required this.amount,
  });
  factory CheckTransferResponse.fromJson(Map<String, dynamic> json) {
    return CheckTransferResponse(
      receiver: json['receiver'] != null
          ? UserCustomerResponse.fromJson(json['receiver'])
          : UserCustomerResponse.empty(),
      amount: json['amount'] as double,
      reference: json['reference'] != null ? json['reference'] as String : '',
    );
  }
}
