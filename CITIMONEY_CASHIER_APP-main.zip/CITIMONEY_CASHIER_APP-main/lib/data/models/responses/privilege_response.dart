class PrivilegeResponse {
  late int id;
  late String name;

  PrivilegeResponse.empty();
  PrivilegeResponse({
    required this.id,
    required this.name,
  });
  factory PrivilegeResponse.fromJson(Map<String, dynamic> json) {
    return PrivilegeResponse(
      id: json['id'] as int,
      name: json['name'] != null ? json['name'] as String : '',
    );
  }
}
