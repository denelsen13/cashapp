import 'package:change_money_cashier_app/data/models/responses/user_customer_response.dart';

class WalletResponse {
  late int id = 0;
  late double balance = 0;
  late String ecocashAccount = '';
  late String oneMoneyAccount = '';
  late String telecashAccount = '';
  WalletResponse.empty();
  WalletResponse({
    required this.id,
    required this.balance,
    required this.ecocashAccount,
    required this.oneMoneyAccount,
    required this.telecashAccount,
  });
  factory WalletResponse.fromJson(Map<String, dynamic> json) {
    return WalletResponse(
      id: json['id'] as int,
      balance: json['balance'] as double,
      ecocashAccount: json['ecocashAccount'] != null
          ? json['ecocashAccount'] as String
          : '',
      oneMoneyAccount: json['oneMoneyAccount'] != null
          ? json['oneMoneyAccount'] as String
          : '',
      telecashAccount: json['telecashAccount'] != null
          ? json['telecashAccount'] as String
          : '',
    );
  }
}
