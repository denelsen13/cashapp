import '../enums/merchant_account_status.dart';

class MerchantAccountResponse {
  late int id = 0;
  late MerchantAccountStatus status = MerchantAccountStatus.CLOSED;
  late String accountAlias = '';
  late double accountBalance = 0.0;
  late bool active = false;

  MerchantAccountResponse.empty();
  MerchantAccountResponse({
    required this.id,
    required this.status,
    required this.accountAlias,
    required this.accountBalance,
    required this.active,
  });
  factory MerchantAccountResponse.fromJson(Map<String, dynamic> json) {
    return MerchantAccountResponse(
      status: json['status'] != null
          ? MerchantAccountStatus.values.firstWhere((element) =>
              element.toString() == 'MerchantAccountStatus.${json['status']}')
          : MerchantAccountStatus.CLOSED,
      id: json['id'] as int,
      accountAlias:
          json['accountAlias'] != null ? json['accountAlias'] as String : '',
      accountBalance: json['accountBalance'] as double,
      active: json['active'] as bool,
    );
  }
}
