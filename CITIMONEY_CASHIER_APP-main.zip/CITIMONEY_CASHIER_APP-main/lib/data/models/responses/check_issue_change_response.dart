import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_cashier_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_response.dart';
import 'package:change_money_cashier_app/data/models/responses/user_customer_response.dart';

class CheckIssueChangeResponse {
  late MerchantResponse merchant = MerchantResponse.empty();
  late MerchantCashierResponse cashier = MerchantCashierResponse.empty();
  late UserCustomerResponse customer = UserCustomerResponse.empty();
  late CurrencyResponse currency = CurrencyResponse.empty();
  late double amount = 0;
  late double changeAlreadyIssued = 0;
  late double changeRequired = 0;
  late double amountInUsd = 0;
  late String receiptNumber = '';

  CheckIssueChangeResponse.empty();
  CheckIssueChangeResponse({
    required this.merchant,
    required this.cashier,
    required this.currency,
    required this.customer,
    required this.receiptNumber,
    required this.changeRequired,
    required this.changeAlreadyIssued,
    required this.amount,
    required this.amountInUsd,
  });
  factory CheckIssueChangeResponse.fromJson(Map<String, dynamic> json) {
    return CheckIssueChangeResponse(
      merchant: json['merchant'] != null
          ? MerchantResponse.fromJson(json['merchant'])
          : MerchantResponse.empty(),
      cashier: json['cashier'] != null
          ? MerchantCashierResponse.fromJson(json['cashier'])
          : MerchantCashierResponse.empty(),
      customer: json['customer'] != null
          ? UserCustomerResponse.fromJson(json['customer'])
          : UserCustomerResponse.empty(),
      currency: json['currency'] != null
          ? CurrencyResponse.fromJson(json['currency'])
          : CurrencyResponse.empty(),
      amount: json['amount'] as double,
      changeRequired: json['changeRequired'] as double,
      changeAlreadyIssued: json['changeAlreadyIssued'] as double,
      amountInUsd: json['amountInUsd'] as double,
      receiptNumber:
          json['receiptNumber'] != null ? json['receiptNumber'] as String : '',
    );
  }
}
