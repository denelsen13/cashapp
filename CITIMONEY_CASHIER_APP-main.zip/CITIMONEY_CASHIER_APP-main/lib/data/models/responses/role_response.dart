class RoleResponse {
  late String authority = '';
  RoleResponse.empty();
  RoleResponse({
    required this.authority,
  });
  factory RoleResponse.fromJson(Map<String, dynamic> json) {
    return RoleResponse(
      authority: json['authority'] != null ? json['authority'] as String : '',
    );
  }
}
