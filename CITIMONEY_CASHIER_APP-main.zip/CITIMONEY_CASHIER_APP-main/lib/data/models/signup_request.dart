class SignupRequestDTO {
  final String firstName;
  final String surname;
  final String appSignature;
  final String mobileNumber;
  final String mobileNumberCountryCode;
  final String password;
  SignupRequestDTO({
    required this.firstName,
    required this.surname,
    required this.mobileNumberCountryCode,
    required this.mobileNumber,
    required this.password,
    required this.appSignature,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['firstName'] = this.firstName;
    data['surname'] = this.surname;
    data['mobileNumber'] = this.mobileNumber;
    data['password'] = this.password;
    data['mobileNumberCountryCode'] = this.mobileNumberCountryCode;
    data['appSignature'] = this.appSignature;
    return data;
  }
}
