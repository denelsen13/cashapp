import 'dart:async';
import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/requests/update_profile_request.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/data/models/login_result_model.dart';
import 'package:change_money_cashier_app/domain/repositories/user_repository.dart';

import '../data_sources/change_money_remote_data_source.dart';

class UserRepositoryImpl extends UserRepository {
  final ChangeMoneyRemoteDataSource remoteDataSource;
  UserRepositoryImpl(this.remoteDataSource);

  @override
  Future<Either<AppError, LoginResultModel>> fetchProfile(
      NoParams noParams) async {
    try {
      final profileResult = await this.remoteDataSource.fetchProfile();
      return profileResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, NoResponse>> updateProfile(
      UpdateProfileRequestDTO request) async {
    try {
      final homeResult = await this.remoteDataSource.updateProfile(request);
      return homeResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }
}
