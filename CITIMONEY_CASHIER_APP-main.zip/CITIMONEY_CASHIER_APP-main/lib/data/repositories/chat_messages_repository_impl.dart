import 'dart:async';
import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/responses/chat_message_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/repositories/chat_messages_repository.dart';

import '../data_sources/change_money_remote_data_source.dart';

class ChatMessagesRepositoryImpl extends ChatMessagesRepository {
  final ChangeMoneyRemoteDataSource remoteDataSource;
  ChatMessagesRepositoryImpl(this.remoteDataSource);

  @override
  Future<Either<AppError, ChatMessagePagedResponse>> getAllChatMessages(
      int pageNumber) async {
    try {
      final loginResult =
          await this.remoteDataSource.getAllChatMessages(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }
}
