import 'dart:async';
import 'dart:io';

import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/requests/update_notifications_read_status_request.dart';
import 'package:change_money_cashier_app/data/models/responses/notification_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/notification_repository.dart';

import '../data_sources/change_money_remote_data_source.dart';

class NotificationRepositoryImpl extends NotificationRepository {
  final ChangeMoneyRemoteDataSource remoteDataSource;
  NotificationRepositoryImpl(this.remoteDataSource);
  @override
  Future<Either<AppError, NoResponse>> updateReadStatus(
      UpdateNotificationsReadStatusRequest request) async {
    try {
      final loginResult = await this.remoteDataSource.updateReadStatus(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, NotificationPagedResponse>> getAllNotifications(
      int pageNumber) async {
    try {
      final loginResult =
          await this.remoteDataSource.getAllNotifications(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, NoResponse>> updateSingleNotificationReadStatus(
      int notificationId) async {
    try {
      final loginResult = await this
          .remoteDataSource
          .updateSingleNotificationReadStatus(notificationId);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }
}
