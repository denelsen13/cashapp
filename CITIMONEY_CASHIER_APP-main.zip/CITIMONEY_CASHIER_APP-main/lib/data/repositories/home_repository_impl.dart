import 'dart:async';
import 'dart:io';

import 'package:change_money_cashier_app/data/data_sources/change_money_remote_data_source.dart';
import 'package:change_money_cashier_app/data/models/check_customer_result_model.dart';
import 'package:change_money_cashier_app/data/models/check_teller_result_model.dart';
import 'package:change_money_cashier_app/data/models/recent_transactions_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashin_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashin_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_issue_change_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_withdrawal_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/transaction_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/entities/transaction_entity.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/notifications/get_currencies_usecase.dart';
import 'package:dartz/dartz.dart';

class HomeRepositoryImpl extends HomeRepository {
  final ChangeMoneyRemoteDataSource remoteDataSource;
  HomeRepositoryImpl(this.remoteDataSource);

  @override
  Future<Either<AppError, CheckCashierResultModel>> checkCashier() async {
    try {
      final checkCashierResult = await this.remoteDataSource.checkCashier();
      return checkCashierResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckTellerResultModel>> checkTeller() async {
    try {
      final checkCashierResult = await this.remoteDataSource.checkTeller();
      return checkCashierResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, List<TransactionEntity>>>
      getRecentTransactions() async {
    try {
      final getRecentTrasactionsResult =
          await this.remoteDataSource.getRecentTrasactions();
      return getRecentTrasactionsResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, List<TransactionEntity>>>
      getTellerRecentTransactions() async {
    try {
      final getRecentTrasactionsResult =
          await this.remoteDataSource.getTellerRecentTransactions();
      return getRecentTrasactionsResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, List<CurrencyResponse>>> getCurrencies() async {
    try {
      final getRecentTrasactionsResult =
          await this.remoteDataSource.getCurrencies();
      return getRecentTrasactionsResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckCashoutResponse>> checkCashout(
      CheckCashoutRequestDTO request) async {
    try {
      final loginResult = await this.remoteDataSource.checkCashout(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckIssueChangeResponse>> checkIssueChange(
      CheckIssueChangeRequestDTO request) async {
    try {
      final loginResult = await this.remoteDataSource.checkIssueChange(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckWithdrawalResponse>> checkWithdrawal(
      CheckWithdrawalRequestDTO request) async {
    try {
      final loginResult = await this.remoteDataSource.checkWithdrawal(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckCashinResponse>> checkCashin(
      CheckCashinRequestDTO request) async {
    try {
      final loginResult = await this.remoteDataSource.checkCashin(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, ConfirmCashoutResponse>> confirmCashout(
      ConfirmCashoutRequestDTO request) async {
    try {
      final loginResult = await this.remoteDataSource.confirmCashout(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckIssueChangeResponse>> confirmIssueChange(
      ConfirmIssueChangeRequestDTO request) async {
    try {
      final loginResult =
          await this.remoteDataSource.confirmIssueChange(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckWithdrawalResponse>> confirmWithdrawal(
      ConfirmWithdrawalRequestDTO request) async {
    try {
      final loginResult =
          await this.remoteDataSource.confirmWithdrawal(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, CheckCashinResponse>> confirmCashin(
      ConfirmCashinRequestDTO request) async {
    try {
      final loginResult = await this.remoteDataSource.confirmCashin(request);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getCashins(
      int pageNumber) async {
    try {
      final loginResult = await this.remoteDataSource.getCashins(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getWithdrawals(
      int pageNumber) async {
    try {
      final loginResult =
          await this.remoteDataSource.getWithdrawals(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getCashouts(
      int pageNumber) async {
    try {
      final loginResult = await this.remoteDataSource.getCashouts(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getPayments(
      int pageNumber) async {
    try {
      final loginResult = await this.remoteDataSource.getPayments(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }

  @override
  Future<Either<AppError, TransactionPagedResponse>> getIssueChanges(
      int pageNumber) async {
    try {
      final loginResult =
          await this.remoteDataSource.getIssueChanges(pageNumber);
      return loginResult;
    } on TimeoutException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.'));
    } on SocketException {
      return Left(AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.'));
    }
  }
}
