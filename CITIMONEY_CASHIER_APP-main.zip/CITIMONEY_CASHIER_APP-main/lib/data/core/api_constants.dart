class ApiConstants {
  ApiConstants._();
  // static const String BASE_URL =
  //     'https://84c4-2c0f-f8f0-c600-3e5f-a424-57ed-17f6-c160.ngrok.io/api';
  // static const String SOCKET_URL =
  //     'https://84c4-2c0f-f8f0-c600-3e5f-a424-57ed-17f6-c160.ngrok.io';

  static const String BASE_URL = 'http://45.77.189.40:9052/api';
  static const String SOCKET_URL = 'http://45.77.189.40:9052';
  // static const String BASE_URL = 'https://f1d3-41-174-160-151.ngrok.io/api';
  // static const String SOCKET_URL = 'https://f1d3-41-174-160-151.ngrok.io';
}
