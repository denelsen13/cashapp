import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:change_money_cashier_app/data/core/api_constants.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:http/http.dart';

import '../../blocs/login/login_bloc.dart';
import '../../domain/entities/generic_error_response.dart';

class ApiClient {
  Client _client;
  ApiClient(this._client);
  dynamic get(String path) async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String accessToken = await sharedPreferencesUtil.getAccessToken();
    try {
      // print('${ApiConstants.BASE_URL}$path');
      final response = await _client
          .get(
        Uri.parse('${ApiConstants.BASE_URL}$path'),
        headers: (accessToken != null && accessToken.isNotEmpty)
            ? {
                'Content-Type': 'application/json',
                'Authorization': '$accessToken',
              }
            : {
                'Content-Type': 'application/json',
              },
      )
          .timeout(const Duration(seconds: 15), onTimeout: () {
        throw TimeoutException(
            'The connection has timed out, Please try again!');
      });

      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return formulateError(response.statusCode, response);
      }
    } on TimeoutException catch (e) {
      return AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.');
    } on SocketException {
      return AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.');
    }
  }

  dynamic post({required String path, dynamic body}) async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String accessToken = await sharedPreferencesUtil.getAccessToken();
    try {
      final response = await _client
          .post(
        Uri.parse('${ApiConstants.BASE_URL}$path'),
        headers: (accessToken != null && accessToken.isNotEmpty)
            ? {
                'Content-Type': 'application/json',
                'Authorization': '$accessToken',
              }
            : {
                'Content-Type': 'application/json',
              },
        body: jsonEncode(body),
      )
          .timeout(const Duration(seconds: 15), onTimeout: () {
        throw TimeoutException(
            'The connection has timed out, Please try again!');
      });

      if (response.statusCode == 200) {
        inspect(response);
        return json.decode(response.body);
      } else {
        return formulateError(response.statusCode, response);
      }
    } on TimeoutException catch (e) {
      return AppError(
          appErrorType: AppErrorType.network,
          message: 'The connection has timed out.');
    } on SocketException {
      return AppError(
          appErrorType: AppErrorType.network,
          message: 'You are not connected to the internet.');
    }
  }

  AppError formulateError(int statusCode, response) {
    // inspect(response);
    switch (statusCode) {
      case 401:
        getItInstance<LoginBloc>()
            .add(LoginLogoutEvent(message: 'Loggin you out...'));
        return AppError(
          appErrorType: AppErrorType.api,
          status: statusCode,
          message: 'You are not Authorised to perform action',
        );
      case 417:
        GenericErrorResponse errorResponse =
            GenericErrorResponse.fromJson(json.decode(response.body));
        return AppError(
          appErrorType: AppErrorType.api,
          status: errorResponse.code,
          message: errorResponse.error,
        );

      case 404:
        if (json.decode(response.body)['path'] != null) {
          return AppError(
            appErrorType: AppErrorType.api,
            status: 404,
            message: 'Wrong Path To API',
          );
        } else {
          GenericErrorResponse errorResponse =
              GenericErrorResponse.fromJson(json.decode(response.body));
          return AppError(
            appErrorType: AppErrorType.api,
            status: errorResponse.code,
            message: errorResponse.error,
          );
        }
      case 406:
        return AppError(
          appErrorType: AppErrorType.api,
          status: statusCode,
          message: 'Incorrect Username or password',
        );
      case 500:
        return AppError(
          appErrorType: AppErrorType.api,
          status: statusCode,
          message:
              'Something went wrong with your request Please contact Admin',
        );

      default:
        return AppError(
          appErrorType: AppErrorType.api,
          status: statusCode,
          message: 'Something went wrong Please contact Admin',
        );
    }
  }
}
