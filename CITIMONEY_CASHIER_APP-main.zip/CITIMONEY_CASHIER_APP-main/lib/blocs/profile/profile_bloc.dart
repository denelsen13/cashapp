import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../data/data_sources/shared_preference.dart';
import '../../data/models/requests/update_profile_request.dart';
import '../../di/get_it.dart';
import '../../domain/entities/app_error.dart';
import '../../domain/entities/no_params.dart';
import '../../domain/usecases/profile/fetch_profile_usecase.dart';
import '../../domain/usecases/profile/update_profile_usecase.dart';

part 'profile_event.dart';
part 'profile_state.dart';

class ProfileBloc extends Bloc<ProfileEvent, ProfileState> {
  final FetchProfileUsecase fetchProfileUsecase;
  final UpdateProfileUsecase updateProfileUsecase;
  ProfileBloc({
    required this.fetchProfileUsecase,
    required this.updateProfileUsecase,
  }) : super(ProfileInitial()) {
    on<ProfileInitialEvent>((event, emit) async {
      emit(ProfileLoading(loadingText: 'Fetching Profile Information...'));
      final response = await this.fetchProfileUsecase(NoParams());

      emit(response.fold(
        (error) {
          return ProfileError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (profileResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setFirstName(profileResult.firstName);
          sharedPreferencesUtil.setLastName(profileResult.surname);
          sharedPreferencesUtil.setUsername(profileResult.username);
          sharedPreferencesUtil.setRole(profileResult.userGroup);
          if (profileResult.mobileNumber != null) {
            sharedPreferencesUtil.setMobileNumber(profileResult.mobileNumber);
          }
          if (profileResult.mobileNumberCountryCode != null) {
            sharedPreferencesUtil.setMobileNumberCountryCode(
                profileResult.mobileNumberCountryCode);
          }

          if (profileResult.email != null) {
            sharedPreferencesUtil.setEmail(profileResult.email);
          }
          return ProfileInitialDone(
              firstName: profileResult.firstName,
              role: profileResult.userGroup,
              lastName: profileResult.surname,
              email: profileResult.email,
              mobileNumberCountryCode: profileResult.mobileNumberCountryCode,
              mobileNumber: profileResult.mobileNumber);
        },
      ));
    });
    on<ProfileUpdateEvent>((event, emit) async {
      emit(ProfileLoading(loadingText: 'Updating Profile Information...'));
      final response = await this.updateProfileUsecase(event.request);

      emit(response.fold(
        (error) {
          return ProfileError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setFirstName(event.request.firstName);
          sharedPreferencesUtil.setLastName(event.request.surname);
          sharedPreferencesUtil.setEmail(event.request.email);

          return ProfileUpdateDone(request: event.request);
        },
      ));
    });
  }
}
