part of 'profile_bloc.dart';

abstract class ProfileState extends Equatable {
  const ProfileState();

  @override
  List<Object> get props => [];
}

class ProfileReady extends ProfileState {}

class ProfileInitial extends ProfileState {}

class ProfileUpdateDone extends ProfileState {
  final UpdateProfileRequestDTO request;
  ProfileUpdateDone({required this.request});
}

class ProfileErrorDone extends ProfileState {}

class ProfileLoading extends ProfileState {
  final String loadingText;
  ProfileLoading({required this.loadingText});
}

class ProfileError extends ProfileState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  ProfileError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class ProfileInitialDone extends ProfileState {
  final String firstName;
  final String role;
  final String lastName;
  final String email;
  final String mobileNumber;
  final String mobileNumberCountryCode;
  ProfileInitialDone(
      {required this.firstName,
      required this.role,
      required this.lastName,
      required this.mobileNumberCountryCode,
      required this.email,
      required this.mobileNumber});
}
