part of 'chat_bloc.dart';

abstract class ChatEvent extends Equatable {
  const ChatEvent();

  @override
  List<Object> get props => [];
}

class GetAllChatMessagesEvent extends ChatEvent {
  final int pageNumber;
  GetAllChatMessagesEvent({required this.pageNumber});
}

class GetMoreChatMessagesEvent extends ChatEvent {
  final int pageNumber;
  GetMoreChatMessagesEvent({required this.pageNumber});
}
