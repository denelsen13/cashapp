part of 'chat_bloc.dart';

abstract class ChatState extends Equatable {
  const ChatState();

  @override
  List<Object> get props => [];
}

class ChatInitial extends ChatState {}

class FetchUpdatedDone extends ChatState {}

class GetAllChatMessagesDone extends ChatState {
  final ChatMessagePagedResponse chatMessages;
  GetAllChatMessagesDone({required this.chatMessages});
}

class GetMoreChatMessagesDone extends ChatState {
  final ChatMessagePagedResponse chatMessages;
  GetMoreChatMessagesDone({required this.chatMessages});
}

class ChatErrorDone extends ChatState {}

class ChatError extends ChatState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  ChatError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class ChatLoading extends ChatState {
  final String loadingText;
  ChatLoading({required this.loadingText});
}
