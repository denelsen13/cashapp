import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../data/models/responses/chat_message_paged_response.dart';
import '../../domain/entities/app_error.dart';
import '../../domain/usecases/chat/load_all_chat_messages_usecase.dart';

part 'chat_event.dart';
part 'chat_state.dart';

class ChatBloc extends Bloc<ChatEvent, ChatState> {
  final LoadAllChatMessagesUsecase loadAllChatMessagesUsecase;
  ChatMessagePagedResponse? chatMessagesPaged =
      ChatMessagePagedResponse.empty();
  ChatBloc({
    required this.loadAllChatMessagesUsecase,
  }) : super(ChatInitial()) {
    on<ChatEvent>((event, emit) {
      on<GetAllChatMessagesEvent>((event, emit) async {
        emit(ChatLoading(loadingText: 'Fetching Chat Messages...'));
        final response =
            await this.loadAllChatMessagesUsecase(event.pageNumber);
        emit(response.fold(
          (error) {
            return ChatError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (orderResult) {
            this.chatMessagesPaged = orderResult;
            return GetAllChatMessagesDone(chatMessages: orderResult);
          },
        ));
      });
      on<GetMoreChatMessagesEvent>((event, emit) async {
        emit(ChatLoading(loadingText: 'Fetching More Messages...'));
        final response =
            await this.loadAllChatMessagesUsecase(event.pageNumber);
        emit(response.fold(
          (error) {
            return ChatError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (orderResult) {
            this.chatMessagesPaged = orderResult;
            return GetMoreChatMessagesDone(chatMessages: orderResult);
          },
        ));
      });
    });
  }
}
