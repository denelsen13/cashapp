part of 'login_bloc.dart';

abstract class LoginEvent extends Equatable {
  const LoginEvent();

  @override
  List<Object> get props => [];
}

class LoginLoadEvent extends LoginEvent {}

class ForgotPasswordLoadEvent extends LoginEvent {}

class ChangePasswordLoadEvent extends LoginEvent {}

class VerifyOtpLoadEvent extends LoginEvent {}

class SignupLoadEvent extends LoginEvent {}

class LoginResetPasswordEvent extends LoginEvent {
  final BuildContext context;
  final String mobileNumber;
  LoginResetPasswordEvent({required this.context, required this.mobileNumber});
}

class LoginChangePasswordEvent extends LoginEvent {
  final BuildContext context;
  final InstantChangePasswordRequestDTO request;
  LoginChangePasswordEvent({
    required this.context,
    required this.request,
  });
}

class ChangePasswordEvent extends LoginEvent {
  final ChangePasswordRequestDTO request;
  ChangePasswordEvent({required this.request});
}

class SignupEvent extends LoginEvent {
  final SignupRequestDTO request;
  SignupEvent({required this.request});
}

class ResendOtpEvent extends LoginEvent {
  final String mobileNumber;
  ResendOtpEvent({required this.mobileNumber});
}

class ResetPasswordEvent extends LoginEvent {
  final String mobileNumber;
  ResetPasswordEvent({required this.mobileNumber});
}

class ResetPasswordVerifyOtpEvent extends LoginEvent {
  final String otp;
  ResetPasswordVerifyOtpEvent({required this.otp});
}

class VerifyOtpEvent extends LoginEvent {
  final String otp;
  VerifyOtpEvent({required this.otp});
}

class LoginLoginEvent extends LoginEvent {
  final BuildContext context;
  final String pin;
  final String username;
  LoginLoginEvent(
      {required this.context, required this.pin, required this.username});
}

class LoginErrorEvent extends LoginEvent {
  final BuildContext context;
  final String message;
  final AppErrorType appErrorType;
  LoginErrorEvent(
      {required this.context,
      required this.message,
      required this.appErrorType});
}

class LoginLogoutEvent extends LoginEvent {
  final String message;
  LoginLogoutEvent({
    this.message = 'Logging out...',
  });
}
