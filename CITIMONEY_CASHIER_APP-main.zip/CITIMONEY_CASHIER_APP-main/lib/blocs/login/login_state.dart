part of 'login_bloc.dart';

abstract class LoginState extends Equatable {
  const LoginState();

  @override
  List<Object> get props => [];
}

class LoginInitial extends LoginState {}

class ChangePasswordErrorDone extends LoginState {}

class SignupErrorDone extends LoginState {}

class LoginChangePasswordErrorDone extends LoginState {}

class ResetPasswordErrorDone extends LoginState {}

class LoginErrorDone extends LoginState {}

class LoginChangePasswordDone extends LoginState {}

class LoginChangePasswordCompleted extends LoginState {}

class ResetPasswordError extends LoginState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  ResetPasswordError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class LoginChangePasswordError extends LoginState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  LoginChangePasswordError(
      {this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class SignupError extends LoginState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  SignupError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class VerifyOtpError extends LoginState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  VerifyOtpError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class ChangePasswordError extends LoginState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  ChangePasswordError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class LoginError extends LoginState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  LoginError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class AuthLoading extends LoginState {
  final String loadingText;
  AuthLoading({required this.loadingText});
}

class ResetPasswordSuccess extends LoginState {}

class ResendOtpSuccess extends LoginState {}

class SignupSuccess extends LoginState {}

class OtpVerified extends LoginState {}

class LoginLoggedIn extends LoginState {}

class LoginResetPasswordSuccess extends LoginState {}
