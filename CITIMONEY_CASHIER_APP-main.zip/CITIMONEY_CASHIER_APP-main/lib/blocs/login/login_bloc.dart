import 'package:bloc/bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/change_pin_request_dto.dart';
import 'package:change_money_cashier_app/data/models/login_request_dto.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';
import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../data/models/requests/change_password_request_dto.dart';
import '../../data/models/requests/instant_change_password_request_dto.dart';
import '../../data/models/signup_request.dart';
import '../../domain/usecases/auth/change_password_usecase.dart';
import '../../domain/usecases/auth/instant_change_password_usecase.dart';
import '../../domain/usecases/auth/login_usecase.dart';
import '../../domain/usecases/auth/resend_otp_usecase.dart';
import '../../domain/usecases/auth/reset_password_usecase.dart';
import '../../domain/usecases/auth/reset_password_verify_otp_usecase.dart';
import '../../domain/usecases/auth/signup_usecase.dart';
import '../../domain/usecases/auth/verify_otp_usecase.dart';
import '../../utils/encoder_util.dart';
import '../../utils/navigation_service.dart';
import '../socket/socket_bloc.dart';

part 'login_event.dart';
part 'login_state.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  final LoginUsecase loginUsecase;
  final ResetPasswordUsecase resetPinUsecase;
  final ResendOtpUsecase resendOtpUsecase;
  final ChangePasswordUsecase changePinUsecase;
  final InstantChangePasswordUsecase instantChangePasswordUsecase;
  final SignupUsecase signupUsecase;
  final VerifyOtpUsecase verifyOtpUsecase;
  final ResetPasswordVerifyOtpUsecase resetPasswordVerifyOtpUsecase;
  LoginBloc({
    required this.loginUsecase,
    required this.changePinUsecase,
    required this.resetPinUsecase,
    required this.signupUsecase,
    required this.verifyOtpUsecase,
    required this.resetPasswordVerifyOtpUsecase,
    required this.resendOtpUsecase,
    required this.instantChangePasswordUsecase,
  }) : super(LoginInitial()) {
    on<LoginLoadEvent>((event, emit) {
      emit(LoginInitial());
    });
    on<SignupLoadEvent>((event, emit) {
      emit(LoginInitial());
    });
    on<ChangePasswordLoadEvent>((event, emit) {
      emit(LoginInitial());
    });
    on<ForgotPasswordLoadEvent>((event, emit) {
      emit(LoginInitial());
    });
    on<LoginLoginEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Logging in...'));
      final response = await this.loginUsecase(
        LoginRequestDTO(
          password: EncoderUtil.threefoldBase64Encode(event.pin),
          channel: 'ANDROID',
          mobileNumberOrEmail: event.username,
        ),
      );
      if (response == null) {
        emit(LoginError(
            appErrorType: AppErrorType.other,
            statusCode: 0,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return LoginError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (loginResult) {
            if (loginResult.userGroup != 'ROLE_CASHIER' &&
                loginResult.userGroup != 'ROLE_TELLER') {
              return LoginError(
                errorMessage:
                    'You are not allowed to use this App Please contact ChangeMoney Support for more Information',
                appErrorType: AppErrorType.other,
                statusCode: 401,
              );
            }
            if (!loginResult.verified) {
              getItInstance<NavigationService>()
                  .navigateToWithArguments(RouteList.verifyOtp, true);
            } else {
              SharedPreferenceUtil sharedPreferencesUtil =
                  getItInstance<SharedPreferenceUtil>();
              sharedPreferencesUtil.setAccessToken(loginResult.accessToken);

              sharedPreferencesUtil.setUserId(loginResult.userId);
              sharedPreferencesUtil.setFirstName(loginResult.firstName);
              sharedPreferencesUtil.setLastName(loginResult.surname);
              sharedPreferencesUtil.setUsername(loginResult.username);
              sharedPreferencesUtil.setRole(loginResult.userGroup);
              sharedPreferencesUtil
                  .setMobileNumberCountryCode(loginResult.mobileNumber);
              sharedPreferencesUtil.setMobileNumber(loginResult.mobileNumber);
              if (loginResult.email != null) {
                sharedPreferencesUtil.setEmail(loginResult.email);
              }

              sharedPreferencesUtil.setEnabled(loginResult.enabled);

              sharedPreferencesUtil.setResetPin(loginResult.resetPin);
              sharedPreferencesUtil.setVerified(loginResult.verified);

              if (loginResult.userGroup == 'ROLE_CASHIER') {
                getItInstance<NavigationService>()
                    .navigateToRemoveUntil(RouteList.home);
              } else {
                getItInstance<NavigationService>()
                    .navigateToRemoveUntil(RouteList.tellerHome);
              }

              return LoginLoggedIn();
            }

            return LoginLoggedIn();
          },
        ));
      }
    });

    on<ChangePasswordEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Changing Password...'));

      final response = await this.changePinUsecase(
        event.request,
      );

      emit(response.fold(
        (error) {
          return LoginChangePasswordError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setAccessToken(loginResult.accessToken);
          sharedPreferencesUtil.setUserId(loginResult.userId);
          sharedPreferencesUtil.setFirstName(loginResult.firstName);
          sharedPreferencesUtil.setLastName(loginResult.surname);
          sharedPreferencesUtil.setUsername(loginResult.username);
          sharedPreferencesUtil.setMobileNumber(loginResult.mobileNumber);
          sharedPreferencesUtil.setRole(loginResult.userGroup);
          sharedPreferencesUtil
              .setMobileNumberCountryCode(loginResult.mobileNumber);
          if (loginResult.email != null) {
            sharedPreferencesUtil.setEmail(loginResult.email);
          }

          sharedPreferencesUtil.setEnabled(loginResult.enabled);

          sharedPreferencesUtil.setResetPin(loginResult.resetPin);
          return LoginChangePasswordDone();
        },
      ));
    });
    on<LoginChangePasswordEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Changing Password...'));

      final response = await this.instantChangePasswordUsecase(
        event.request,
      );

      emit(response.fold(
        (error) {
          return LoginChangePasswordError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setAccessToken(loginResult.accessToken);
          sharedPreferencesUtil.setUserId(loginResult.userId);
          sharedPreferencesUtil.setFirstName(loginResult.firstName);
          sharedPreferencesUtil.setLastName(loginResult.surname);
          sharedPreferencesUtil.setUsername(loginResult.username);
          sharedPreferencesUtil.setMobileNumber(loginResult.mobileNumber);
          sharedPreferencesUtil.setRole(loginResult.userGroup);
          sharedPreferencesUtil
              .setMobileNumberCountryCode(loginResult.mobileNumber);
          if (loginResult.email != null) {
            sharedPreferencesUtil.setEmail(loginResult.email);
          }

          sharedPreferencesUtil.setEnabled(loginResult.enabled);

          sharedPreferencesUtil.setResetPin(loginResult.resetPin);
          getItInstance<NavigationService>()
              .navigateToRemoveUntil(RouteList.home);
          return LoginChangePasswordDone();
        },
      ));
    });

    on<LoginLogoutEvent>((event, emit) async {
      emit(AuthLoading(loadingText: event.message));
      SharedPreferenceUtil sharedPreferencesUtil =
          getItInstance<SharedPreferenceUtil>();
      sharedPreferencesUtil.clearStorage();

      getItInstance<NavigationService>().navigateToRemoveUntil(RouteList.login);
      getItInstance<SocketBloc>().add(DisconnectWebSocketEvent());
    });

    on<SignupEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Creating Account...'));
      final response = await this.signupUsecase(event.request);

      emit(response.fold(
        (error) {
          return SignupError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (signupResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setMobileNumber(event.request.mobileNumber);
          getItInstance<NavigationService>()
              .navigateToWithArguments(RouteList.verifyOtp, true);
          return SignupSuccess();
        },
      ));
    });
    on<ResendOtpEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Resending OTP...'));

      SmsAutoFill().listenForCode;
      final response = await this.resendOtpUsecase(event.mobileNumber);

      emit(response.fold(
        (error) {
          return VerifyOtpError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          return ResendOtpSuccess();
        },
      ));
    });
    on<ResetPasswordEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Resetting Password...'));
      final response = await this.resetPinUsecase(event.mobileNumber);

      emit(response.fold(
        (error) {
          return ResetPasswordError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setMobileNumber(event.mobileNumber);
          getItInstance<NavigationService>()
              .navigateToWithArguments(RouteList.verifyOtp, false);
          return ResetPasswordSuccess();
        },
      ));
    });
    on<ResetPasswordVerifyOtpEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Verifying Otp...'));
      final response = await this.resetPasswordVerifyOtpUsecase(event.otp);

      emit(response.fold(
        (error) {
          return VerifyOtpError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setAccessToken(loginResult.accessToken);
          sharedPreferencesUtil.setUserId(loginResult.userId);
          sharedPreferencesUtil.setFirstName(loginResult.firstName);
          sharedPreferencesUtil.setLastName(loginResult.surname);
          sharedPreferencesUtil.setUsername(loginResult.username);
          sharedPreferencesUtil.setMobileNumber(loginResult.mobileNumber);
          sharedPreferencesUtil.setRole(loginResult.userGroup);
          sharedPreferencesUtil
              .setMobileNumberCountryCode(loginResult.mobileNumber);
          if (loginResult.email != null) {
            sharedPreferencesUtil.setEmail(loginResult.email);
          }
          sharedPreferencesUtil.setEnabled(loginResult.enabled);

          sharedPreferencesUtil.setResetPin(loginResult.resetPin);
          getItInstance<NavigationService>()
              .navigateToRemoveUntil(RouteList.changePassword);
          return OtpVerified();
        },
      ));
    });
    on<VerifyOtpLoadEvent>((event, emit) async {
      await SmsAutoFill().listenForCode;
    });
    on<VerifyOtpEvent>((event, emit) async {
      emit(AuthLoading(loadingText: 'Verifying Otp...'));
      final response = await this.verifyOtpUsecase(event.otp);

      emit(response.fold(
        (error) {
          return VerifyOtpError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (loginResult) {
          SharedPreferenceUtil sharedPreferencesUtil =
              getItInstance<SharedPreferenceUtil>();
          sharedPreferencesUtil.setAccessToken(loginResult.accessToken);
          sharedPreferencesUtil.setUserId(loginResult.userId);
          sharedPreferencesUtil.setFirstName(loginResult.firstName);
          sharedPreferencesUtil.setLastName(loginResult.surname);
          sharedPreferencesUtil.setUsername(loginResult.username);
          sharedPreferencesUtil.setMobileNumber(loginResult.mobileNumber);
          sharedPreferencesUtil.setRole(loginResult.userGroup);
          sharedPreferencesUtil
              .setMobileNumberCountryCode(loginResult.mobileNumber);
          if (loginResult.email != null) {
            sharedPreferencesUtil.setEmail(loginResult.email);
          }
          sharedPreferencesUtil.setEnabled(loginResult.enabled);

          sharedPreferencesUtil.setResetPin(loginResult.resetPin);

          getItInstance<NavigationService>()
              .navigateToRemoveUntil(RouteList.home);
          return LoginLoggedIn();
        },
      ));
    });
  }
}
