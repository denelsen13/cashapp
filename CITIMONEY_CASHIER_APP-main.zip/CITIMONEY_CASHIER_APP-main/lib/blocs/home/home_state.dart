part of 'home_bloc.dart';

abstract class HomeState extends Equatable {
  const HomeState();

  @override
  List<Object> get props => [];
}

class HomeInitial extends HomeState {}

class HomeReAuthenticating extends HomeState {}

class HomeErrorDone extends HomeState {}

class CurrenciesLoadedDone extends HomeState {}

class CheckCashoutLoaded extends HomeState {
  final CheckCashoutResponse response;
  CheckCashoutLoaded({required this.response});
}

class CheckIssueChangeLoaded extends HomeState {
  final CheckIssueChangeResponse response;
  CheckIssueChangeLoaded({required this.response});
}

class CheckCashinLoaded extends HomeState {
  final CheckCashinResponse response;
  CheckCashinLoaded({required this.response});
}

class ConfirmCashoutLoaded extends HomeState {
  final ConfirmCashoutResponse response;
  ConfirmCashoutLoaded({required this.response});
}

class ConfirmIssueChangeLoaded extends HomeState {
  final CheckIssueChangeResponse response;
  ConfirmIssueChangeLoaded({required this.response});
}

class CheckWithdrawalLoaded extends HomeState {
  final CheckWithdrawalResponse response;
  CheckWithdrawalLoaded({required this.response});
}

class ConfirmWithdrawalLoaded extends HomeState {
  final CheckWithdrawalResponse response;
  ConfirmWithdrawalLoaded({required this.response});
}

class ConfirmCashinLoaded extends HomeState {
  final CheckCashinResponse response;
  ConfirmCashinLoaded({required this.response});
}

class HomeLoading extends HomeState {
  final String loadingText;
  HomeLoading({required this.loadingText});
}

class CurrenciesLoaded extends HomeState {
  final List<CurrencyResponse> currencies;
  const CurrenciesLoaded({required this.currencies});
}

class TellerHomeLoaded extends HomeState {
  final CheckTellerEntity tellerEntity;
  final List<TransactionEntity> transactions;
  TellerHomeLoaded({required this.tellerEntity, required this.transactions});
}

class HomeLoaded extends HomeState {
  final CheckCashierEntity cashierEntity;
  final List<TransactionEntity> transactions;
  HomeLoaded({required this.cashierEntity, required this.transactions});
}

class HomeError extends HomeState {
  final String errorMessage;
  final AppErrorType appErrorType;
  final int statusCode;
  HomeError(
      {required this.errorMessage,
      required this.appErrorType,
      required this.statusCode});
  @override
  List<Object> get props => [statusCode, errorMessage, appErrorType];
}
