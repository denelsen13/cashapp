import 'package:bloc/bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashin_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashin_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_issue_change_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_withdrawal_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/check_customer_entity.dart';
import 'package:change_money_cashier_app/domain/entities/check_teller_entity.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/entities/transaction_entity.dart';
import 'package:change_money_cashier_app/domain/usecases/notifications/get_currencies_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_cashout_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_payment_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_transfer_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_withdrawal_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_cashout_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_payment_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_transfer_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_withdrawal_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_float_balance_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_recent_transactions_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_teller_float_balance_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_teller_recent_transactions_usecase.dart';
import 'package:equatable/equatable.dart';

part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final GetRecentTransactionsUsecase getRecentTransactionsUsecase;
  final GetTellerRecentTransactionsUsecase getTellerRecentTransactionsUsecase;
  final GetFloatBalanceUsecase getFloatBalanceUsecase;
  final GetTellerFloatBalanceUsecase getTellerFloatBalanceUsecase;
  final GetCurrenciesUsecase getCurrenciesUsecase;
  final CheckCashoutUsecase checkCashoutUsecase;
  final CheckIssueChangeUsecase checkIssueChangeUsecase;
  final CheckCashinUsecase checkCashinUsecase;
  final CheckWithdrawalUsecase checkWithdrawalUsecase;
  final ConfirmCashoutUsecase confirmCashoutUsecase;
  final ConfirmWithdrawalUsecase confirmWithdrawalUsecase;
  final ConfirmIssueChangeUsecase confirmIssueChangeUsecase;
  final ConfirmCashinUsecase confirmCashinUsecase;
  HomeBloc(
      {required this.getRecentTransactionsUsecase,
      required this.getCurrenciesUsecase,
      required this.checkCashoutUsecase,
      required this.checkIssueChangeUsecase,
      required this.getTellerRecentTransactionsUsecase,
      required this.getTellerFloatBalanceUsecase,
      required this.checkCashinUsecase,
      required this.confirmCashoutUsecase,
      required this.checkWithdrawalUsecase,
      required this.confirmIssueChangeUsecase,
      required this.confirmWithdrawalUsecase,
      required this.confirmCashinUsecase,
      required this.getFloatBalanceUsecase})
      : super(HomeInitial()) {
    on<ConfirmWithdrawalEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Completing Withdrawal...'));
      final response = await this.confirmWithdrawalUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return ConfirmWithdrawalLoaded(response: result);
          },
        ));
      }
    });

    on<ConfirmCashoutEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Completing Cashout...'));
      final response = await this.confirmCashoutUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return ConfirmCashoutLoaded(response: result);
          },
        ));
      }
    });
    on<ConfirmCashinEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Completing Cashin...'));
      final response = await this.confirmCashinUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return ConfirmCashinLoaded(response: result);
          },
        ));
      }
    });
    on<ConfirmIssueChangeEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Completing IssueChange...'));
      final response = await this.confirmIssueChangeUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return ConfirmIssueChangeLoaded(response: result);
          },
        ));
      }
    });
    on<CheckWithdrawalEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Validating Withdrawal Details...'));
      final response = await this.checkWithdrawalUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return CheckWithdrawalLoaded(response: result);
          },
        ));
      }
    });

    on<CheckCashoutEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Validating Cashout Details...'));
      final response = await this.checkCashoutUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return CheckCashoutLoaded(response: result);
          },
        ));
      }
    });
    on<CheckCashinEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Validating Cashin Details...'));
      final response = await this.checkCashinUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return CheckCashinLoaded(response: result);
          },
        ));
      }
    });
    on<CheckIssueChangeEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Validating IssueChange Details...'));
      final response = await this.checkIssueChangeUsecase(event.request);
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return CheckIssueChangeLoaded(response: result);
          },
        ));
      }
    });
    on<LoadCurrenciesEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Fetching Currencies...'));
      final response = await this.getCurrenciesUsecase(NoParams());
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return CurrenciesLoaded(currencies: result);
          },
        ));
      }
    });

    on<TellerHomeLoadEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Fetching Data...'));
      final response = await this.getTellerFloatBalanceUsecase(NoParams());
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            SharedPreferenceUtil sharedPreferencesUtil =
                getItInstance<SharedPreferenceUtil>();

            sharedPreferencesUtil
                .setTotalWithdrawalIssued(result.totalWithdrawal);
            this.add(
                TellerHomeLoadRecentTransactionsEvent(tellerEntity: result));
            return HomeLoading(loadingText: 'Fetching Data...');
          },
        ));
      }
    });
    on<TellerHomeLoadRecentTransactionsEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Fetching Data...'));
      final response =
          await this.getTellerRecentTransactionsUsecase(NoParams());
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return TellerHomeLoaded(
                tellerEntity: event.tellerEntity, transactions: result);
          },
        ));
      }
    });

    on<HomeLoadEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Fetching Data...'));
      final response = await this.getFloatBalanceUsecase(NoParams());
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            SharedPreferenceUtil sharedPreferencesUtil =
                getItInstance<SharedPreferenceUtil>();

            sharedPreferencesUtil.setCurrentBalance(result.currentBalance);
            sharedPreferencesUtil
                .setTotalChangeIssued(result.totalChangeIssuedBalance);
            this.add(HomeLoadRecentTransactionsEvent(cashierEntity: result));
            return HomeLoading(loadingText: 'Fetching Data...');
          },
        ));
      }
    });
    on<HomeLoadRecentTransactionsEvent>((event, emit) async {
      emit(HomeLoading(loadingText: 'Fetching Data...'));
      final response = await this.getRecentTransactionsUsecase(NoParams());
      if (response == null) {
        emit(HomeError(
            statusCode: 0,
            appErrorType: AppErrorType.other,
            errorMessage: 'Something went terribly wrong. Try Again Later'));
      } else {
        emit(response.fold(
          (error) {
            return HomeError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (result) {
            return HomeLoaded(
                cashierEntity: event.cashierEntity, transactions: result);
          },
        ));
      }
    });
  }
  getFloatBalance() async {
    final response = await this.getFloatBalanceUsecase(NoParams());
    if (response == null) {
      return HomeError(
          statusCode: 0,
          appErrorType: AppErrorType.other,
          errorMessage: 'Something went terribly wrong. Try Again Later');
    } else {
      response.fold(
        (error) {
          return HomeError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (floatBalanceResult) {
          return floatBalanceResult;
        },
      );
    }
  }
}
