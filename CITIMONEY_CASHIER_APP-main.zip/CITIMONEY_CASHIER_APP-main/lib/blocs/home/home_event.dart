part of 'home_bloc.dart';

abstract class HomeEvent extends Equatable {
  const HomeEvent();

  @override
  List<Object> get props => [];
}

class HomeLoadEvent extends HomeEvent {}

class TellerHomeLoadEvent extends HomeEvent {}

class LoadCurrenciesEvent extends HomeEvent {}

class TellerHomeLoadRecentTransactionsEvent extends HomeEvent {
  final CheckTellerEntity tellerEntity;
  TellerHomeLoadRecentTransactionsEvent({required this.tellerEntity});
}

class HomeLoadRecentTransactionsEvent extends HomeEvent {
  final CheckCashierEntity cashierEntity;
  HomeLoadRecentTransactionsEvent({required this.cashierEntity});
}

class CheckCashoutEvent extends HomeEvent {
  final CheckCashoutRequestDTO request;
  CheckCashoutEvent({required this.request});
}

class CheckCashinEvent extends HomeEvent {
  final CheckCashinRequestDTO request;
  CheckCashinEvent({required this.request});
}

class CheckIssueChangeEvent extends HomeEvent {
  final CheckIssueChangeRequestDTO request;
  CheckIssueChangeEvent({required this.request});
}

class CheckWithdrawalEvent extends HomeEvent {
  final CheckWithdrawalRequestDTO request;
  CheckWithdrawalEvent({required this.request});
}

class ConfirmCashoutEvent extends HomeEvent {
  final ConfirmCashoutRequestDTO request;
  ConfirmCashoutEvent({required this.request});
}

class ConfirmCashinEvent extends HomeEvent {
  final ConfirmCashinRequestDTO request;
  ConfirmCashinEvent({required this.request});
}

class ConfirmIssueChangeEvent extends HomeEvent {
  final ConfirmIssueChangeRequestDTO request;
  ConfirmIssueChangeEvent({required this.request});
}

class ConfirmWithdrawalEvent extends HomeEvent {
  final ConfirmWithdrawalRequestDTO request;
  ConfirmWithdrawalEvent({required this.request});
}
