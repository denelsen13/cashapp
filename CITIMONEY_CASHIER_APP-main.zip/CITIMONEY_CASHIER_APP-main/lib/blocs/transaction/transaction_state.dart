part of 'transaction_bloc.dart';

abstract class TransactionState extends Equatable {
  const TransactionState();

  @override
  List<Object> get props => [];
}

class TransactionsErrorDone extends TransactionState {}

class TransactionInitial extends TransactionState {}

class GetAllPaymentTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetAllPaymentTransactionsDone({required this.transactions});
}

class GetMorePaymentTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetMorePaymentTransactionsDone({required this.transactions});
}

class GetAllIssueChangeTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetAllIssueChangeTransactionsDone({required this.transactions});
}

class GetMoreIssueChangeTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetMoreIssueChangeTransactionsDone({required this.transactions});
}

class FetchUpdatedDone extends TransactionState {}

class GetAllCashoutTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetAllCashoutTransactionsDone({required this.transactions});
}

class GetMoreCashoutTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetMoreCashoutTransactionsDone({required this.transactions});
}

class GetAllWithdrawalsTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetAllWithdrawalsTransactionsDone({required this.transactions});
}

class GetMoreWithdrawalsTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetMoreWithdrawalsTransactionsDone({required this.transactions});
}

class GetAllCashinTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetAllCashinTransactionsDone({required this.transactions});
}

class GetMoreCashinTransactionsDone extends TransactionState {
  final TransactionPagedResponse transactions;
  GetMoreCashinTransactionsDone({required this.transactions});
}

class TransactionsError extends TransactionState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  TransactionsError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class TransactionsLoading extends TransactionState {
  final String loadingText;
  TransactionsLoading({required this.loadingText});
}
