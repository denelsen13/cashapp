import 'package:bloc/bloc.dart';
import 'package:change_money_cashier_app/data/models/responses/transaction_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_cashins_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_cashouts_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_issued_changes_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_payments_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_withdrawals_usecase.dart';
import 'package:equatable/equatable.dart';

part 'transaction_event.dart';
part 'transaction_state.dart';

class TransactionBloc extends Bloc<TransactionEvent, TransactionState> {
  final GetPaymentsUsecase getPaymentsUsecase;
  final GetIssueChangesUsecase getIssueChangesUsecase;
  final GetCashinsUsecase getCashinsUsecase;
  final GetWithdrawalsUsecase getWithdrawalsUsecase;
  final GetCashoutsUsecase getCashoutsUsecase;
  TransactionPagedResponse? transactionsPaged =
      TransactionPagedResponse.empty();
  TransactionBloc({
    required this.getCashinsUsecase,
    required this.getPaymentsUsecase,
    required this.getIssueChangesUsecase,
    required this.getCashoutsUsecase,
    required this.getWithdrawalsUsecase,
  }) : super(TransactionInitial()) {
    on<GetAllIssueChangeTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(
          loadingText: 'Fetching IssueChange Transactions...'));
      final response = await this.getIssueChangesUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetAllIssueChangeTransactionsDone(transactions: orderResult);
        },
      ));
    });
    on<GetMoreIssueChangeTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(
          loadingText: 'Fetching More IssueChange Transactions...'));
      final response = await this.getIssueChangesUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetMoreIssueChangeTransactionsDone(transactions: orderResult);
        },
      ));
    });

    on<GetAllPaymentTransactionsEvent>((event, emit) async {
      emit(
          TransactionsLoading(loadingText: 'Fetching Payment Transactions...'));
      final response = await this.getPaymentsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetAllPaymentTransactionsDone(transactions: orderResult);
        },
      ));
    });
    on<GetMorePaymentTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(loadingText: 'Fetching More Transactions...'));
      final response = await this.getPaymentsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetMorePaymentTransactionsDone(transactions: orderResult);
        },
      ));
    });
    on<GetAllWithdrawalsTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(
          loadingText: 'Fetching Withdrawals Transactions...'));
      final response = await this.getWithdrawalsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetAllWithdrawalsTransactionsDone(transactions: orderResult);
        },
      ));
    });
    on<GetMoreWithdrawalsTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(loadingText: 'Fetching More Transactions...'));
      final response = await this.getWithdrawalsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetMoreWithdrawalsTransactionsDone(transactions: orderResult);
        },
      ));
    });

    on<GetAllCashinTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(loadingText: 'Fetching Cashin Transactions...'));
      final response = await this.getCashinsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetAllCashinTransactionsDone(transactions: orderResult);
        },
      ));
    });
    on<GetMoreCashinTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(
          loadingText: 'Fetching More Cashin Transactions...'));
      final response = await this.getCashinsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetMoreCashinTransactionsDone(transactions: orderResult);
        },
      ));
    });

    on<GetAllCashoutTransactionsEvent>((event, emit) async {
      emit(
          TransactionsLoading(loadingText: 'Fetching Cashout Transactions...'));
      final response = await this.getCashoutsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetAllCashoutTransactionsDone(transactions: orderResult);
        },
      ));
    });
    on<GetMoreCashoutTransactionsEvent>((event, emit) async {
      emit(TransactionsLoading(
          loadingText: 'Fetching More Cashout Transactions...'));
      final response = await this.getCashoutsUsecase(event.pageNumber);
      emit(response.fold(
        (error) {
          return TransactionsError(
            errorMessage: error.message,
            appErrorType: error.appErrorType,
            statusCode: error.status,
          );
        },
        (orderResult) {
          this.transactionsPaged = orderResult;
          return GetMoreCashoutTransactionsDone(transactions: orderResult);
        },
      ));
    });
  }
}
