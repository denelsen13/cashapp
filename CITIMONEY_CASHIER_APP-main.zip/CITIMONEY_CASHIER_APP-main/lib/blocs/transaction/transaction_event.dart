part of 'transaction_bloc.dart';

abstract class TransactionEvent extends Equatable {
  const TransactionEvent();

  @override
  List<Object> get props => [];
}

class GetAllPaymentTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetAllPaymentTransactionsEvent({required this.pageNumber});
}

class GetMorePaymentTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetMorePaymentTransactionsEvent({required this.pageNumber});
}

class GetAllIssueChangeTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetAllIssueChangeTransactionsEvent({required this.pageNumber});
}

class GetMoreIssueChangeTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetMoreIssueChangeTransactionsEvent({required this.pageNumber});
}

class GetAllCashinTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetAllCashinTransactionsEvent({required this.pageNumber});
}

class GetMoreCashinTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetMoreCashinTransactionsEvent({required this.pageNumber});
}

class GetAllWithdrawalsTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetAllWithdrawalsTransactionsEvent({required this.pageNumber});
}

class GetMoreWithdrawalsTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetMoreWithdrawalsTransactionsEvent({required this.pageNumber});
}

class GetAllCashoutTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetAllCashoutTransactionsEvent({required this.pageNumber});
}

class GetMoreCashoutTransactionsEvent extends TransactionEvent {
  final int pageNumber;
  GetMoreCashoutTransactionsEvent({required this.pageNumber});
}
