part of 'socket_bloc.dart';

abstract class SocketEvent extends Equatable {
  const SocketEvent();

  @override
  List<Object> get props => [];
}

class ConnectWebSocketEvent extends SocketEvent {}

class UpdateAppStatusSocketEvent extends SocketEvent {
  final bool isActive;
  UpdateAppStatusSocketEvent({required this.isActive});
}

class UnsubscribeToDriverLocationSocketEvent extends SocketEvent {}

class SendChatMessageSocketEvent extends SocketEvent {
  final ChatMessageRequest request;
  SendChatMessageSocketEvent({required this.request});
}

class NewChatMessageSocketEvent extends SocketEvent {
  final ChatMessageResultModel chatMessage;
  NewChatMessageSocketEvent({required this.chatMessage});
}

class NewNotificationSocketEvent extends SocketEvent {
  final NotificationResultModel notification;
  NewNotificationSocketEvent({required this.notification});
}

class SubscribeToDriverLocationSocketEvent extends SocketEvent {
  final String orderId;
  SubscribeToDriverLocationSocketEvent({required this.orderId});
}

class DisconnectWebSocketEvent extends SocketEvent {}
