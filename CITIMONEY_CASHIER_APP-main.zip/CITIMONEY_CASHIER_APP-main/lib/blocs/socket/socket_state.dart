part of 'socket_bloc.dart';

abstract class SocketState extends Equatable {
  const SocketState();

  @override
  List<Object> get props => [];
}

class SocketInitial extends SocketState {}

class DisconnectWebSocketDone extends SocketState {}

class UpdateAppStatusSocketDone extends SocketState {}

class UpdatedOrderSocketReceivedDone extends SocketState {}

class NewNotificationSocketReceivedDone extends SocketState {}

class SubscribeToDriverLocationSocketDone extends SocketState {}

class UnsubscribeToDriverLocationSocketDone extends SocketState {}

class UpdatedDriverLocationUpdateDone extends SocketState {}

class SendChatMessageSocketDone extends SocketState {}

class NewChatMessageSocketDone extends SocketState {
  final ChatMessageResultModel chatMessage;
  NewChatMessageSocketDone({required this.chatMessage});
}

class NewNotificationSocketDone extends SocketState {
  final NotificationResultModel notification;
  NewNotificationSocketDone({required this.notification});
}

class ConnectWebSocketDone extends SocketState {}

class SocketMessageReceived extends SocketState {}

class SocketMessageReceivedDone extends SocketState {}
