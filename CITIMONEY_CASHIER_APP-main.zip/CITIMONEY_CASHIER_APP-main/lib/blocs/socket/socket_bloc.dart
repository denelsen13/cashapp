import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:change_money_cashier_app/utils/string_utils.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:stomp_dart_client/stomp.dart';
import 'package:stomp_dart_client/stomp_config.dart';
import 'package:stomp_dart_client/stomp_frame.dart';

import '../../data/core/api_constants.dart';
import '../../data/data_sources/shared_preference.dart';
import '../../data/models/chat_message_result_model.dart';
import '../../data/models/notification_result_model.dart';
import '../../data/models/requests/chat_message_request.dart';
import '../../di/get_it.dart';
import '../../utils/colors.dart';
import '../../utils/navigation_service.dart';
import '../../widgets/show_error_message.dart';
import '../notification/notification_bloc.dart';

part 'socket_event.dart';
part 'socket_state.dart';

class SocketBloc extends Bloc<SocketEvent, SocketState> {
  StompClient? client;
  String accessToken = '';
  String? notificationTopic;
  String? exchangeRateTopic;
  String? chatSendTopic = '/app/customerChatMessages';
  String? chatMessagesTopic;
  bool isSubscribed = false;
  bool isActive = false;
  String? userSpecificTopic;
  String? userOrderSpecificTopic;
  String? userOrderDriverLocationSpecificTopic;
  String? broadCastTopic;
  String? groupTopic;
  String? userId;
  String? webSocketMessageGroup = 'CUSTOMERS';
  VoidCallback? exchangeRateUnsubscribeFn = () {};
  VoidCallback? chatMessagesUnsubscribeFn = () {};
  VoidCallback? driverLocationUnsubscribeFn = () {};
  VoidCallback? broadcastUnsubscribeFn = () {};
  VoidCallback? notificationUnsubscribeFn = () {};
  VoidCallback? userUnsubscribeFn = () {};
  VoidCallback? userOrderUnsubscribeFn = () {};
  VoidCallback? groupUnsubscribeFn = () {};
  SocketBloc() : super(SocketInitial()) {
    on<SocketEvent>((event, emit) {
      on<SendChatMessageSocketEvent>((event, emit) async {
        this.sendMessage(event.request);
        emit(SendChatMessageSocketDone());
      });
      on<ConnectWebSocketEvent>((event, emit) async {
        this.connectWebSocket();
        emit(ConnectWebSocketDone());
      });
      on<UpdateAppStatusSocketEvent>((event, emit) async {
        this.isActive = event.isActive;
        emit(UpdateAppStatusSocketDone());
      });
      on<UnsubscribeToDriverLocationSocketEvent>((event, emit) async {
        this.unsubscribeToRderDriverLocation();
        emit(UnsubscribeToDriverLocationSocketDone());
      });
      on<SubscribeToDriverLocationSocketEvent>((event, emit) async {
        this.subscribeToDriverLocation(event.orderId);
        emit(SubscribeToDriverLocationSocketDone());
      });
      on<DisconnectWebSocketEvent>((event, emit) async {
        this.disconnect();
        emit(DisconnectWebSocketDone());
      });

      on<NewChatMessageSocketEvent>((event, emit) async {
        if (!event.chatMessage.isFromCustomer) {
          this.sendNotification(
            event.chatMessage.message,
            'New Message',
            'NEW_CHAT_MESSAGE',
          );
          getItInstance<NotificationBloc>().add(AddToCurrentUreadCountEvent());
        }
        emit(NewChatMessageSocketDone(
          chatMessage: event.chatMessage,
        ));
      });
      on<NewNotificationSocketEvent>((event, emit) async {
        this.sendNotification(
          event.notification.message,
          event.notification.title,
          'NEW_NOTIFICATION',
        );
        getItInstance<NotificationBloc>().add(AddToCurrentUreadCountEvent());
        emit(NewNotificationSocketDone(
          notification: event.notification,
        ));
      });
    });
  }

  sendMessage(ChatMessageRequest request) {
    print('this is our endpoint..........${chatSendTopic}');
    this.client!.send(
          destination: this.chatSendTopic!,
          body: jsonEncode(request.toJson()),
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
        );
  }

  void sendNotification(String message, String title, String payload) {
    this.isActive
        ? showErrorMessage(
            getItInstance<NavigationService>().navigationKey!.currentContext!,
            message: message.trimString(100),
            title: title,
            backgroundColor: secondaryColor,
          )
        : getItInstance<NotificationBloc>().add(ShowNotificationEvent(
            message: message, title: title, payload: payload));
  }

  void connectWebSocket() async {
    if (this.client == null || !this.client!.connected) {
      SharedPreferenceUtil sharedPreferencesUtil =
          getItInstance<SharedPreferenceUtil>();
      this.userId = await sharedPreferencesUtil.getUserId();
      this.accessToken = await sharedPreferencesUtil.getAccessToken();

      this.chatMessagesTopic = '/user/$userId/chatMessages';
      this.notificationTopic = '/notifications/$userId';
      this.notificationTopic = '/notifications/$userId';
      this.exchangeRateTopic = '/exchangeRate/';
      this.userSpecificTopic = '/user/$userId/msg';
      this.userOrderSpecificTopic = '/user/$userId/order';
      this.broadCastTopic = '/b';
      this.groupTopic = '/g/$webSocketMessageGroup';

      this.client = StompClient(
        config: StompConfig.SockJS(
          url: '${ApiConstants.SOCKET_URL}/ws',
          webSocketConnectHeaders: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          stompConnectHeaders: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          onConnect: onConnect,
          onDisconnect: (stompFrame) {
            print(
                '#################DisConnected from Web Sockets........$stompFrame');
          },
          onStompError: (stompFrame) {
            print('#################Stomp error........${stompFrame.command}');
            print('#################Stomp error........${stompFrame.headers}');
            print('#################Stomp error........${stompFrame.body}');
            print(
                '#################Stomp error........${stompFrame.binaryBody}');
          },
          onWebSocketError: (stompFrame) {
            print('#################Web Socket error........$stompFrame');
          },
        ),
      );
      this.client!.activate();
    }
  }

  disconnect() {
    this.broadcastUnsubscribeFn!();
    this.notificationUnsubscribeFn!();
    this.userUnsubscribeFn!();
    this.userOrderUnsubscribeFn!();
    this.groupUnsubscribeFn!();
    this.exchangeRateUnsubscribeFn!();
    this.client!.deactivate();
  }

  subscribeToDriverLocation(String orderId) {
    this.userOrderDriverLocationSpecificTopic =
        '/user/$userId/driverLocation/$orderId';

    this.driverLocationUnsubscribeFn = this.client!.subscribe(
          destination: this.userOrderDriverLocationSpecificTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );
  }

  unsubscribeToRderDriverLocation() {
    this.driverLocationUnsubscribeFn!();
  }

  onConnect(stompFrame) {
    print('#################Connected Info........${stompFrame.command}');
    print('#################Connected Info........${stompFrame.headers}');

    this.broadcastUnsubscribeFn = this.client!.subscribe(
          destination: this.broadCastTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );
    this.chatMessagesUnsubscribeFn = this.client!.subscribe(
          destination: this.chatMessagesTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );
    this.exchangeRateUnsubscribeFn = this.client!.subscribe(
          destination: this.exchangeRateTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );
    this.notificationUnsubscribeFn = this.client!.subscribe(
          destination: this.notificationTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );

    this.userOrderUnsubscribeFn = this.client!.subscribe(
          destination: this.userOrderSpecificTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );
    this.userUnsubscribeFn = this.client!.subscribe(
          destination: this.userSpecificTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );

    this.groupUnsubscribeFn = this.client!.subscribe(
          destination: this.groupTopic!,
          headers: this.accessToken.isNotEmpty
              ? {"Authorization": this.accessToken}
              : {},
          callback: (frame) {
            this.onMessageReceived(frame);
          },
        );
  }

  onMessageReceived(StompFrame frame) {
    print('message...........................................$frame');
    if (frame.headers.isNotEmpty) {
      frame.headers.entries.forEach((element) {
        if (element.key == 'destination' &&
            element.value == this.chatMessagesTopic) {
          this.sortNewchatMessage(frame.body);
        }
        if (element.key == 'destination' &&
            element.value == this.notificationTopic) {
          this.sortNewNotification(frame.body);
        }
        if (element.key == 'destination' &&
            element.value == this.userSpecificTopic) {
          this.sortNewUserSpecificNotification(frame.body);
        }

        if (element.key == 'destination' &&
            element.value == this.broadCastTopic) {
          this.sortNewBroadcastNotification(frame.body);
        }
        if (element.key == 'destination' && element.value == this.groupTopic) {
          this.sortNewGroupNotification(frame.body);
        }
      });
    }
  }

  sortNewchatMessage(String? body) {
    print('Received New Notification.......$body');
    ChatMessageResultModel chatMessage =
        ChatMessageResultModel.fromJson(jsonDecode(body!));

    this.add(
      NewChatMessageSocketEvent(
        chatMessage: chatMessage,
      ),
    );
  }

  sortNewNotification(String? body) {
    print('Received New Notification.......$body');
    NotificationResultModel notification =
        NotificationResultModel.fromJson(jsonDecode(body!));

    this.add(
      NewNotificationSocketEvent(
        notification: notification,
      ),
    );
  }

  sortNewUserSpecificNotification(String? body) {
    print('Received New User Specific Notification.......$body');
    NotificationResultModel notification =
        NotificationResultModel.fromJson(jsonDecode(body!));

    this.add(
      NewNotificationSocketEvent(
        notification: notification,
      ),
    );
  }

  sortNewBroadcastNotification(String? body) {
    print('Received New Broadcast Notification.......$body');
    NotificationResultModel notification =
        NotificationResultModel.fromJson(jsonDecode(body!));

    this.add(
      NewNotificationSocketEvent(
        notification: notification,
      ),
    );
  }

  sortNewGroupNotification(String? body) {
    print('Received New Group Notification.......$body');
    NotificationResultModel notification =
        NotificationResultModel.fromJson(jsonDecode(body!));

    this.add(
      NewNotificationSocketEvent(
        notification: notification,
      ),
    );
  }
}
