import 'package:bloc/bloc.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../../data/data_sources/shared_preference.dart';
import '../../di/get_it.dart';
import '../../routes/route_constants.dart';
import '../../utils/navigation_service.dart';

part 'splash_event.dart';
part 'splash_state.dart';

class SplashBloc extends Bloc<SplashEvent, SplashState> {
  SplashBloc() : super(SplashInitial()) {
    on<SplashLoadEvent>((event, emit) async {
      print('Tapinda Mu Load......................................');
      final today = DateTime.now();
      final expiryDate = DateTime.utc(2022, 6, 10);
      if (diffInDays(expiryDate, today) <= 0) {
        getItInstance<NavigationService>()
            .navigateToReplacement(RouteList.expiry);
        emit(SplashLoadDone());
      } else {
        SharedPreferenceUtil sharedPreferencesUtil =
            getItInstance<SharedPreferenceUtil>();
        String accessToken = await sharedPreferencesUtil.getAccessToken();
        if (accessToken.isNotEmpty) {
          String userGroup = await sharedPreferencesUtil.getRole();
          if (userGroup == 'ROLE_CASHIER') {
            getItInstance<NavigationService>()
                .navigateToReplacement(RouteList.home);
          } else {
            getItInstance<NavigationService>()
                .navigateToReplacement(RouteList.tellerHome);
          }

          emit(SplashLoadDone());
        } else {
          getItInstance<NavigationService>()
              .navigateToReplacement(RouteList.login);
          emit(SplashLoadDone());
        }
      }
    });
  }
  int diffInDays(DateTime date1, DateTime date2) {
    return ((date1.difference(date2) -
                    Duration(hours: date1.hour) +
                    Duration(hours: date2.hour))
                .inHours /
            24)
        .round();
  }
}
