part of 'splash_bloc.dart';

abstract class SplashState extends Equatable {
  const SplashState();

  @override
  List<Object> get props => [];
}

class SplashInitial extends SplashState {}

class SplashErrorDone extends SplashState {}

class SplashLoadDone extends SplashState {}

class SplashError extends SplashState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  SplashError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class SplashLoading extends SplashState {
  final String loadingText;
  SplashLoading({required this.loadingText});
}
