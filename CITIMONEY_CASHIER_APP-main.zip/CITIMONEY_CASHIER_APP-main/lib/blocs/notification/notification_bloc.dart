import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../../data/models/notification_result_model.dart';
import '../../data/models/received_notification.dart';
import '../../data/models/requests/update_notifications_read_status_request.dart';
import '../../data/models/responses/notification_paged_response.dart';
import '../../di/get_it.dart';
import '../../domain/entities/app_error.dart';
import '../../domain/usecases/notifications/load_notifications_usecase.dart';
import '../../domain/usecases/notifications/update_notifications_read_status_usecase.dart';
import '../../domain/usecases/notifications/update_single_notification_read_status_usecase.dart';
import '../../routes/route_constants.dart';
import '../../utils/navigation_service.dart';

part 'notification_event.dart';
part 'notification_state.dart';

class NotificationBloc extends Bloc<NotificationEvent, NotificationState> {
  final LoadAllNotificationsUsecase loadAllNotificationsUsecase;
  final UpdateSingleNotificationsReadStatusUsecase
      updateSingleNotificationsReadStatusUsecase;
  final UpdateNotificationsReadStatusUsecase
      updateNotificationsReadStatusUsecase;

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  ReceivedNotification? currentNotification;
  ReceivedNotification? selectedNotification;
  String? selectedNotificationPayload;
  NotificationPagedResponse? notificationsPaged =
      NotificationPagedResponse.empty();

  int unreadCount = 0;
  NotificationBloc(
      {required this.loadAllNotificationsUsecase,
      required this.updateSingleNotificationsReadStatusUsecase,
      required this.updateNotificationsReadStatusUsecase})
      : super(NotificationInitial()) {
    on<NotificationEvent>((event, emit) {
      on<GetCurrentUreadCountEvent>((event, emit) async {
        emit(GetCurrentUreadCountDone(unreadCount: this.unreadCount));
      });
      on<AddToCurrentUreadCountEvent>((event, emit) async {
        this.unreadCount = this.unreadCount + 1;
        emit(UpdateCurrentUreadCountDone(unreadCount: this.unreadCount));
      });
      on<UpdateCurrentUreadCountEvent>((event, emit) async {
        this.unreadCount = event.unreadCount;
        emit(UpdateCurrentUreadCountDone(unreadCount: event.unreadCount));
      });
      on<UpdateNotificationsReadStatusEvent>((event, emit) async {
        emit(
            NotificationsMarkLoading(loadingText: 'Updating Notifications...'));
        final response =
            await this.updateNotificationsReadStatusUsecase(event.request);
        emit(response.fold(
          (error) {
            return NotificationsError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (orderResult) {
            this.unreadCount = 0;
            return UpdateNotificationsReadStatusDone();
          },
        ));
      });
      on<UpdateSingleNotificationsReadStatusEvent>((event, emit) async {
        final response = await this
            .updateSingleNotificationsReadStatusUsecase(event.notificationId);
        emit(response.fold(
          (error) {
            return NotificationsError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (orderResult) {
            this.unreadCount = this.unreadCount - 1;
            return UpdateSingleNotificationsReadStatusDone(
                notificationId: event.notificationId);
          },
        ));
      });
      on<GetAllNotificationsEvent>((event, emit) async {
        emit(NotificationsLoading(loadingText: 'Fetching Notifications...'));
        final response =
            await this.loadAllNotificationsUsecase(event.pageNumber);
        emit(response.fold(
          (error) {
            return NotificationsError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (orderResult) {
            this.notificationsPaged = orderResult;
            return GetAllNotificationsDone(notifications: orderResult);
          },
        ));
      });
      on<GetMoreNotificationsEvent>((event, emit) async {
        emit(NotificationsLoading(
            loadingText: 'Fetching More Notifications...'));
        final response =
            await this.loadAllNotificationsUsecase(event.pageNumber);
        emit(response.fold(
          (error) {
            return NotificationsError(
              errorMessage: error.message,
              appErrorType: error.appErrorType,
              statusCode: error.status,
            );
          },
          (orderResult) {
            this.notificationsPaged = orderResult;
            return GetMoreNotificationsDone(notifications: orderResult);
          },
        ));
      });
      on<InitializeNotificationsEvent>((event, emit) async {
        this.initializeNotifications();
        emit(InitializeNotificationsDone());
      });
      on<ShowNotificationEvent>((event, emit) async {
        this._showNotification(
          id: 0,
          title: event.title,
          body: event.message,
          payload: event.payload,
        );
        emit(ShowNotificationDone());
      });
    });
  }

  Future<void> _showNotification(
      {int id = 0, String? title, String? body, String? payload}) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails('your channel id', 'your channel name',
            importance: Importance.max,
            priority: Priority.high,
            ticker: 'ticker');
    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin
        .show(id, title, body, platformChannelSpecifics, payload: payload);
  }

  Future<void> _cancelNotification(int id) async {
    await flutterLocalNotificationsPlugin.cancel(id);
  }

  Future<void> _showNotificationCustomSound(
      {int id = 0, String? title, String? body}) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'your other channel id',
      'your other channel name',
      sound: RawResourceAndroidNotificationSound('slow_spring_board'),
    );
    const IOSNotificationDetails iOSPlatformChannelSpecifics =
        IOSNotificationDetails(sound: 'slow_spring_board.aiff');

    final NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
      iOS: iOSPlatformChannelSpecifics,
    );
    await flutterLocalNotificationsPlugin.show(
      id,
      title,
      body,
      platformChannelSpecifics,
    );
  }

  initializeNotifications() async {
    await flutterLocalNotificationsPlugin.getNotificationAppLaunchDetails();

    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings(
      'notification_icon',
    );

    /// Note: permissions aren't requested here just to demonstrate that can be
    /// done later
    final IOSInitializationSettings initializationSettingsIOS =
        IOSInitializationSettings(
            requestAlertPermission: true,
            requestBadgePermission: true,
            requestSoundPermission: true,
            onDidReceiveLocalNotification: (
              int id,
              String? title,
              String? body,
              String? payload,
            ) async {
              this.currentNotification = ReceivedNotification(
                id: id,
                title: title,
                body: body,
                payload: payload,
              );
            });

    final InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );
    await flutterLocalNotificationsPlugin.initialize(initializationSettings,
        onSelectNotification: (String? payload) async {
      if (payload != null) {
        if (payload == 'NEW_CHAT_MESSAGE') {
          getItInstance<NavigationService>().navigateTo(RouteList.chat);
        }
        if (payload == 'NEW_NOTIFICATION') {
          getItInstance<NavigationService>()
              .navigateTo(RouteList.notifications);
        }
      }
      this.selectedNotificationPayload = payload;
      this.selectedNotification = ReceivedNotification(
        id: 0,
        title: '',
        body: '',
        payload: payload,
      );
    });
  }
}
