part of 'notification_bloc.dart';

abstract class NotificationEvent extends Equatable {
  const NotificationEvent();

  @override
  List<Object> get props => [];
}

class InitializeNotificationsEvent extends NotificationEvent {}

class AddToCurrentUreadCountEvent extends NotificationEvent {}

class UpdateCurrentUreadCountEvent extends NotificationEvent {
  final int unreadCount;
  UpdateCurrentUreadCountEvent({required this.unreadCount});
}

class GetCurrentUreadCountEvent extends NotificationEvent {}

class NewNotificationSocketEvent extends NotificationEvent {
  final NotificationResultModel notification;
  NewNotificationSocketEvent({required this.notification});
}

class UpdateSingleNotificationsReadStatusEvent extends NotificationEvent {
  final int notificationId;
  UpdateSingleNotificationsReadStatusEvent({required this.notificationId});
}

class UpdateNotificationsReadStatusEvent extends NotificationEvent {
  final UpdateNotificationsReadStatusRequest request;
  UpdateNotificationsReadStatusEvent({required this.request});
}

class GetAllNotificationsEvent extends NotificationEvent {
  final int pageNumber;
  GetAllNotificationsEvent({required this.pageNumber});
}

class GetMoreNotificationsEvent extends NotificationEvent {
  final int pageNumber;
  GetMoreNotificationsEvent({required this.pageNumber});
}

class ShowNotificationEvent extends NotificationEvent {
  final String message;
  final String title;
  final String payload;
  ShowNotificationEvent({
    required this.message,
    required this.title,
    required this.payload,
  });
}
