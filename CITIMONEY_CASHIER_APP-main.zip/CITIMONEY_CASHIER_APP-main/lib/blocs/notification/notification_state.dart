part of 'notification_bloc.dart';

abstract class NotificationState extends Equatable {
  const NotificationState();

  @override
  List<Object> get props => [];
}

class NotificationInitial extends NotificationState {}

class ShowNotificationDone extends NotificationState {}

class FetchUpdatedDone extends NotificationState {}

class NotificationsErrorDone extends NotificationState {}

class InitializeNotificationsDone extends NotificationState {}

class UpdateSingleNotificationsReadStatusDone extends NotificationState {
  final int notificationId;
  UpdateSingleNotificationsReadStatusDone({required this.notificationId});
}

class UpdateCurrentUreadCountDone extends NotificationState {
  final int unreadCount;
  UpdateCurrentUreadCountDone({required this.unreadCount});
}

class GetCurrentUreadCountDone extends NotificationState {
  final int unreadCount;
  GetCurrentUreadCountDone({required this.unreadCount});
}

class UpdateNotificationsReadStatusDone extends NotificationState {}

class GetAllNotificationsDone extends NotificationState {
  final NotificationPagedResponse notifications;
  GetAllNotificationsDone({required this.notifications});
}

class GetMoreNotificationsDone extends NotificationState {
  final NotificationPagedResponse notifications;
  GetMoreNotificationsDone({required this.notifications});
}

class NotificationsError extends NotificationState {
  final String? errorMessage;
  final AppErrorType? appErrorType;
  final int? statusCode;
  NotificationsError({this.errorMessage, this.appErrorType, this.statusCode});
  @override
  List<Object> get props => [errorMessage!, appErrorType!];
}

class NotificationsLoading extends NotificationState {
  final String loadingText;
  NotificationsLoading({required this.loadingText});
}

class NotificationsMarkLoading extends NotificationState {
  final String loadingText;
  NotificationsMarkLoading({required this.loadingText});
}
