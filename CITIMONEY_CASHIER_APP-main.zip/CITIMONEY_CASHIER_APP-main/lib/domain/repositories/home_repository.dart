import 'package:change_money_cashier_app/data/models/check_customer_result_model.dart';
import 'package:change_money_cashier_app/data/models/check_teller_result_model.dart';
import 'package:change_money_cashier_app/data/models/recent_transactions_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashin_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashin_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_issue_change_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_withdrawal_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_transfer_response.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/transaction_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/entities/transaction_entity.dart';
import 'package:dartz/dartz.dart';

abstract class HomeRepository {
  Future<Either<AppError, CheckTellerResultModel>> checkTeller();
  Future<Either<AppError, CheckCashierResultModel>> checkCashier();
  Future<Either<AppError, List<TransactionEntity>>>
      getTellerRecentTransactions();
  Future<Either<AppError, List<TransactionEntity>>> getRecentTransactions();
  Future<Either<AppError, List<CurrencyResponse>>> getCurrencies();
  Future<Either<AppError, CheckCashinResponse>> checkCashin(
      CheckCashinRequestDTO request);
  Future<Either<AppError, CheckCashoutResponse>> checkCashout(
      CheckCashoutRequestDTO request);
  Future<Either<AppError, CheckWithdrawalResponse>> checkWithdrawal(
      CheckWithdrawalRequestDTO request);
  Future<Either<AppError, CheckIssueChangeResponse>> checkIssueChange(
      CheckIssueChangeRequestDTO request);
  Future<Either<AppError, CheckWithdrawalResponse>> confirmWithdrawal(
      ConfirmWithdrawalRequestDTO request);
  Future<Either<AppError, CheckCashinResponse>> confirmCashin(
      ConfirmCashinRequestDTO request);
  Future<Either<AppError, ConfirmCashoutResponse>> confirmCashout(
      ConfirmCashoutRequestDTO request);
  Future<Either<AppError, CheckIssueChangeResponse>> confirmIssueChange(
      ConfirmIssueChangeRequestDTO request);

  Future<Either<AppError, TransactionPagedResponse>> getCashins(int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getCashouts(
      int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getWithdrawals(
      int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getPayments(
      int pageNumber);
  Future<Either<AppError, TransactionPagedResponse>> getIssueChanges(
      int pageNumber);
}
