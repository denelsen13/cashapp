import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/login_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/update_profile_request.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';

abstract class UserRepository {
  Future<Either<AppError, NoResponse>> updateProfile(
      UpdateProfileRequestDTO request);
  Future<Either<AppError, LoginResultModel>> fetchProfile(NoParams noParams);
}
