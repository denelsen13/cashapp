import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/requests/update_notifications_read_status_request.dart';
import 'package:change_money_cashier_app/data/models/responses/notification_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';

abstract class NotificationRepository {
  Future<Either<AppError, NotificationPagedResponse>> getAllNotifications(
      int pageNumber);
  Future<Either<AppError, NoResponse>> updateSingleNotificationReadStatus(
      int notificationId);

  Future<Either<AppError, NoResponse>> updateReadStatus(
      UpdateNotificationsReadStatusRequest request);
}
