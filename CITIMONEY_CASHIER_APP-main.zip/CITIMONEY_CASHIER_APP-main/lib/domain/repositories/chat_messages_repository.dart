import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/responses/chat_message_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';

abstract class ChatMessagesRepository {
  Future<Either<AppError, ChatMessagePagedResponse>> getAllChatMessages(
      int pageNumber);
}
