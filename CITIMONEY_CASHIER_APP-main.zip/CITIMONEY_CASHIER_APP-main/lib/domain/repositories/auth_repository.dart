import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/login_request_dto.dart';
import 'package:change_money_cashier_app/data/models/login_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/change_password_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/instant_change_password_request_dto.dart';
import 'package:change_money_cashier_app/data/models/signup_request.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';

abstract class AuthRepository {
  Future<Either<AppError, LoginResultModel>> changePassword(
      ChangePasswordRequestDTO request);
  Future<Either<AppError, LoginResultModel>> instantChangePassword(
      InstantChangePasswordRequestDTO request);
  Future<Either<AppError, LoginResultModel>> login(LoginRequestDTO request);
  Future<Either<AppError, NoResponse>> signup(SignupRequestDTO request);
  Future<Either<AppError, NoResponse>> resetPassword(String phonenumber);
  Future<Either<AppError, NoResponse>> resendOtp(String phonenumber);
  Future<Either<AppError, LoginResultModel>> resetPasswordVerifyOtp(String otp);
  Future<Either<AppError, LoginResultModel>> verifyOtp(String otp);
}
