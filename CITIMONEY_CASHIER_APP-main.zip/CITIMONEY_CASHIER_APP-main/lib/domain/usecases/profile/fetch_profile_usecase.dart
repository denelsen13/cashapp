import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/repositories/user_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class FetchProfileUsecase extends Usecase<LoginEntity, NoParams> {
  final UserRepository userRepository;
  FetchProfileUsecase(this.userRepository);

  @override
  Future<Either<AppError, LoginEntity>> call(NoParams noParams) async {
    return await userRepository.fetchProfile(noParams);
  }
}
