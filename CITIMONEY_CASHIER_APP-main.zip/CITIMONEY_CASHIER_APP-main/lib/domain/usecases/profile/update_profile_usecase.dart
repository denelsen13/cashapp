import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/requests/update_profile_request.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/user_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class UpdateProfileUsecase
    extends Usecase<NoResponse, UpdateProfileRequestDTO> {
  final UserRepository userRepository;
  UpdateProfileUsecase(this.userRepository);

  @override
  Future<Either<AppError, NoResponse>> call(
      UpdateProfileRequestDTO request) async {
    return await userRepository.updateProfile(request);
  }
}
