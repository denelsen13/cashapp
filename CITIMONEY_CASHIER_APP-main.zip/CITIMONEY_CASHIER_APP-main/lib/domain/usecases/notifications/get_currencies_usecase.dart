import 'package:change_money_cashier_app/data/models/recent_transactions_result_model.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/entities/recent_transactions_entity.dart';
import 'package:change_money_cashier_app/domain/entities/transaction_entity.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';
import 'package:dartz/dartz.dart';

class GetCurrenciesUsecase extends Usecase<List<CurrencyResponse>, NoParams> {
  final HomeRepository homeRepository;
  GetCurrenciesUsecase(this.homeRepository);

  @override
  Future<Either<AppError, List<CurrencyResponse>>> call(
      NoParams noParams) async {
    return await homeRepository.getCurrencies();
  }
}
