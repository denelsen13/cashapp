import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/responses/notification_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/repositories/notification_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class LoadAllNotificationsUsecase
    extends Usecase<NotificationPagedResponse, int> {
  final NotificationRepository notificationRepository;
  LoadAllNotificationsUsecase(this.notificationRepository);

  @override
  Future<Either<AppError, NotificationPagedResponse>> call(
      int pageNumber) async {
    return await notificationRepository.getAllNotifications(pageNumber);
  }
}
