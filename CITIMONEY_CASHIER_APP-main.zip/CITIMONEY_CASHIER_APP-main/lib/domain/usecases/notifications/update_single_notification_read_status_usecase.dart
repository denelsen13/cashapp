import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/responses/notification_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/notification_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class UpdateSingleNotificationsReadStatusUsecase
    extends Usecase<NoResponse, int> {
  final NotificationRepository notificationRepository;
  UpdateSingleNotificationsReadStatusUsecase(this.notificationRepository);

  @override
  Future<Either<AppError, NoResponse>> call(int notificationId) async {
    return await notificationRepository
        .updateSingleNotificationReadStatus(notificationId);
  }
}
