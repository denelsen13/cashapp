import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class ResetPasswordUsecase extends Usecase<NoResponse, String> {
  final AuthRepository authRepository;
  ResetPasswordUsecase(this.authRepository);

  @override
  Future<Either<AppError, NoResponse>> call(String phonenumber) async {
    return await authRepository.resetPassword(phonenumber);
  }
}
