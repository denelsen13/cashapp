import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/login_request_dto.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class LoginUsecase extends Usecase<LoginEntity, LoginRequestDTO> {
  final AuthRepository authRepository;
  LoginUsecase(this.authRepository);

  @override
  Future<Either<AppError, LoginEntity>> call(LoginRequestDTO request) async {
    return await authRepository.login(request);
  }
}
