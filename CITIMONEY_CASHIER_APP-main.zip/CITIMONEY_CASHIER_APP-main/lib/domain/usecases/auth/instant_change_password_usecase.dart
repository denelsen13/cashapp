import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/login_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/instant_change_password_request_dto.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class InstantChangePasswordUsecase
    extends Usecase<LoginResultModel, InstantChangePasswordRequestDTO> {
  final AuthRepository authRepository;
  InstantChangePasswordUsecase(this.authRepository);

  @override
  Future<Either<AppError, LoginResultModel>> call(
      InstantChangePasswordRequestDTO request) async {
    return await authRepository.instantChangePassword(request);
  }
}
