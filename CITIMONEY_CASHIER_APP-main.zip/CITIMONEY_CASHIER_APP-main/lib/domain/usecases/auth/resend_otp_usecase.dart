import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class ResendOtpUsecase extends Usecase<NoResponse, String> {
  final AuthRepository authRepository;
  ResendOtpUsecase(this.authRepository);

  @override
  Future<Either<AppError, NoResponse>> call(String phonenumber) async {
    return await authRepository.resendOtp(phonenumber);
  }
}
