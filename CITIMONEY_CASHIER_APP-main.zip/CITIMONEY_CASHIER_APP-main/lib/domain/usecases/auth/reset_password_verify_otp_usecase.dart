import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class ResetPasswordVerifyOtpUsecase extends Usecase<LoginEntity, String> {
  final AuthRepository authRepository;
  ResetPasswordVerifyOtpUsecase(this.authRepository);

  @override
  Future<Either<AppError, LoginEntity>> call(String otp) async {
    return await authRepository.resetPasswordVerifyOtp(otp);
  }
}
