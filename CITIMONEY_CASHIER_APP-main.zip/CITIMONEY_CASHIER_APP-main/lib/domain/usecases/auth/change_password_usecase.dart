import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/login_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/change_password_request_dto.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';
import 'package:change_money_cashier_app/domain/entities/no_response.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class ChangePasswordUsecase
    extends Usecase<LoginEntity, ChangePasswordRequestDTO> {
  final AuthRepository authRepository;
  ChangePasswordUsecase(this.authRepository);

  @override
  Future<Either<AppError, LoginEntity>> call(
      ChangePasswordRequestDTO request) async {
    return await authRepository.changePassword(request);
  }
}
