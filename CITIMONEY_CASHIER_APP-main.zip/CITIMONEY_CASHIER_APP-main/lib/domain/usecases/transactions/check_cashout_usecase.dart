import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashout_response.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class CheckCashoutUsecase
    extends Usecase<CheckCashoutResponse, CheckCashoutRequestDTO> {
  final HomeRepository homeRepository;
  CheckCashoutUsecase(this.homeRepository);

  @override
  Future<Either<AppError, CheckCashoutResponse>> call(
      CheckCashoutRequestDTO request) async {
    return await homeRepository.checkCashout(request);
  }
}
