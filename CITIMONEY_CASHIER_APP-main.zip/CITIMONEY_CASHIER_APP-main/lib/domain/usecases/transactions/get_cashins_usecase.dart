import 'package:change_money_cashier_app/data/models/responses/transaction_paged_response.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/responses/notification_paged_response.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/repositories/notification_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class GetCashinsUsecase extends Usecase<TransactionPagedResponse, int> {
  final HomeRepository homeRepository;
  GetCashinsUsecase(this.homeRepository);

  @override
  Future<Either<AppError, TransactionPagedResponse>> call(
      int pageNumber) async {
    return await homeRepository.getCashins(pageNumber);
  }
}
