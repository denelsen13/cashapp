import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/check_customer_entity.dart';
import 'package:change_money_cashier_app/domain/entities/no_params.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';
import 'package:dartz/dartz.dart';

class GetFloatBalanceUsecase extends Usecase<CheckCashierEntity, NoParams> {
  final HomeRepository homeRepository;
  GetFloatBalanceUsecase(this.homeRepository);

  @override
  Future<Either<AppError, CheckCashierEntity>> call(NoParams noParams) async {
    return await homeRepository.checkCashier();
  }
}
