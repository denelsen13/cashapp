import 'package:change_money_cashier_app/data/models/requests/check_issue_change_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/responses/check_issue_change_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_payment_response.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/data/models/login_request_dto.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/entities/login_entity.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class CheckIssueChangeUsecase
    extends Usecase<CheckIssueChangeResponse, CheckIssueChangeRequestDTO> {
  final HomeRepository homeRepository;
  CheckIssueChangeUsecase(this.homeRepository);

  @override
  Future<Either<AppError, CheckIssueChangeResponse>> call(
      CheckIssueChangeRequestDTO request) async {
    return await homeRepository.checkIssueChange(request);
  }
}
