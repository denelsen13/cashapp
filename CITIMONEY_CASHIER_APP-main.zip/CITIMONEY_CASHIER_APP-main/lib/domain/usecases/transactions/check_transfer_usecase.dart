import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_transfer_request.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashin_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_cashout_response.dart';
import 'package:change_money_cashier_app/data/models/responses/check_transfer_response.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class CheckCashinUsecase
    extends Usecase<CheckCashinResponse, CheckCashinRequestDTO> {
  final HomeRepository homeRepository;
  CheckCashinUsecase(this.homeRepository);

  @override
  Future<Either<AppError, CheckCashinResponse>> call(
      CheckCashinRequestDTO request) async {
    return await homeRepository.checkCashin(request);
  }
}
