import 'package:change_money_cashier_app/data/models/requests/check_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/responses/check_withdrawal_response.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/domain/usecases/usecase.dart';

class CheckWithdrawalUsecase
    extends Usecase<CheckWithdrawalResponse, CheckWithdrawalRequestDTO> {
  final HomeRepository homeRepository;
  CheckWithdrawalUsecase(this.homeRepository);

  @override
  Future<Either<AppError, CheckWithdrawalResponse>> call(
      CheckWithdrawalRequestDTO request) async {
    return await homeRepository.checkWithdrawal(request);
  }
}
