import 'package:equatable/equatable.dart';

class CheckTellerEntity extends Equatable {
  final String msisdn;
  final String id;
  final double totalWithdrawal;
  CheckTellerEntity(
      {required this.totalWithdrawal, required this.id, required this.msisdn});
  @override
  List<Object> get props => throw UnimplementedError();
}
