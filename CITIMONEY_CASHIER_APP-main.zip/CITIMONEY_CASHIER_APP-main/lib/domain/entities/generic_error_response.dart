import 'package:equatable/equatable.dart';

class GenericErrorResponse extends Equatable {
  final String status;
  final String error;
  final int code;
  GenericErrorResponse(
      {required this.status, required this.error, required this.code});

  factory GenericErrorResponse.fromJson(Map<String, dynamic> json) {
    return GenericErrorResponse(
      status: json['status'],
      error: json['error'],
      code: json['code'],
    );
  }
  @override
  List<Object> get props => [];
}
