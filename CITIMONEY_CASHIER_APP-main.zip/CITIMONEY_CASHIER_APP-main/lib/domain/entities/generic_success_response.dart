import 'package:equatable/equatable.dart';

class GenericSuccessResponse extends Equatable {
  final String status;
  final String message;
  GenericSuccessResponse({required this.status, required this.message});

  factory GenericSuccessResponse.fromJson(Map<String, dynamic> json) {
    return GenericSuccessResponse(
      status: json['status'],
      message: json['message'],
    );
  }
  @override
  List<Object> get props => [];
}
