import 'package:change_money_cashier_app/data/models/enums/transaction_status.dart';
import 'package:change_money_cashier_app/data/models/enums/transaction_type.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/responses/financial_institution_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_branch_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_cashier_response.dart';
import 'package:change_money_cashier_app/data/models/responses/merchant_response.dart';
import 'package:change_money_cashier_app/data/models/responses/user_customer_response.dart';
import 'package:equatable/equatable.dart';

class TransactionEntity extends Equatable {
  final String id;
  final String reference;
  final String dateCreated;
  final String dateUpdated;
  final double amount;
  final double amountInUsd;
  final double baseExchangeRateUsed;
  final double merchantIncentiveUsed;
  final double totalExchangeRateUsed;
  final double changeAlreadyIssued;
  final double changeAlreadyIssuedInUsd;
  final double requiredChange;
  final double requiredChangeInUsd;
  final String destinationAccount;
  final String dateOfTransaction;
  final String notificationMsisdn;
  final double transactionCharge;
  final double transactionChargeInUsd;
  final TransactionType transactionType;
  final TransactionStatus status;
  final MerchantResponse merchant;
  final MerchantCashierResponse cashier;
  final MerchantBranchResponse merchantBranch;
  final UserCustomerResponse customer;
  final UserCustomerResponse receiver;
  final CurrencyResponse currency;
  final FinancialInstitutionResponse financialInstitution;
  TransactionEntity({
    required this.id,
    required this.dateCreated,
    required this.dateUpdated,
    required this.reference,
    required this.amount,
    required this.transactionCharge,
    required this.financialInstitution,
    required this.currency,
    required this.customer,
    required this.receiver,
    required this.merchantBranch,
    required this.cashier,
    required this.merchant,
    required this.status,
    required this.transactionType,
    required this.transactionChargeInUsd,
    required this.notificationMsisdn,
    required this.dateOfTransaction,
    required this.destinationAccount,
    required this.requiredChangeInUsd,
    required this.requiredChange,
    required this.changeAlreadyIssuedInUsd,
    required this.changeAlreadyIssued,
    required this.totalExchangeRateUsed,
    required this.merchantIncentiveUsed,
    required this.baseExchangeRateUsed,
    required this.amountInUsd,
  });

  @override
  List<Object> get props =>
      [amountInUsd, status, transactionType, dateOfTransaction];
}
