import 'package:change_money_cashier_app/data/models/enums/gender.dart';
import 'package:equatable/equatable.dart';

import '../../data/models/enums/socket_group.dart';
import '../../data/models/responses/merchant_branch_response.dart';
import '../../data/models/responses/merchant_response.dart';
import '../../data/models/responses/privilege_response.dart';
import '../../data/models/responses/role_response.dart';

class LoginEntity extends Equatable {
  final String userId;
  final String firstName;
  final bool verified;
  final String mobileNumber;
  final bool available;
  final String mobileNumberCountryCode;
  final String username;
  final bool enabled;
  final bool resetPin;
  final String surname;
  final String dateCreated;
  final String dateUpdated;
  final String email;
  final String userGroup;
  final WebSocketMessageGroup webSocketMessageGroup;
  final Gender gender;
  final MerchantResponse merchant;
  final MerchantBranchResponse merchantBranch;
  final List<RoleResponse> userRoles;
  final List<PrivilegeResponse> privileges;
  final String accessToken;
  LoginEntity({
    required this.accessToken,
    required this.userId,
    required this.firstName,
    required this.verified,
    required this.mobileNumber,
    required this.available,
    required this.email,
    required this.mobileNumberCountryCode,
    required this.enabled,
    required this.username,
    required this.resetPin,
    required this.surname,
    required this.dateCreated,
    required this.dateUpdated,
    required this.userGroup,
    required this.webSocketMessageGroup,
    required this.gender,
    required this.merchant,
    required this.merchantBranch,
    required this.userRoles,
    required this.privileges,
  });
  @override
  List<Object> get props => [
        accessToken,
        username,
        userGroup,
        accessToken,
        firstName,
        surname,
      ];
}
