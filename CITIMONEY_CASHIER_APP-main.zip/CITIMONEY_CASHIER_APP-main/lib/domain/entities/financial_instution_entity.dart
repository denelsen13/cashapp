import 'package:equatable/equatable.dart';

class FinancialInstutionEntity extends Equatable {
  final String id;
  final String institutionNumber;
  final String displayName;
  final bool status;
  final bool mobileMoney;
  FinancialInstutionEntity(
      {required this.displayName,
      required this.id,
      required this.institutionNumber,
      required this.mobileMoney,
      required this.status});
  @override
  List<Object> get props =>
      [id, displayName, institutionNumber, mobileMoney, status];
}
