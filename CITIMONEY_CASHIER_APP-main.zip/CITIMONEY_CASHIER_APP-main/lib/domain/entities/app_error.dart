import 'package:equatable/equatable.dart';

class AppError extends Equatable {
  final AppErrorType appErrorType;
  final String message;
  final int status;
  const AppError(
      {required this.appErrorType,
      this.status = 0,
      this.message = 'Something went terribly wrong. Try Again Later'});

  @override
  List<Object> get props => [appErrorType];
}

enum AppErrorType { api, network, other }
