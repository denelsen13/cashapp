import 'package:equatable/equatable.dart';

class RecentTrasactionsEntity extends Equatable {
  final List transactions;
  RecentTrasactionsEntity({required this.transactions});
  @override
  List<Object> get props => [transactions];
}
