import 'package:change_money_cashier_app/data/models/responses/wallet_response.dart';
import 'package:equatable/equatable.dart';

class CheckCashierEntity extends Equatable {
  final String msisdn;
  final String id;
  final double currentBalance;
  final double totalChangeIssuedBalance;
  CheckCashierEntity(
      {required this.currentBalance,
      required this.totalChangeIssuedBalance,
      required this.id,
      required this.msisdn});
  @override
  List<Object> get props => throw UnimplementedError();
}
