import 'package:equatable/equatable.dart';

class NoResponse extends Equatable {
  final String statusCode;
  final bool isSucess;
  final String message;
  NoResponse(
      {required this.statusCode,
      required this.isSucess,
      required this.message});
  @override
  List<Object> get props => [];
  factory NoResponse.fromJson(Map<String, dynamic> json) {
    return NoResponse(
      statusCode: json['status'],
      message: json['message'],
      isSucess: true,
    );
  }
}
