class RouteList {
  RouteList._();
  static const String initial = '/';
  static const String expiry = 'expiry';
  static const String login = '/login';
  static const String forgotPassword = '/forgot-password';
  static const String home = '/home';
  static const String tellerHome = '/teller-home';
  static const String issueChange = '/issue-change';
  static const String changePin = '/change-pin';
  static const String splash = 'splash';
  static const String verifyOtp = 'verify-otp';
  static const String changePassword = 'change-password';
  static const String chat = 'chat';
  static const String notifications = 'notifications';
  static const String signup = 'signup';
}
