import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:change_money_cashier_app/screens/change_password_screen.dart';
import 'package:change_money_cashier_app/screens/expiry_screen.dart';
import 'package:change_money_cashier_app/screens/forgot_password_screen.dart';
import 'package:change_money_cashier_app/screens/home_screen.dart';
import 'package:change_money_cashier_app/screens/login_screen.dart';
import 'package:change_money_cashier_app/screens/sign_up_screen.dart';
import 'package:change_money_cashier_app/screens/splash_screen.dart';
import 'package:change_money_cashier_app/screens/teller_home_screen.dart';
import 'package:change_money_cashier_app/screens/verify_otp_screen.dart';
import 'package:flutter/material.dart';

class Routes {
  static Map<String, WidgetBuilder>? getRoutes(RouteSettings setting) => {
        RouteList.initial: (context) => ExpiryScreen(),
        RouteList.expiry: (context) => ExpiryScreen(),
        RouteList.forgotPassword: (context) => ForgotPasswordScreen(),
        RouteList.home: (context) => HomeScreen(),
        RouteList.tellerHome: (context) => TellerHomeScreen(),
        RouteList.login: (context) => LoginScreen(),
        RouteList.splash: (context) => SplashScreen(),
        RouteList.signup: (context) => SignupScreen(),
        RouteList.verifyOtp: (context) => VerifyOtpScreen(),
        RouteList.expiry: (context) => ExpiryScreen(),
        RouteList.changePassword: (context) => ChangePasswordScreen(),
        RouteList.forgotPassword: (context) => ForgotPasswordScreen(),
      };
}
