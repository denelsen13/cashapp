import 'package:flutter/material.dart';

const primaryColor = Color(0xFF0677F8);
const secondaryColor = Color(0xFF707070);
const blackTextColor = Color(0xFF2D2D2D);
const greyTextColor = Color(0xFFAAAAAA);
const backgroundColor = Color(0xFFF6F6F6);
const veryLightBlueColor = Color(0xFFEDF4FD);
const fadedBackgroundColor = Color(0xFFEDF4FD);
const whiteColor = Color(0xFFFFFFFF);
const blackColor = Color(0xFF000000);
const greyColor = Color(0xFFCDCDCD);
const whiteishColor = Color(0xFFF2F2F2);
