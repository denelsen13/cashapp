import 'dart:convert';

class EncoderUtil {
  EncoderUtil._();

  static threefoldBase64Encode(String password) {
    for (var i = 0; i < 3; i++) {
      password = base64Encode(utf8.encode(password));
    }

    return password;
  }
}
