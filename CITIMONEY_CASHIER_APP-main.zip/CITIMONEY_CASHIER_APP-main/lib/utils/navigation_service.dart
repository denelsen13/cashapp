import 'package:flutter/material.dart';

class NavigationService {
  GlobalKey<NavigatorState>? navigationKey;

  NavigationService() {
    navigationKey = GlobalKey<NavigatorState>();
  }

  Future<dynamic> navigateToRemoveUntil(String _rn) {
    return navigationKey!.currentState!
        .pushNamedAndRemoveUntil(_rn, (route) => false);
  }

  Future<dynamic> navigateToReplacement(String _rn) {
    return navigationKey!.currentState!.pushReplacementNamed(_rn);
  }

  Future<dynamic> navigateTo(String _rn) {
    return navigationKey!.currentState!.pushNamed(_rn);
  }

  Future<dynamic> navigateToWithArguments(String _rn, dynamic arguments) {
    return navigationKey!.currentState!.pushNamed(_rn, arguments: arguments);
  }

  Future<dynamic> navigateToRoute(MaterialPageRoute _rn) {
    return navigationKey!.currentState!.push(_rn);
  }

  goback() {
    return navigationKey!.currentState!.pop();
  }
}
