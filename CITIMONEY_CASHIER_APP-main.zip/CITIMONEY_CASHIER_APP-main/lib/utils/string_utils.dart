extension StringExtension on String {
  String capitalize() {
    if (this.isNotEmpty) {
      return "${this[0].toUpperCase()}${this.substring(1)}";
    } else {
      return this;
    }
  }
}

extension TrimExtension on String {
  String trimString(int length) {
    String elepsis = "..."; //define your variable truncation elipsis here
    String truncated = "";

    if (this.length > length) {
      return this.substring(0, length - elepsis.length) + elepsis;
    } else {
      return this;
    }
  }
}

extension StringExtensions on String {
  bool containsIgnoreCase(String secondString) =>
      this.toLowerCase().contains(secondString.toLowerCase());

  //bool isNotBlank() => this != null && this.isNotEmpty;
}

class StringUtil {
  StringUtil._();

  static bool equalsIgnoreCase(String string1, String string2) {
    return string1.toLowerCase() == string2.toLowerCase();
  }
}
