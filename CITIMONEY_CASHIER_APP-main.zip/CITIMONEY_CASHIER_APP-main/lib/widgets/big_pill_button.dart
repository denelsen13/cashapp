import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildLargePillButton({
  Color labelColor = whiteColor,
  Color backgroundColor = primaryColor,
  required String label,
}) {
  return Container(
    height: SizeConfig.heightMultiplier! * 8,
    width: double.maxFinite,
    padding: EdgeInsets.symmetric(
      horizontal: SizeConfig.widthMultiplier! * 8,
    ),
    decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(
          SizeConfig.imageSizeMultiplier! * 8,
        )),
    child: Center(
      child: Text(
        label,
        style: TextStyle(
            color: labelColor, fontSize: SizeConfig.textMultiplier! * 2),
      ),
    ),
  );
}
