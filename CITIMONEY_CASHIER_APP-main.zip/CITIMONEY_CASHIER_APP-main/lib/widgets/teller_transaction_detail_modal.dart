import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/home/home_bloc.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/data/models/enums/transaction_type.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/confirm_payment_request.dart';
import 'package:change_money_cashier_app/data/models/responses/check_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/confirm_payment_response.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/data/models/transaction_model.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome4_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_select.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

class TellerTransactionDetailModal extends StatefulWidget {
  final TransactionModel transaction;
  TellerTransactionDetailModal({required this.transaction});
  @override
  _TellerTransactionDetailModalState createState() =>
      _TellerTransactionDetailModalState();
}

class _TellerTransactionDetailModalState
    extends State<TellerTransactionDetailModal>
    with SingleTickerProviderStateMixin {
  HomeBloc? homeBloc;
  AnimationController? controller;
  DateFormat formatter = DateFormat('yyyy-MM-dd');
  final format = DateFormat("yyyy-MM-dd'T'HH:mm");
  final df = new DateFormat(DateFormat.YEAR_ABBR_MONTH_DAY);
  final moneyFormatter = new NumberFormat("#,###.00#");
  getTransactionTime(String date) {
    var adate = format.parse(date);
    return DateFormat('hh:mm a').format(adate);
  }

  bool isAlertboxOpened = false;
  Animation<double>? scaleAnimation;
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);
    homeBloc = getItInstance<HomeBloc>();
    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  getTransactionType(TransactionType transactionType) {
    if (transactionType == TransactionType.CASH_IN) {
      return 'Cashin';
    }
    if (transactionType == TransactionType.CASH_OUT) {
      return 'Cashout';
    }
    if (transactionType == TransactionType.CHANGE) {
      return 'Change';
    }
    if (transactionType == TransactionType.CHECK_BALANCE) {
      return 'Balance';
    }
    if (transactionType == TransactionType.PAYMENT) {
      return 'Payment';
    }
    if (transactionType == TransactionType.TRANSFER) {
      return 'Transfer';
    }
    if (transactionType == TransactionType.WITHDRAWAL) {
      return 'Withdrawal';
    }
  }

  @override
  void dispose() {
    homeBloc!.close();
    controller!.dispose();
    super.dispose();
  }

  validatePin(cashierCode) {
    if (cashierCode == null) {
      return 'Pin cannot be empty';
    } else if (cashierCode.isEmpty) {
      return 'Pin cannot be empty';
    } else if (cashierCode.length < 4) {
      return 'Pin length cannot be less than 4';
    }
  }

  close() {
    Navigator.of(context).pop();
  }

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  popUpSection(HomeState state, BuildContext context) {
    if (state is HomeError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          homeBloc!.emit(HomeErrorDone());
          showErrorMessage(context,
              message: state.errorMessage, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                homeBloc!.add(HomeLoadEvent());
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  bodyContent({required HomeState state}) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            height: MediaQuery.of(context).size.height -
                SizeConfig.heightMultiplier! * 22,
            width: MediaQuery.of(context).size.width -
                SizeConfig.widthMultiplier! * 5,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    margin: EdgeInsets.all(15.0),
                    height: MediaQuery.of(context).size.height -
                        SizeConfig.heightMultiplier! * 30,
                    width: MediaQuery.of(context).size.width -
                        SizeConfig.widthMultiplier! * 5,
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        children: <Widget>[
                          Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.widthMultiplier! * 5,
                            ),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: SizeConfig.heightMultiplier! * 2,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    GestureDetector(
                                      onTap: close,
                                      child: FadeInLeft(
                                        duration: Duration(milliseconds: 1250),
                                        child: Icon(
                                          Icons.close,
                                          color: primaryColor,
                                          size:
                                              SizeConfig.imageSizeMultiplier! *
                                                  7,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: SizeConfig.heightMultiplier! * 3,
                                ),
                                Container(
                                  height: SizeConfig.heightMultiplier! * 35,
                                  width: double.infinity,
                                  padding: EdgeInsets.symmetric(
                                      horizontal:
                                          SizeConfig.widthMultiplier! * 5,
                                      vertical:
                                          SizeConfig.heightMultiplier! * 1),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(
                                      SizeConfig.imageSizeMultiplier! * 5,
                                    ),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Text(
                                        'Transaction Type',
                                        style: TextStyle(
                                            color: secondaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! *
                                                    2.1,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        '${this.getTransactionType(widget.transaction.transactionType)}',
                                        style: TextStyle(
                                            color: primaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! * 2,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        'Merchant Name',
                                        style: TextStyle(
                                            color: secondaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! *
                                                    2.1,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        '${widget.transaction.merchant.name}',
                                        style: TextStyle(
                                            color: primaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! * 2,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        'Teller',
                                        style: TextStyle(
                                            color: secondaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! *
                                                    2.1,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        '${widget.transaction.teller.firstName} ${widget.transaction.teller.surname}',
                                        style: TextStyle(
                                            color: primaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! * 2,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        'Transaction Date',
                                        style: TextStyle(
                                            color: secondaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! *
                                                    2.1,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                      Text(
                                        '${df.format(formatter.parse(widget.transaction.dateOfTransaction))} - ${this.getTransactionTime(widget.transaction.dateOfTransaction)}',
                                        style: TextStyle(
                                            color: primaryColor,
                                            fontSize:
                                                SizeConfig.textMultiplier! * 2,
                                            fontWeight: FontWeight.w600,
                                            height:
                                                SizeConfig.heightMultiplier! *
                                                    0.13),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: SizeConfig.heightMultiplier! * 10,
                            width: double.infinity,
                            color: veryLightBlueColor,
                            padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.widthMultiplier! * 5,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Amount',
                                  style: TextStyle(
                                      color: primaryColor,
                                      fontSize:
                                          SizeConfig.textMultiplier! * 2.1,
                                      fontWeight: FontWeight.w600,
                                      height:
                                          SizeConfig.heightMultiplier! * 0.13),
                                ),
                                Text(
                                  '${widget.transaction.currency.name.toUpperCase()}\$ ${moneyFormatter.format(widget.transaction.amount)}',
                                  style: TextStyle(
                                      color: primaryColor,
                                      fontSize: SizeConfig.textMultiplier! * 2,
                                      fontWeight: FontWeight.w600,
                                      height:
                                          SizeConfig.heightMultiplier! * 0.13),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 4,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.widthMultiplier! * 5,
                            ),
                            child: FadeInUp(
                              duration: Duration(milliseconds: 650),
                              child: GestureDetector(
                                onTap: close,
                                child: buildPillButton(
                                  label: 'Close',
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    height: SizeConfig.heightMultiplier! * 12,
                    width: SizeConfig.heightMultiplier! * 12,
                    decoration: BoxDecoration(
                      color: primaryColor,
                      border: Border.all(
                        color: whiteColor,
                        width: SizeConfig.widthMultiplier! * 0.2,
                      ),
                      borderRadius: BorderRadius.circular(
                        SizeConfig.imageSizeMultiplier! * 9,
                      ),
                    ),
                    child: Center(
                      child: Bounce(
                        duration: Duration(milliseconds: 850),
                        child: Icon(
                          BootstrapIcon.shop_window,
                          color: whiteColor,
                          size: SizeConfig.imageSizeMultiplier! * 15,
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<HomeBloc>(
      create: (context) => homeBloc!,
      child: BlocBuilder<HomeBloc, HomeState>(
        bloc: homeBloc,
        buildWhen: (HomeState previous, HomeState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is HomeLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              popUpSection(state, context),
            ],
          );
        },
      ),
    );
  }
}
