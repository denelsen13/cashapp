import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/requests/change_password_request_dto.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/encoder_util.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/change_pin_success_modal.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ChangeAccountPinModal extends StatefulWidget {
  @override
  _ChangeAccountPinModalState createState() => _ChangeAccountPinModalState();
}

class _ChangeAccountPinModalState extends State<ChangeAccountPinModal>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;
  final _formKey = GlobalKey<FormState>();
  String _msidn = '';
  bool isAlertboxOpened = false;
  LoginBloc? loginBloc;
  Animation<double>? scaleAnimation;
  TextEditingController confirmPinController = new TextEditingController();
  TextEditingController oldPinController = new TextEditingController();
  TextEditingController newPinController = new TextEditingController();
  final pinFocus = FocusNode();
  final oldPinFocus = FocusNode();
  final confirmPinFocus = FocusNode();
  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);
    loginBloc = getItInstance<LoginBloc>();
    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  @override
  void dispose() {
    controller!.dispose();
    loginBloc!.close();
    super.dispose();
  }

  updatePin() async {
    if (_formKey.currentState!.validate()) {
      SharedPreferenceUtil sharedPreferencesUtil =
          getItInstance<SharedPreferenceUtil>();
      final msidn = await sharedPreferencesUtil.getUsername();
      setState(() {
        _msidn = msidn;
      });
      loginBloc!.add(
        ChangePasswordEvent(
          request: ChangePasswordRequestDTO(
              newPassword:
                  EncoderUtil.threefoldBase64Encode(newPinController.text),
              oldPassword:
                  EncoderUtil.threefoldBase64Encode(oldPinController.text)),
        ),
      );
    } else {}

    // Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => RootScreen(),
    //   ),
    // );
  }

  close() {
    Navigator.of(context).pop(false);
  }

  validateOldPin(pin) {
    if (pin == null) {
      return 'old pin cannot be empty';
    } else if (pin.isEmpty) {
      return 'old pin cannot be empty';
    } else if (pin.length < 4) {
      return 'old pin length cannot be less than 4';
    }
  }

  validatePin(pin) {
    if (pin == null) {
      return 'pin cannot be empty';
    } else if (pin.isEmpty) {
      return 'pin cannot be empty';
    } else if (pin.length < 4) {
      return 'pin length cannot be less than 4';
    }
  }

  validateConfirmPin(pin) {
    if (pin == null) {
      return 'pin cannot be empty';
    } else if (pin.isEmpty) {
      return 'pin cannot be empty';
    } else if (pin.length < 4) {
      return 'pin length cannot be less than 4';
    } else if (pin != newPinController.text) {
      return 'New Pin and Confirmed Pin do not match';
    }
  }

  changePinSuccess() {
    Navigator.of(context).pop(false);
    showDialog(
      context: context,
      builder: (_) => ChangePinSuccessModal(),
    ).then((value) {});
  }

  popUpSection(LoginState state, BuildContext context) {
    if (state is LoginError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          loginBloc!.emit(LoginErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            loginBloc!.emit(LoginErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                loginBloc!.add(
                  ChangePasswordEvent(
                    request: ChangePasswordRequestDTO(
                        newPassword: EncoderUtil.threefoldBase64Encode(
                            newPinController.text),
                        oldPassword: EncoderUtil.threefoldBase64Encode(
                            oldPinController.text)),
                  ),
                );
              }
            });
          }
        });
      }
    }
    if (state is LoginChangePasswordDone) {
      loginBloc!.emit(LoginChangePasswordCompleted());
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        changePinSuccess();
      });
    }

    return SizedBox.shrink();
  }

  bodyContent({
    required LoginState state,
  }) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            height: MediaQuery.of(context).size.height -
                SizeConfig.heightMultiplier! * 20,
            width: MediaQuery.of(context).size.width -
                SizeConfig.widthMultiplier! * 5,
            padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 2,
            ),
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    margin: EdgeInsets.all(15.0),
                    height: MediaQuery.of(context).size.height -
                        SizeConfig.heightMultiplier! * 28,
                    width: MediaQuery.of(context).size.width -
                        SizeConfig.widthMultiplier! * 5,
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 5,
                    ),
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              GestureDetector(
                                onTap: close,
                                child: FadeInLeft(
                                  duration: Duration(milliseconds: 1250),
                                  child: Icon(
                                    Icons.close,
                                    color: primaryColor,
                                    size: SizeConfig.imageSizeMultiplier! * 7,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Text(
                            'Change Account Pin',
                            style: TextStyle(
                              color: primaryColor,
                              fontSize: SizeConfig.textMultiplier! * 2.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: SizeConfig.widthMultiplier! * 3),
                            child: Text(
                              'You are about to change your cashier account pin. Please fill in the required fields and submit to change',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: secondaryColor,
                                fontSize: SizeConfig.textMultiplier! * 1.7,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          FadeInUp(
                            duration: Duration(milliseconds: 650),
                            child: buildCustomTextField(
                              hintText: 'Enter Old Pin',
                              obsecureText: true,
                              validateFunction: validateOldPin,
                              isValidate: true,
                              controller: oldPinController,
                              currentFocusNode: oldPinFocus,
                              focusChangeFunction: changeFocus,
                              nextFocusNode: pinFocus,
                              isNumber: true,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          FadeInUp(
                            duration: Duration(milliseconds: 850),
                            child: buildCustomTextField(
                              hintText: 'Enter New Pin',
                              obsecureText: true,
                              validateFunction: validatePin,
                              isValidate: true,
                              controller: newPinController,
                              currentFocusNode: pinFocus,
                              focusChangeFunction: changeFocus,
                              nextFocusNode: confirmPinFocus,
                              isNumber: true,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          FadeInUp(
                            duration: Duration(milliseconds: 1250),
                            child: buildCustomTextField(
                              hintText: 'Confirm New Pin',
                              obsecureText: true,
                              validateFunction: validateConfirmPin,
                              isValidate: true,
                              controller: confirmPinController,
                              currentFocusNode: confirmPinFocus,
                              textInputAction: TextInputAction.done,
                              isNumber: true,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          FadeInUp(
                              duration: Duration(milliseconds: 650),
                              child: GestureDetector(
                                onTap: updatePin,
                                child: buildPillButton(label: 'Update Pin'),
                              )),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    height: SizeConfig.heightMultiplier! * 12,
                    width: SizeConfig.heightMultiplier! * 12,
                    decoration: BoxDecoration(
                      color: primaryColor,
                      border: Border.all(
                        color: whiteColor,
                        width: SizeConfig.widthMultiplier! * 0.2,
                      ),
                      borderRadius: BorderRadius.circular(
                        SizeConfig.imageSizeMultiplier! * 9,
                      ),
                    ),
                    child: Center(
                      child: Bounce(
                        duration: Duration(milliseconds: 850),
                        child: Icon(
                          BoxIcons.bx_lock_open,
                          color: whiteColor,
                          size: SizeConfig.imageSizeMultiplier! * 15,
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => loginBloc!,
      child: BlocBuilder<LoginBloc, LoginState>(
        bloc: loginBloc,
        buildWhen: (LoginState previous, LoginState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is AuthLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              popUpSection(state, context),
            ],
          );
        },
      ),
    );
  }
}
