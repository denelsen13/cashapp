import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';

class ChangePinSuccessModal extends StatefulWidget {
  @override
  _ChangePinSuccessModalState createState() => _ChangePinSuccessModalState();
}

class _ChangePinSuccessModalState extends State<ChangePinSuccessModal>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;

  Animation<double>? scaleAnimation;

  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);

    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller!.dispose();
    super.dispose();
  }

  close() {
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            height: MediaQuery.of(context).size.height -
                SizeConfig.heightMultiplier! * 62,
            width: MediaQuery.of(context).size.width -
                SizeConfig.widthMultiplier! * 5,
            padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 2,
            ),
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    margin: EdgeInsets.all(15.0),
                    height: MediaQuery.of(context).size.height -
                        SizeConfig.heightMultiplier! * 70,
                    width: MediaQuery.of(context).size.width -
                        SizeConfig.widthMultiplier! * 5,
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 5,
                    ),
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: close,
                              child: FadeInLeft(
                                duration: Duration(milliseconds: 1250),
                                child: Icon(
                                  Icons.close,
                                  color: primaryColor,
                                  size: SizeConfig.imageSizeMultiplier! * 7,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Text(
                          'Successfully Changed Pin',
                          style: TextStyle(
                              color: primaryColor,
                              fontSize: SizeConfig.textMultiplier! * 2.5,
                              fontWeight: FontWeight.w600,
                              height: SizeConfig.heightMultiplier! * 0.15),
                        ),
                        Text(
                          'You have successfully changed your pin',
                          style: TextStyle(
                            color: secondaryColor,
                            fontSize: SizeConfig.textMultiplier! * 1.7,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        FadeInUp(
                          duration: Duration(milliseconds: 650),
                          child: GestureDetector(
                            onTap: close,
                            child: buildPillButton(
                              label: 'Close',
                              labelColor: primaryColor,
                              borderColor: primaryColor,
                              showBorders: true,
                              backgroundColor: whiteColor,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 3,
                        ),
                      ],
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    height: SizeConfig.heightMultiplier! * 12,
                    width: SizeConfig.heightMultiplier! * 12,
                    decoration: BoxDecoration(
                      color: primaryColor,
                      border: Border.all(
                        color: whiteColor,
                        width: SizeConfig.widthMultiplier! * 0.2,
                      ),
                      borderRadius: BorderRadius.circular(
                        SizeConfig.imageSizeMultiplier! * 9,
                      ),
                    ),
                    child: Center(
                      child: Bounce(
                        duration: Duration(milliseconds: 850),
                        child: Icon(
                          BoxIcons.bx_check_shield,
                          color: whiteColor,
                          size: SizeConfig.imageSizeMultiplier! * 15,
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
