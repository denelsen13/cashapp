import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

buildLeftCurve(
    {required VoidCallback leftButtonFunction,
    IconData leftIcon = BootstrapIcon.chevron_double_right,
    bool isOpen = false}) {
  return Align(
    alignment: Alignment.topLeft,
    child: GestureDetector(
      onTap: leftButtonFunction,
      child: Container(
        width: SizeConfig.widthMultiplier! * 25,
        height: SizeConfig.heightMultiplier! * 20,
        child: Stack(
          children: [
            SvgPicture.asset(
              'assets/images/curve_1.svg',
              fit: BoxFit.contain,
              width: SizeConfig.widthMultiplier! * 25,
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 5,
              left: SizeConfig.widthMultiplier! * 5,
              child: GestureDetector(
                onTap: leftButtonFunction,
                child: Icon(
                  isOpen ? Icons.clear : leftIcon,
                  color: whiteColor,
                  size: SizeConfig.imageSizeMultiplier! * 8,
                ),
              ),
            )
          ],
        ),
      ),
    ),
  );
}
