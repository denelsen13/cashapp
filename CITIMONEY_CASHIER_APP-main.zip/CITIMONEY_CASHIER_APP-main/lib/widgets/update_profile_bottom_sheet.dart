import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/profile/profile_bloc.dart';
import 'package:change_money_cashier_app/data/models/requests/update_profile_request.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_phone_number_field.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:intl_phone_field/countries.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:intl/intl.dart';

class UpdateProfileBottomSheet extends StatefulWidget {
  final String? mobileNumber;
  final String? mobileNumberCountryCode;
  final String? firstName;
  final String? lastName;
  final String? email;
  UpdateProfileBottomSheet(
      {required this.email,
      required this.firstName,
      required this.lastName,
      required this.mobileNumberCountryCode,
      required this.mobileNumber});
  @override
  _UpdateProfileBottomSheetState createState() =>
      _UpdateProfileBottomSheetState();
}

class _UpdateProfileBottomSheetState extends State<UpdateProfileBottomSheet> {
  final _formKey = GlobalKey<FormState>();
  ProfileBloc? profileBloc;
  bool isAlertboxOpened = false;
  String countryCode = 'ZW';
  String countryDial = '+263';
  late TextEditingController? mobileNumberController;
  late TextEditingController? emailController;
  late TextEditingController? firstNameController;
  late TextEditingController? lastNameController;

  final emailFocus = FocusNode();
  final firstNameFocus = FocusNode();
  final lastNameFocus = FocusNode();
  final mobileNumberFocus = FocusNode();

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  updateProfile() async {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate()) {
      UpdateProfileRequestDTO request = UpdateProfileRequestDTO(
        email: emailController!.text,
        firstName: firstNameController!.text,
        surname: lastNameController!.text,
        mobileNumberCountryCode: countryCode.toUpperCase(),
        mobileNumber:
            '${countryDial.substring(1)}${mobileNumberController!.text}',
      );

      Navigator.of(context).pop(request);
    }
  }

  updateCountryCode(countryCode, countryDial) {
    setState(() {
      this.countryCode = countryCode;
      this.countryDial = countryDial;
    });
  }

  validateMobileNumber(mobileNumber) {
    Country _selectedCountry = countries.firstWhere((element) =>
        element.code.toUpperCase() == this.countryCode.toUpperCase());

    if (mobileNumberController!.text == null) {
      return 'mobile number cannot be empty';
    } else if (mobileNumberController!.text.isEmpty) {
      return 'mobile number cannot be empty';
    } else if (mobileNumberController!.text.length <
            _selectedCountry.maxLength ||
        mobileNumberController!.text.length > _selectedCountry.maxLength) {
      return 'mobile number is not valid';
    }
  }

  validateFirstName(name) {
    if (firstNameController!.text == null) {
      return 'First Name cannot be empty';
    } else if (firstNameController!.text.isEmpty) {
      return 'First Name cannot be empty';
    } else if (firstNameController!.text.length < 1) {
      return 'First Name length cannot be less than 1';
    } else if (firstNameController!.text.length > 25) {
      return 'First Name length cannot be more than 25';
    }
  }

  validateLastName(name) {
    if (lastNameController!.text == null) {
      return 'Last Name cannot be empty';
    } else if (lastNameController!.text.isEmpty) {
      return 'Last Name cannot be empty';
    } else if (lastNameController!.text.length < 1) {
      return 'Last Name length cannot be less than 1';
    } else if (lastNameController!.text.length > 25) {
      return 'Last Name length cannot be more than 25';
    }
  }

  validateEmail(String email) {
    if (emailController!.text != null && emailController!.text.isNotEmpty) {
      bool emailValid = RegExp(
              r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
          .hasMatch(email);
      if (!emailValid) {
        return 'invalid email';
      }
    }
  }

  close() {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.of(context).pop(true);
  }

  @override
  void initState() {
    super.initState();
    profileBloc = getItInstance<ProfileBloc>();

    this.emailController = new TextEditingController(
        text: widget.email != null ? widget.email : '');
    this.firstNameController =
        new TextEditingController(text: widget.firstName!);
    this.lastNameController = new TextEditingController(text: widget.lastName!);

    if (widget.email != null) {
      emailController!.text = widget.email!;
    }

    countryCode = widget.mobileNumberCountryCode!;
    Country _selectedCountry = countries.firstWhere((element) =>
        element.code.toUpperCase() == this.countryCode.toUpperCase());
    this.mobileNumberController = new TextEditingController(
        text: widget.mobileNumber!.split('${_selectedCountry.dialCode}')[1]);
  }

  @override
  void dispose() {
    super.dispose();
    profileBloc?.close();
  }

  sortOutMobileNumber() {}

  handleLogicStates(ProfileState state, BuildContext context) {
    if (state is ProfileError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          profileBloc!.emit(ProfileErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            profileBloc!.emit(ProfileErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.updateProfile();
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<ProfileBloc>(
      create: (context) => profileBloc!,
      child: BlocBuilder<ProfileBloc, ProfileState>(
        bloc: profileBloc,
        buildWhen: (ProfileState previous, ProfileState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is ProfileLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              handleLogicStates(state, context),
            ],
          );
        },
      ),
    );
  }

  bodyContent({required ProfileState state}) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      padding: EdgeInsets.only(
        right: SizeConfig.widthMultiplier! * 5,
        left: SizeConfig.widthMultiplier! * 5,
        top: SizeConfig.heightMultiplier! * 3,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(
            SizeConfig.imageSizeMultiplier! * 8,
          ),
          topRight: Radius.circular(
            SizeConfig.imageSizeMultiplier! * 8,
          ),
        ),
      ),
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: Form(
          key: _formKey,
          child: ListView(
            // mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Update Details',
                      style: TextStyle(
                        color: secondaryColor,
                        fontSize: SizeConfig.textMultiplier! * 2.8,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    InkWell(
                      onTap: close,
                      child: Icon(
                        Icons.clear,
                        color: secondaryColor,
                        size: SizeConfig.imageSizeMultiplier! * 8,
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 3,
              ),
              buildPhoneNumberField(
                // labelColor: secondaryColor,
                // borderColor: secondaryColor,
                valueColor: secondaryColor,
                countryCode: countryCode,
                validateFunction: validateMobileNumber,
                value: mobileNumberController!.text,
                isValidate: true,
                enabled: false,
                updateCountryCodeFunction: updateCountryCode,
                controller: mobileNumberController!,
                currentFocusNode: mobileNumberFocus,
                focusChangeFunction: changeFocus,
                nextFocusNode: emailFocus,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 2,
              ),
              buildCustomTextField(
                // borderColor: secondaryColor,
                hintText: 'First Name',
                // labelColor: secondaryColor,
                validateFunction: validateFirstName,
                isValidate: true,
                controller: firstNameController,
                currentFocusNode: firstNameFocus,
                focusChangeFunction: changeFocus,
                nextFocusNode: lastNameFocus,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 2,
              ),
              buildCustomTextField(
                // borderColor: secondaryColor,
                hintText: 'Last Name',
                labelColor: secondaryColor,
                validateFunction: validateLastName,
                isValidate: true,
                controller: lastNameController,
                currentFocusNode: lastNameFocus,
                focusChangeFunction: changeFocus,
                nextFocusNode: mobileNumberFocus,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 2,
              ),
              buildCustomTextField(
                // borderColor: secondaryColor,
                hintText: 'Please Enter Email',
                labelColor: primaryColor,
                validateFunction: validateEmail,
                isValidate: true,
                controller: emailController,
                currentFocusNode: emailFocus,
                textInputAction: TextInputAction.done,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 2,
              ),
              GestureDetector(
                onTap: updateProfile,
                child: buildPillButton(
                    label: 'Update Profile', backgroundColor: primaryColor),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
