import 'package:animate_do/animate_do.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome4_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

class ProcessingPaymentModal extends StatefulWidget {
  @override
  _ProcessingPaymentModalState createState() => _ProcessingPaymentModalState();
}

class _ProcessingPaymentModalState extends State<ProcessingPaymentModal>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;

  Animation<double>? scaleAnimation;

  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);

    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            color: blackColor.withOpacity(0.6),
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 2,
            ),
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    margin: EdgeInsets.all(15.0),
                    height: MediaQuery.of(context).size.height -
                        SizeConfig.heightMultiplier! * 60,
                    width: MediaQuery.of(context).size.width -
                        SizeConfig.widthMultiplier! * 10,
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 5,
                    ),
                    decoration: ShapeDecoration(
                      color: veryLightBlueColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Image.asset(
                          'assets/images/payment_1.gif',
                          width: double.infinity,
                          height: SizeConfig.heightMultiplier! * 30,
                        ),
                        TypewriterAnimatedTextKit(
                            repeatForever:
                                true, //this will ignore [totalRepeatCount]
                            pause: Duration(seconds: 1),
                            text: [
                              'Processing...',
                              'Processing...',
                              'Processing...',
                            ],
                            speed: Duration(milliseconds: 200),
                            textStyle: TextStyle(
                              color: primaryColor,
                              fontSize: SizeConfig.textMultiplier! * 2.5,
                              fontWeight: FontWeight.w400,
                            ),
                            displayFullTextOnTap: true,
                            stopPauseOnTap: true),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                      ],
                    ),
                  ),
                ),
                // Align(
                //   alignment: Alignment.topCenter,
                //   child: Container(
                //     height: SizeConfig.heightMultiplier! * 12,
                //     width: SizeConfig.heightMultiplier! * 12,
                //     decoration: BoxDecoration(
                //       color: primaryColor,
                //       border: Border.all(
                //         color: whiteColor,
                //         width: SizeConfig.widthMultiplier! * 0.2,
                //       ),
                //       borderRadius: BorderRadius.circular(
                //         SizeConfig.imageSizeMultiplier! * 9,
                //       ),
                //     ),
                //     child: Center(
                //       child: Bounce(
                //         duration: Duration(milliseconds: 850),
                //         child: Icon(
                //           FontAwesome4.dollar,
                //           color: whiteColor,
                //           size: SizeConfig.imageSizeMultiplier! * 15,
                //         ),
                //       ),
                //     ),
                //   ),
                // )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
