import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

buildBackgroundCurve() {
  return Align(
    alignment: Alignment.topCenter,
    child: Container(
      width: double.infinity,
      height: SizeConfig.heightMultiplier! * 62,
      child: SvgPicture.asset(
        'assets/images/curve_2.svg',
        fit: BoxFit.cover,
        // width: MediaQuery.of(context).size.width,
        // height: SizeConfig.heightMultiplier! * 50,
      ),
    ),
  );
}
