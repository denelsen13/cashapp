import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

buildPhoneNumberField({
  String hintText = 'Phone Number',
  Color borderColor = whiteColor,
  String value = '',
  String countryCode = 'ZW',
  Color valueColor = primaryColor,
  Color labelColor = primaryColor,
  bool enabled = true,
  List<String>? allowedCountries,
  bool isValidate = false,
  Function? validateFunction,
  Function? updateCountryCodeFunction,
  required TextEditingController controller,
  required FocusNode currentFocusNode,
  FocusNode? nextFocusNode,
  TextInputAction textInputAction = TextInputAction.next,
  Function? focusChangeFunction,
}) {
  return FormField(
    // initialValue: 0,
    // autovalidate: true,
    validator: isValidate ? (value) => validateFunction!(value) : null,
    builder: (state) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: SizeConfig.heightMultiplier! * 7.5,
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 8,
            ),
            decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(
                  SizeConfig.imageSizeMultiplier! * 8,
                )),
            child: Center(
              child: IntlPhoneField(
                textInputAction: textInputAction,
                focusNode: currentFocusNode,
                onSubmitted: (v) {
                  if (focusChangeFunction != null) {
                    focusChangeFunction(nextFocusNode);
                  }
                },
                initialCountryCode: 'ZW',
                controller: controller,
                autovalidateMode: AutovalidateMode.disabled,
                enabled: enabled,
                style: TextStyle(
                  color: valueColor,
                  fontSize: SizeConfig.textMultiplier! * 1.8,
                  fontWeight: FontWeight.w600,
                ),
                // countryCodeTextColor: primaryColor,
                decoration: InputDecoration(
                  hintText: hintText,
                  counterText: "",
                  labelStyle: TextStyle(
                    color: greyTextColor,
                    fontSize: SizeConfig.textMultiplier! * 1.8,
                  ),
                  hintStyle: TextStyle(
                    color: greyTextColor,
                    fontSize: SizeConfig.textMultiplier! * 1.8,
                  ),
                  prefixStyle: TextStyle(
                    color: valueColor,
                    fontSize: SizeConfig.textMultiplier! * 1.8,
                    fontWeight: FontWeight.w600,
                  ),
                  border: InputBorder.none,
                ),
                onChanged: (phone) {
                  state.didChange(phone.number);

                  updateCountryCodeFunction!(
                    phone.countryISOCode,
                    phone.countryCode,
                  );
                },
              ),
            ),
          ),
          SizedBox(
            height: SizeConfig.heightMultiplier! * 1,
          ),
          state.hasError
              ? Padding(
                  padding: EdgeInsets.only(
                      top: SizeConfig.heightMultiplier! * 1,
                      left: SizeConfig.widthMultiplier! * 5),
                  child: Text(
                    state.errorText!,
                    style: TextStyle(color: Colors.red, fontSize: 12),
                  ),
                )
              : SizedBox.shrink(),
        ],
      );
    },
  );
}
