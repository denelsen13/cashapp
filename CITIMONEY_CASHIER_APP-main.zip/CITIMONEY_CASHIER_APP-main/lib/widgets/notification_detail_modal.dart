import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/data/models/notification_result_model.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';

import 'package:flutter/material.dart';

class NotificationDetailModal extends StatefulWidget {
  final NotificationResultModel notification;
  NotificationDetailModal({
    required this.notification,
  });
  @override
  _NotificationDetailModalState createState() =>
      _NotificationDetailModalState();
}

class _NotificationDetailModalState extends State<NotificationDetailModal>
    with SingleTickerProviderStateMixin {
  AnimationController? controller;

  Animation<double>? scaleAnimation;

  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);

    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller!.dispose();
    super.dispose();
  }

  close() {
    {
      Navigator.of(context).pop(0);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            margin: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 5,
            ),
            height: MediaQuery.of(context).size.height -
                SizeConfig.heightMultiplier! * 60,
            width: double.infinity,
            padding: EdgeInsets.only(
              top: SizeConfig.heightMultiplier! * 1,
            ),
            decoration: ShapeDecoration(
              color: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Center(
                  child: Bounce(
                    duration: Duration(milliseconds: 850),
                    child: Icon(
                      widget.notification.readStatus
                          ? Ionicons.ion_ios_notifications_off
                          : Ionicons.ion_ios_notifications_outline,
                      color: widget.notification.readStatus
                          ? greyColor
                          : secondaryColor,
                      size: SizeConfig.imageSizeMultiplier! * 15,
                    ),
                  ),
                ),
                SizedBox(
                  height: SizeConfig.heightMultiplier! * 1,
                ),
                Text(
                  '${widget.notification.title}',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: primaryColor,
                    fontSize: SizeConfig.textMultiplier! * 2.1,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(
                  height: SizeConfig.heightMultiplier! * 1,
                ),
                Expanded(
                  child: Scrollbar(
                    isAlwaysShown: true,
                    child: ListView(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.widthMultiplier! * 5,
                          ),
                          child: Text(
                            '${widget.notification.message}',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: primaryColor,
                                fontSize: SizeConfig.textMultiplier! * 1.8),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                FadeInUp(
                  duration: Duration(milliseconds: 650),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 8,
                      vertical: SizeConfig.heightMultiplier! * 2,
                    ),
                    child: GestureDetector(
                      onTap: close,
                      child: buildPillButton(
                        label: 'Close',
                        backgroundColor: primaryColor,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
