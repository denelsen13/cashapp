import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';

class AuthPromptModal extends StatefulWidget {
  @override
  _AuthPromptModalState createState() => _AuthPromptModalState();
}

class _AuthPromptModalState extends State<AuthPromptModal>
    with SingleTickerProviderStateMixin {
  LoginBloc? loginBloc;
  AnimationController? controller;
  final _formKey = GlobalKey<FormState>();
  TextEditingController pinController = new TextEditingController();
  Animation<double>? scaleAnimation;
  final passwordFocus = FocusNode();
  final mobileNumberFocus = FocusNode();
  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);
    loginBloc = getItInstance<LoginBloc>();
    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  @override
  void dispose() {
    loginBloc!.close();
    controller!.dispose();
    super.dispose();
  }

  authenticate() {
    if (_formKey.currentState!.validate()) {
      Navigator.of(context).pop(pinController.text);
    } else {}
  }

  logout() {
    loginBloc!.add(LoginLogoutEvent());
  }

  validatePin(pin) {
    if (pin == null) {
      return 'pin cannot be empty';
    } else if (pin.isEmpty) {
      return 'pin cannot be empty';
    } else if (pin.length < 4) {
      return 'pin length cannot be less than 4';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: ListView(
            children: [
              SizedBox(
                height: SizeConfig.heightMultiplier! * 10,
              ),
              Container(
                margin: EdgeInsets.all(15.0),
                height: MediaQuery.of(context).size.height -
                    SizeConfig.heightMultiplier! * 38,
                width: MediaQuery.of(context).size.width -
                    SizeConfig.widthMultiplier! * 5,
                padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.widthMultiplier! * 5,
                ),
                decoration: ShapeDecoration(
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Image.asset(
                      'assets/images/lock_out.gif',
                      height: SizeConfig.heightMultiplier! * 20,
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.widthMultiplier! * 10),
                      child: Text(
                        ' Please enter your pin to continue using the App',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: secondaryColor,
                            fontSize: SizeConfig.textMultiplier! * 1.7),
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Form(
                      key: _formKey,
                      child: buildCustomTextField(
                        hintText: 'Enter Pin',
                        obsecureText: true,
                        isValidate: true,
                        validateFunction: validatePin,
                        controller: pinController,
                        isNumber: true,
                        textInputAction: TextInputAction.done,
                        currentFocusNode: passwordFocus,
                        // isNumber: true,
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    FadeInUp(
                      duration: Duration(milliseconds: 650),
                      child: GestureDetector(
                        onTap: authenticate,
                        child: buildPillButton(
                          label: 'Authenticate',
                        ),
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    FadeInUp(
                      duration: Duration(milliseconds: 650),
                      child: GestureDetector(
                        onTap: logout,
                        child: buildPillButton(
                            label: 'Logout',
                            showBorders: true,
                            labelColor: primaryColor,
                            backgroundColor: whiteColor,
                            borderColor: primaryColor),
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
