import 'package:change_money_cashier_app/data/models/enums/transaction_type.dart';
import 'package:change_money_cashier_app/domain/entities/transaction_entity.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

buildTellerHorizontalTransactionCard({required TransactionEntity transaction}) {
  DateFormat formatter = DateFormat('yyyy-MM-dd');
  final format = DateFormat("yyyy-MM-dd'T'HH:mm");
  final df = new DateFormat(DateFormat.YEAR_ABBR_MONTH_DAY);
  final moneyFormatter = new NumberFormat("#,###.00#");
  getTransactionTime(String date) {
    var adate = format.parse(date);
    return DateFormat('hh:mm a').format(adate);
  }

  getTransactionType(TransactionType transactionType) {
    if (transactionType == TransactionType.CASH_IN) {
      return 'Cashin';
    }
    if (transactionType == TransactionType.CASH_OUT) {
      return 'Cashout';
    }
    if (transactionType == TransactionType.CHANGE) {
      return 'Change';
    }
    if (transactionType == TransactionType.CHECK_BALANCE) {
      return 'Balance';
    }
    if (transactionType == TransactionType.PAYMENT) {
      return 'Payment';
    }
    if (transactionType == TransactionType.TRANSFER) {
      return 'Transfer';
    }
    if (transactionType == TransactionType.WITHDRAWAL) {
      return 'Withdrawal';
    }
  }

  return Container(
    height: SizeConfig.heightMultiplier! * 10,
    width: double.infinity,
    margin: EdgeInsets.only(bottom: SizeConfig.heightMultiplier! * 1),
    padding: EdgeInsets.symmetric(
        horizontal: SizeConfig.widthMultiplier! * 5,
        vertical: SizeConfig.heightMultiplier! * 1),
    decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(
          SizeConfig.imageSizeMultiplier! * 5,
        ),
        boxShadow: [
          BoxShadow(
            color: greyTextColor.withOpacity(0.3),
            blurRadius: 4.0,
            offset: Offset(1, 3),
            spreadRadius: 1.2,
          ),
        ]),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Container(
            child: Row(
              children: [
                Container(
                  height: SizeConfig.heightMultiplier! * 6,
                  width: SizeConfig.heightMultiplier! * 6,
                  decoration: BoxDecoration(
                    color: primaryColor,
                    borderRadius: BorderRadius.circular(
                      SizeConfig.imageSizeMultiplier! * 3,
                    ),
                  ),
                  child: Center(
                      child: Icon(
                    BoxIcons.bx_hash,
                    color: whiteColor,
                    size: SizeConfig.imageSizeMultiplier! * 6,
                  )),
                ),
                SizedBox(
                  width: SizeConfig.widthMultiplier! * 3,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        (transaction.transactionType == null)
                            ? 'N/A'
                            : '${getTransactionType(transaction.transactionType)}',
                        style: TextStyle(
                          color: secondaryColor,
                          fontWeight: FontWeight.w600,
                          fontSize: SizeConfig.textMultiplier! * 2,
                        ),
                      ),
                      Text(
                        (transaction.merchant == null)
                            ? 'N/A'
                            : '${transaction.merchant.name}',
                        style: TextStyle(
                          color: secondaryColor,
                          fontSize: SizeConfig.textMultiplier! * 1.5,
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
        Container(
          width: SizeConfig.widthMultiplier! * 20,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                getTransactionTime(transaction.dateOfTransaction),
                style: TextStyle(
                  color: primaryColor,
                  fontSize: SizeConfig.textMultiplier! * 1.2,
                ),
              ),
              Text(
                '${df.format(formatter.parse(transaction.dateOfTransaction))}',
                style: TextStyle(
                  color: secondaryColor,
                  fontSize: SizeConfig.textMultiplier! * 1.5,
                ),
              ),
              Text(
                '${transaction.currency.name.toUpperCase()}\$ ${moneyFormatter.format(transaction.amount)}',
                style: TextStyle(
                  color: primaryColor,
                  fontSize: SizeConfig.textMultiplier! * 1.2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        )
      ],
    ),
  );
}
