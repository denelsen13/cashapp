import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome4_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

buildFloatBanner({required double balance}) {
  final moneyFormatter = new NumberFormat("#,###.00#");
  return Container(
    height: SizeConfig.heightMultiplier! * 18,
    width: double.infinity,
    padding: EdgeInsets.all(
      SizeConfig.imageSizeMultiplier! * 5,
    ),
    decoration: BoxDecoration(
      color: whiteColor,
      border: Border.all(
        color: greyColor,
        width: SizeConfig.widthMultiplier! * 0.1,
      ),
      borderRadius: BorderRadius.circular(
        SizeConfig.imageSizeMultiplier! * 8,
      ),
    ),
    child: Row(
      children: [
        Container(
            height: SizeConfig.heightMultiplier! * 12,
            width: SizeConfig.heightMultiplier! * 12,
            padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
                vertical: SizeConfig.heightMultiplier! * 2),
            decoration: BoxDecoration(
              color: primaryColor,
              borderRadius: BorderRadius.circular(
                SizeConfig.imageSizeMultiplier! * 5,
              ),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'USD',
                  style: TextStyle(
                    color: whiteColor,
                    fontSize: SizeConfig.textMultiplier! * 2.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Container(
                  width: SizeConfig.widthMultiplier! * 5,
                  margin:
                      EdgeInsets.only(right: SizeConfig.widthMultiplier! * 2),
                  child: Icon(
                    FontAwesome4.dollar,
                    color: whiteColor,
                    size: SizeConfig.imageSizeMultiplier! * 16,
                  ),
                ),
              ],
            )),
        SizedBox(
          width: SizeConfig.widthMultiplier! * 5,
        ),
        Expanded(
          child: Container(
            height: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  balance == 0.0 ? '0.00' : '${moneyFormatter.format(balance)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: primaryColor,
                    fontSize: SizeConfig.textMultiplier! * 4,
                    height: SizeConfig.heightMultiplier! * 0.13,
                  ),
                ),
                Text(
                  'Current Balance',
                  style: TextStyle(
                    color: primaryColor,
                    fontSize: SizeConfig.textMultiplier! * 1.8,
                    fontWeight: FontWeight.w600,
                    height: SizeConfig.heightMultiplier! * 0.13,
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    ),
  );
}
