import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/utils/string_utils.dart';
import 'package:flutter/material.dart';

buildProfileDetailItem({
  required String label,
  required String value,
  isValueCapitalized = true,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        label.capitalize(),
        style: TextStyle(
          color: greyColor,
          fontSize: SizeConfig.textMultiplier! * 1.8,
          fontWeight: FontWeight.w800,
        ),
      ),
      Expanded(
        child: Text(
          isValueCapitalized ? value.capitalize() : value,
          textAlign: TextAlign.end,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: primaryColor,
            fontSize: SizeConfig.textMultiplier! * 1.8,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    ],
  );
}
