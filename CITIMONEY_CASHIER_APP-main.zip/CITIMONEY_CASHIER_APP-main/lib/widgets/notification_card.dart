import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/carbon_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

buildNotificationsCard(
    {bool isActive = false,
    required int index,
    required String title,
    required String time,
    required String message}) {
  DateFormat formatter = DateFormat('yyyy-MM-ddTHH:mm:ss');
  // final df = new DateFormat('yMMMEd');
  final df = new DateFormat('E d MMM y h:mm a');
  // final df = new DateFormat(DateFormat.YEAR_ABBR_MONTH_WEEKDAY_DAY );
  return Container(
    height: SizeConfig.heightMultiplier! * 14,
    width: double.infinity,
    margin: EdgeInsets.only(
      bottom: SizeConfig.heightMultiplier! * 2,
    ),
    padding: EdgeInsets.only(
      top: SizeConfig.heightMultiplier! * 2,
      right: SizeConfig.widthMultiplier! * 2,
      left: SizeConfig.widthMultiplier! * 2,
    ),
    decoration: BoxDecoration(
      color: whiteColor,
      borderRadius: BorderRadius.circular(
        SizeConfig.imageSizeMultiplier! * 5,
      ),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Container(
          height: SizeConfig.heightMultiplier! * 10,
          child: Row(
            children: [
              Container(
                height: double.infinity,
                width: SizeConfig.widthMultiplier! * 16,
                decoration: BoxDecoration(
                  color: isActive ? primaryColor : greyColor,
                  borderRadius: BorderRadius.circular(
                    SizeConfig.imageSizeMultiplier! * 2,
                  ),
                ),
                child: Center(
                  child: Icon(
                    CarbonIcons.notification,
                    color: whiteColor,
                    size: SizeConfig.imageSizeMultiplier! * 8,
                  ),
                ),
              ),
              SizedBox(
                width: SizeConfig.widthMultiplier! * 3,
              ),
              Expanded(
                child: Container(
                  height: double.infinity,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        maxLines: 1,
                        style: TextStyle(
                          color: isActive ? primaryColor : greyColor,
                          fontSize: SizeConfig.textMultiplier! * 1.7,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        message,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: isActive ? primaryColor : greyColor,
                          fontSize: SizeConfig.textMultiplier! * 1.7,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.only(
            right: SizeConfig.widthMultiplier! * 3,
          ),
          child: Text(
            time.isNotEmpty ? '${df.format(formatter.parse(time))}' : 'N/A',
            style: TextStyle(
              color: secondaryColor,
              fontSize: SizeConfig.textMultiplier! * 1.3,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    ),
  );
}
