import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/carbon_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildSearchBox({
  String hintText = 'Search for Order by Order Number',
  Function? onChangeFunction,
  TextEditingController? controller,
}) {
  return Container(
    height: SizeConfig.heightMultiplier! * 7,
    width: double.infinity,
    padding: EdgeInsets.only(
      left: SizeConfig.widthMultiplier! * 3,
    ),
    decoration: BoxDecoration(
      boxShadow: [
        BoxShadow(
          color: blackColor.withOpacity(0.05),
          blurRadius: 3.0,
          spreadRadius: 2.0,
        )
      ],
      color: whiteColor,
      borderRadius: BorderRadius.circular(
        SizeConfig.imageSizeMultiplier! * 3,
      ),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: TextFormField(
            cursorColor: secondaryColor,
            controller: controller,
            onChanged: (newValue) {
              onChangeFunction != null ? onChangeFunction(newValue) : () {};
            },
            keyboardType: TextInputType.text,
            textAlignVertical: TextAlignVertical.top,
            style: TextStyle(
              color: primaryColor,
              fontSize: SizeConfig.textMultiplier! * 1.8,
            ),
            decoration: InputDecoration(
              isDense: true,
              hintText: hintText,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 3,
              ),
              border: InputBorder.none,
              // fillColor: Colors.green,
              // filled: true,

              hintStyle: TextStyle(
                color: greyColor,
                fontSize: SizeConfig.textMultiplier! * 1.8,
              ),
            ),
          ),
        ),
        Container(
          height: SizeConfig.heightMultiplier! * 7,
          width: SizeConfig.heightMultiplier! * 7,
          child: Center(
            child: Icon(
              CarbonIcons.search,
              color: greyColor,
              size: SizeConfig.imageSizeMultiplier! * 6,
            ),
          ),
        ),
      ],
    ),
  );
}
