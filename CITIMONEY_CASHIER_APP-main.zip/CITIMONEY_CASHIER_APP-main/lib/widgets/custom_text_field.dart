import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildCustomTextField({
  Color labelColor = secondaryColor,
  Color borderColor = whiteColor,
  required String hintText,
  bool obsecureText = false,
  bool isNumber = false,
  bool enabled = true,
  bool hasBorder = true,
  String? value,
  bool isValidate = false,
  Function? validateFunction,
  Function? onChangeFunction,
  Function? focusChangeFunction,
  TextEditingController? controller,
  required FocusNode currentFocusNode,
  FocusNode? nextFocusNode,
  TextInputAction textInputAction = TextInputAction.next,
}) {
  return FormField(
    // initialValue: 0,
    // autovalidate: true,

    validator: isValidate
        ? (value) => value != null ? validateFunction!(value) : null
        : null,
    builder: (state) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: SizeConfig.heightMultiplier! * 7.5,
            width: double.infinity,
            padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 8,
            ),
            decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(
                  SizeConfig.imageSizeMultiplier! * 8,
                )),
            child: Center(
              child: TextFormField(
                textInputAction: textInputAction,
                focusNode: currentFocusNode,
                onFieldSubmitted: (v) {
                  if (focusChangeFunction != null) {
                    focusChangeFunction(nextFocusNode);
                  }
                },
                onChanged: (v) {
                  state.didChange(v);

                  // ignore: unnecessary_statements
                  onChangeFunction != null ? onChangeFunction() : null;
                  // ignore: unnecessary_statements
                  validateFunction != null ? validateFunction(v) : null;
                },
                controller: controller,
                cursorColor: secondaryColor,
                enabled: enabled,
                obscureText: obsecureText,
                keyboardType:
                    isNumber ? TextInputType.number : TextInputType.text,
                textAlignVertical: TextAlignVertical.center,
                style: TextStyle(
                  color: primaryColor,
                  fontSize: SizeConfig.textMultiplier! * 1.8,
                  fontWeight: FontWeight.w600,
                ),
                // initialValue: value,
                decoration: InputDecoration(
                  isDense: false,
                  counterText: "",
                  hintText: hintText,
                  // contentPadding: EdgeInsets.symmetric(
                  //   horizontal: SizeConfig.widthMultiplier! * 3,
                  // ),
                  border: InputBorder.none,
                  // fillColor: Colors.green,
                  // filled: true,

                  hintStyle: TextStyle(
                    color: greyTextColor,
                    fontSize: SizeConfig.textMultiplier! * 1.8,
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            height: SizeConfig.heightMultiplier! * 1,
          ),
          state.hasError
              ? Padding(
                  padding: EdgeInsets.only(
                      top: SizeConfig.heightMultiplier! * 1,
                      left: SizeConfig.widthMultiplier! * 5),
                  child: Text(
                    state.errorText!,
                    style: TextStyle(color: Colors.red, fontSize: 12),
                  ),
                )
              : SizedBox.shrink(),
        ],
      );
    },
  );
}
