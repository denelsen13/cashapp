import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/icons/feather_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildBasicTopBar(
    {required VoidCallback rightButtonFunction,
    required VoidCallback leftButtonFunction,
    required Function storePositionFunction}) {
  return Container(
    height: SizeConfig.heightMultiplier! * 5,
    width: double.infinity,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        GestureDetector(
          onTap: leftButtonFunction,
          child: Container(
            height: SizeConfig.heightMultiplier! * 5,
            width: SizeConfig.heightMultiplier! * 5,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(
                SizeConfig.imageSizeMultiplier! * 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: greyTextColor.withOpacity(0.4),
                  blurRadius: 3.0,
                  offset: Offset(0, 3),
                  spreadRadius: 1.2,
                ),
              ],
            ),
            child: Center(
              child: Icon(
                Feather.chevron_left,
                color: primaryColor,
                size: SizeConfig.imageSizeMultiplier! * 8,
              ),
            ),
          ),
        ),
        GestureDetector(
          onTap: rightButtonFunction,
          onTapDown: (value) => storePositionFunction(value),
          child: Container(
            height: SizeConfig.heightMultiplier! * 5,
            width: SizeConfig.heightMultiplier! * 5,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(
                SizeConfig.imageSizeMultiplier! * 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: greyTextColor.withOpacity(0.4),
                  blurRadius: 3.0,
                  offset: Offset(0, 3),
                  spreadRadius: 1.2,
                ),
              ],
            ),
            child: Center(
              child: Icon(
                BoxIcons.bx_menu_alt_right,
                color: secondaryColor,
                size: SizeConfig.imageSizeMultiplier! * 8,
              ),
            ),
          ),
        ),
      ],
    ),
  );
}
