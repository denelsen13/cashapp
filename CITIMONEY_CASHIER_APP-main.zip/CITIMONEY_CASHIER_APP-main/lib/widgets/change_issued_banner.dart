import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

buildChangeIssuedBanner(
    {VoidCallback? reloadFunction, required double totalChangeIssued}) {
  final moneyFormatter = new NumberFormat("#,###.00#");
  return Container(
    height: SizeConfig.heightMultiplier! * 16,
    width: SizeConfig.widthMultiplier! * 70,
    decoration: BoxDecoration(
      color: whiteColor,
      borderRadius: BorderRadius.circular(
        SizeConfig.imageSizeMultiplier! * 3,
      ),
      border: Border.all(
        color: greyTextColor,
        width: SizeConfig.widthMultiplier! * 0.1,
      ),
    ),
    child: Stack(
      children: [
        Container(
          width: double.infinity,
          height: double.infinity,
          padding: EdgeInsets.symmetric(
            horizontal: SizeConfig.widthMultiplier! * 5,
            vertical: SizeConfig.heightMultiplier! * 2,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    totalChangeIssued == 0.0
                        ? '0.00'
                        : '${moneyFormatter.format(totalChangeIssued)}',
                    style: TextStyle(
                      color: primaryColor,
                      fontSize: SizeConfig.textMultiplier! * 2.5,
                    ),
                  ),
                  Text(
                    'USD',
                    style: TextStyle(
                      color: secondaryColor,
                      fontSize: SizeConfig.textMultiplier! * 1.5,
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'N/A',
                    style: TextStyle(
                      color: primaryColor,
                      fontSize: SizeConfig.textMultiplier! * 2.5,
                    ),
                  ),
                  Text(
                    'ZWL',
                    style: TextStyle(
                      color: secondaryColor,
                      fontSize: SizeConfig.textMultiplier! * 1.5,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Container(
            width: double.infinity,
            margin: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 5),
            height: SizeConfig.heightMultiplier! * 0.1,
            color: greyTextColor,
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: GestureDetector(
            onTap: reloadFunction,
            child: Container(
              width: SizeConfig.heightMultiplier! * 5,
              height: SizeConfig.heightMultiplier! * 5,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.circular(
                  SizeConfig.imageSizeMultiplier! * 3,
                ),
              ),
              child: Center(
                child: Icon(
                  BoxIcons.bx_refresh,
                  color: whiteColor,
                  size: SizeConfig.imageSizeMultiplier! * 7,
                ),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}
