import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildPillButton({
  Color labelColor = whiteColor,
  Color backgroundColor = primaryColor,
  bool showBorders = false,
  Color borderColor = Colors.red,
  required String label,
}) {
  return Container(
    height: SizeConfig.heightMultiplier! * 7.5,
    width: double.maxFinite,
    padding: EdgeInsets.symmetric(
      horizontal: SizeConfig.widthMultiplier! * 8,
    ),
    decoration: BoxDecoration(
        color: backgroundColor,
        border: showBorders
            ? Border.all(
                color: borderColor, width: SizeConfig.widthMultiplier! * 0.3)
            : null,
        borderRadius: BorderRadius.circular(
          SizeConfig.imageSizeMultiplier! * 8,
        )),
    child: Center(
      child: Text(
        label,
        style: TextStyle(
            color: labelColor, fontSize: SizeConfig.textMultiplier! * 2),
      ),
    ),
  );
}
