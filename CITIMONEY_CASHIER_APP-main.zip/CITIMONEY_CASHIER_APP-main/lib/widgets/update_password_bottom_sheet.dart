import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/data/models/requests/change_password_request_dto.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/encoder_util.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:intl/intl.dart';

class UpdatePassswordBottomSheet extends StatefulWidget {
  @override
  _UpdatePassswordBottomSheetState createState() =>
      _UpdatePassswordBottomSheetState();
}

class _UpdatePassswordBottomSheetState
    extends State<UpdatePassswordBottomSheet> {
  bool isAlertboxOpened = false;
  final _formKey = GlobalKey<FormState>();
  TextEditingController oldPasswordController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  TextEditingController confirmPasswordController = new TextEditingController();
  final passwordFocus = FocusNode();
  final oldPasswordFocus = FocusNode();
  final confiemPasswordFocus = FocusNode();

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  changePassword() async {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate()) {
      ChangePasswordRequestDTO request = ChangePasswordRequestDTO(
        newPassword: EncoderUtil.threefoldBase64Encode(passwordController.text),
        oldPassword:
            EncoderUtil.threefoldBase64Encode(oldPasswordController.text),
      );

      Navigator.of(context).pop(request);
    }
  }

  close() {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.of(context).pop(true);
  }

  validatePassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
  }

  validateOldPassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
  }

  validateConfirmPassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
    if (this.passwordController.text != pin) {
      return 'passwords dont match';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      width: double.infinity,
      padding: EdgeInsets.only(
        right: SizeConfig.widthMultiplier! * 5,
        left: SizeConfig.widthMultiplier! * 5,
        top: SizeConfig.heightMultiplier! * 3,
        bottom: MediaQuery.of(context).viewInsets.bottom,
      ),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(
            SizeConfig.imageSizeMultiplier! * 8,
          ),
          topRight: Radius.circular(
            SizeConfig.imageSizeMultiplier! * 8,
          ),
        ),
      ),
      child: Container(
        height: MediaQuery.of(context).size.height,
        child: Form(
          key: _formKey,
          child: ListView(
            // mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Update Password',
                      style: TextStyle(
                        color: secondaryColor,
                        fontSize: SizeConfig.textMultiplier! * 2.8,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    InkWell(
                      onTap: close,
                      child: Icon(
                        Icons.clear,
                        color: primaryColor,
                        size: SizeConfig.imageSizeMultiplier! * 8,
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 3,
              ),
              buildCustomTextField(
                hintText: 'Old Password',
                borderColor: secondaryColor,
                labelColor: secondaryColor,
                obsecureText: true,
                isNumber: true,
                validateFunction: validateOldPassword,
                isValidate: true,
                controller: oldPasswordController,
                currentFocusNode: oldPasswordFocus,
                focusChangeFunction: changeFocus,
                nextFocusNode: passwordFocus,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 3,
              ),
              buildCustomTextField(
                borderColor: secondaryColor,
                labelColor: secondaryColor,
                hintText: 'New Password',
                obsecureText: true,
                validateFunction: validatePassword,
                isValidate: true,
                isNumber: true,
                controller: passwordController,
                currentFocusNode: passwordFocus,
                focusChangeFunction: changeFocus,
                nextFocusNode: confiemPasswordFocus,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 3,
              ),
              buildCustomTextField(
                borderColor: secondaryColor,
                labelColor: secondaryColor,
                hintText: 'Confirm New Password',
                obsecureText: true,
                validateFunction: validateConfirmPassword,
                isValidate: true,
                isNumber: true,
                controller: confirmPasswordController,
                currentFocusNode: confiemPasswordFocus,
                textInputAction: TextInputAction.done,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 5,
              ),
              GestureDetector(
                onTap: changePassword,
                child: buildPillButton(
                    label: 'Update Password', backgroundColor: primaryColor),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
