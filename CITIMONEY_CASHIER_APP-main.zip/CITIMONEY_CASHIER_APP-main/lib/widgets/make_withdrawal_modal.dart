import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/home/home_bloc.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_withdrawal_request_dto.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome4_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_select.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MakeWithdrawalModal extends StatefulWidget {
  @override
  _MakeWithdrawalModalState createState() => _MakeWithdrawalModalState();
}

class _MakeWithdrawalModalState extends State<MakeWithdrawalModal>
    with SingleTickerProviderStateMixin {
  HomeBloc? homeBloc;
  AnimationController? controller;
  bool isAlertboxOpened = false;
  List<CurrencyResponse> currencies = [];
  final _formKey = GlobalKey<FormState>();
  TextEditingController approvalCodeController = new TextEditingController();
  TextEditingController merchantCodeController = new TextEditingController();
  Animation<double>? scaleAnimation;
  final approvalCodeFocus = FocusNode();
  final merchantCodeFocus = FocusNode();
  final mobileNumberFocus = FocusNode();
  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);
    homeBloc = getItInstance<HomeBloc>();
    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  @override
  void dispose() {
    homeBloc!.close();
    controller!.dispose();
    super.dispose();
  }

  next() {
    if (_formKey.currentState!.validate()) {
      CheckWithdrawalRequestDTO request = new CheckWithdrawalRequestDTO(
        approval: approvalCodeController.text,
        code: merchantCodeController.text,
      );
      Navigator.of(context).pop(request);
    } else {}
  }

  validateMerchantCode(cashierCode) {
    if (cashierCode == null) {
      return 'Merchant Code cannot be empty';
    } else if (cashierCode.isEmpty) {
      return 'Merchant Code cannot be empty';
    } else if (cashierCode.length < 6) {
      return 'Merchant Code length cannot be less than 6 characters';
    }
  }

  validateApprovalCode(cashierCode) {
    if (cashierCode == null) {
      return 'Approval Code cannot be empty';
    } else if (cashierCode.isEmpty) {
      return 'Approval Code cannot be empty';
    } else if (cashierCode.length < 6) {
      return 'Approval Code length cannot be less than 6 characters';
    }
  }

  close() {
    Navigator.of(context).pop();
  }

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  popUpSection(HomeState state, BuildContext context) {
    if (state is HomeError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          homeBloc!.emit(HomeErrorDone());
          showErrorMessage(context,
              message: state.errorMessage, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                homeBloc!.add(HomeLoadEvent());
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  bodyContent({required HomeState state}) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            height: MediaQuery.of(context).size.height -
                SizeConfig.heightMultiplier! * 37,
            width: MediaQuery.of(context).size.width -
                SizeConfig.widthMultiplier! * 5,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    margin: EdgeInsets.all(15.0),
                    height: MediaQuery.of(context).size.height -
                        SizeConfig.heightMultiplier! * 45,
                    width: MediaQuery.of(context).size.width -
                        SizeConfig.widthMultiplier! * 5,
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 5,
                    ),
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: close,
                              child: FadeInLeft(
                                duration: Duration(milliseconds: 1250),
                                child: Icon(
                                  Icons.close,
                                  color: primaryColor,
                                  size: SizeConfig.imageSizeMultiplier! * 7,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).viewInsets.bottom == 0
                              ? SizeConfig.heightMultiplier! * 3
                              : SizeConfig.heightMultiplier! * 1,
                        ),
                        Text(
                          'Make Withdrawal',
                          style: TextStyle(
                            color: primaryColor,
                            fontSize: SizeConfig.textMultiplier! * 2.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.widthMultiplier! * 5),
                          child: Text(
                            'To make a withdrawal. Please enter the Merchant Code and approval code you want to withdrew.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: secondaryColor,
                                fontSize: SizeConfig.textMultiplier! * 1.7),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Expanded(
                          child: Form(
                              key: _formKey,
                              child: ListView(
                                children: [
                                  buildCustomTextField(
                                    hintText: 'Enter Merchant Code',
                                    isValidate: true,
                                    validateFunction: validateMerchantCode,
                                    controller: merchantCodeController,
                                    isNumber: true,
                                    textInputAction: TextInputAction.next,
                                    currentFocusNode: merchantCodeFocus,
                                    focusChangeFunction: changeFocus,
                                    nextFocusNode: approvalCodeFocus,
                                  ),
                                  SizedBox(
                                    height: SizeConfig.heightMultiplier! * 1,
                                  ),
                                  buildCustomTextField(
                                    hintText: 'Enter Approval Code',
                                    isValidate: true,
                                    isNumber: true,
                                    validateFunction: validateApprovalCode,
                                    controller: approvalCodeController,
                                    textInputAction: TextInputAction.done,
                                    currentFocusNode: approvalCodeFocus,
                                    focusChangeFunction: changeFocus,
                                  ),
                                ],
                              )),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        FadeInUp(
                          duration: Duration(milliseconds: 650),
                          child: GestureDetector(
                            onTap: next,
                            child: buildPillButton(
                              label: 'Next',
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                      ],
                    ),
                  ),
                ),
                MediaQuery.of(context).viewInsets.bottom == 0
                    ? Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          height: SizeConfig.heightMultiplier! * 12,
                          width: SizeConfig.heightMultiplier! * 12,
                          decoration: BoxDecoration(
                            color: primaryColor,
                            border: Border.all(
                              color: whiteColor,
                              width: SizeConfig.widthMultiplier! * 0.2,
                            ),
                            borderRadius: BorderRadius.circular(
                              SizeConfig.imageSizeMultiplier! * 9,
                            ),
                          ),
                          child: Center(
                            child: Bounce(
                              duration: Duration(milliseconds: 850),
                              child: Icon(
                                BootstrapIcon.shop_window,
                                color: whiteColor,
                                size: SizeConfig.imageSizeMultiplier! * 15,
                              ),
                            ),
                          ),
                        ),
                      )
                    : SizedBox.shrink()
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<HomeBloc>(
      create: (context) => homeBloc!,
      child: BlocBuilder<HomeBloc, HomeState>(
        bloc: homeBloc,
        buildWhen: (HomeState previous, HomeState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is HomeLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              popUpSection(state, context),
            ],
          );
        },
      ),
    );
  }
}
