import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

class LoadingScreen extends StatelessWidget {
  final String text;
  LoadingScreen({required this.text});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        color: blackColor.withOpacity(0.6),
        child: Center(
          child: Container(
            height: SizeConfig.heightMultiplier! * 40,
            width: double.infinity,
            margin: EdgeInsets.symmetric(
              horizontal: SizeConfig.widthMultiplier! * 15,
            ),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(
                SizeConfig.imageSizeMultiplier! * 5,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Image.asset(
                  'assets/images/loading.gif',
                  width: double.infinity,
                  height: SizeConfig.heightMultiplier! * 30,
                ),
                ScaleAnimatedTextKit(
                    repeatForever: true, //this will ignore [totalRepeatCount]
                    pause: Duration(seconds: 1),
                    text: [text, text, text],
                    // speed: Duration(milliseconds: 100),
                    textStyle: TextStyle(
                      fontSize: 2 * SizeConfig.textMultiplier!,
                      color: Colors.black,
                    ),
                    displayFullTextOnTap: true,
                    stopPauseOnTap: true),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
