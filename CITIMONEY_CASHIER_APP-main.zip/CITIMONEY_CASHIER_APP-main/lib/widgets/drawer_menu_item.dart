import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildDrawerMenuItem({required String label, required IconData icon}) {
  return Container(
    height: SizeConfig.heightMultiplier! * 7,
    margin: EdgeInsets.symmetric(
      vertical: SizeConfig.heightMultiplier! * 0.5,
    ),
    child: Row(
      children: [
        Icon(
          icon,
          color: whiteColor,
          size: SizeConfig.imageSizeMultiplier! * 7,
        ),
        SizedBox(
          width: SizeConfig.widthMultiplier! * 4,
        ),
        Text(
          label,
          style: TextStyle(
            color: whiteColor,
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w400,
          ),
        ),
      ],
    ),
  );
}
