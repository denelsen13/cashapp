import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/feather_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildCustomSelect({
  required String selectedValue,
  required List<DropdownMenuItem<String>> selectItems,
  required Function onChangeDropdownItemFunction,
  required FocusNode focusNode,
}) {
  return Container(
    height: SizeConfig.heightMultiplier! * 7.5,
    width: double.infinity,
    padding: EdgeInsets.symmetric(
      horizontal: SizeConfig.widthMultiplier! * 5,
    ),
    decoration: BoxDecoration(
        color: fadedBackgroundColor,
        borderRadius: BorderRadius.circular(
          SizeConfig.imageSizeMultiplier! * 8,
        )),
    child: Center(
      child: DropdownButton(
        dropdownColor: fadedBackgroundColor,
        focusNode: focusNode,
        icon: Icon(
          Feather.chevron_down,
          color: primaryColor,
          size: SizeConfig.imageSizeMultiplier! * 6,
        ),
        isExpanded: true,
        underline: SizedBox.shrink(),
        value: selectedValue,
        items: selectItems,
        onChanged: (value) => onChangeDropdownItemFunction(value),
      ),
    ),
  );
}
