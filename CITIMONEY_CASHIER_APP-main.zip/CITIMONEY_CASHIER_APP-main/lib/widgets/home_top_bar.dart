import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/icons/box_icons_icons.dart';
import 'package:change_money_cashier_app/utils/icons/clarity_icons_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome5_icons.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

buildHomeTopBar({
  required String username,
  bool showDefault = true,
  required VoidCallback openDrawerFunction,
  required VoidCallback closeDrawerFunction,
  required VoidCallback goToProfileFunction,
}) {
  String greeting() {
    var hour = DateTime.now().hour;
    if (hour < 12) {
      return 'Morning';
    }
    if (hour < 17) {
      return 'Afternoon';
    }
    return 'Evening';
  }

  return Container(
    height: SizeConfig.heightMultiplier! * 12,
    width: double.infinity,
    // padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier! * 3),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: showDefault ? closeDrawerFunction : openDrawerFunction,
              child: Icon(
                showDefault ? Icons.clear : BootstrapIcon.chevron_double_right,
                size: SizeConfig.imageSizeMultiplier! * 8,
                color: whiteColor,
              ),
            ),
            Text(
              'Home',
              style: TextStyle(
                  color: whiteColor,
                  fontSize: SizeConfig.textMultiplier! * 2.5,
                  fontWeight: FontWeight.w600,
                  height: SizeConfig.heightMultiplier! * 0.13),
            ),
            GestureDetector(
              onTap: goToProfileFunction,
              child: Container(
                height: SizeConfig.heightMultiplier! * 5,
                width: SizeConfig.heightMultiplier! * 5,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: whiteColor,
                  border: Border.all(
                    color: whiteColor,
                    width: SizeConfig.widthMultiplier! * 0.1,
                  ),
                ),
                child: CircleAvatar(
                  backgroundImage: AssetImage(
                    'assets/images/avatar.png',
                  ),
                ),
              ),
            )
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Hi, $username',
          style: TextStyle(
              color: whiteColor,
              fontSize: SizeConfig.textMultiplier! * 3,
              fontWeight: FontWeight.w600,
              height: SizeConfig.heightMultiplier! * 0.15),
        ),
      ],
    ),
  );
}
