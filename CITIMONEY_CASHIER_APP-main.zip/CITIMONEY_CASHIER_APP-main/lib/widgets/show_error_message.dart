import 'package:another_flushbar/flushbar.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

showErrorMessage(BuildContext context,
    {String message = '',
    int duration = 3,
    bool isDismissible = false,
    FlushbarPosition posistion = FlushbarPosition.TOP,
    String title = 'Something Went Wrong',
    Color backgroundColor = Colors.red}) {
  Flushbar flush = Flushbar();
  flush = Flushbar(
    reverseAnimationCurve: Curves.decelerate,
    forwardAnimationCurve: Curves.fastLinearToSlowEaseIn,
    flushbarPosition: posistion,
    backgroundColor: backgroundColor,
    isDismissible: isDismissible,
    onTap: (value) {
      if (isDismissible) {
        flush.dismiss(true);
      }
    },
    dismissDirection: FlushbarDismissDirection.HORIZONTAL,
    // backgroundGradient: LinearGradient(
    //   colors: [purpleTop, purpleBottom],
    //   begin: Alignment.topCenter,
    //   end: Alignment.bottomCenter,
    // ),
    margin: EdgeInsets.symmetric(
      horizontal: SizeConfig.widthMultiplier! * 3,
      vertical: SizeConfig.heightMultiplier! * 1,
    ),
    title: title,

    message: message,
    duration: Duration(seconds: duration),
  )..show(context);
  return SizedBox.shrink();
}
