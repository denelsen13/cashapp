import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/home/home_bloc.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/data/models/requests/check_cashout_request.dart';
import 'package:change_money_cashier_app/data/models/requests/check_payment_request.dart';
import 'package:change_money_cashier_app/data/models/responses/currency_response.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome4_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_select.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MakeCashoutModal extends StatefulWidget {
  @override
  _MakeCashoutModalState createState() => _MakeCashoutModalState();
}

class _MakeCashoutModalState extends State<MakeCashoutModal>
    with SingleTickerProviderStateMixin {
  HomeBloc? homeBloc;
  AnimationController? controller;
  bool isAlertboxOpened = false;
  List<CurrencyResponse> currencies = [];
  final _formKey = GlobalKey<FormState>();
  TextEditingController pinController = new TextEditingController();
  TextEditingController amountController = new TextEditingController();
  Animation<double>? scaleAnimation;
  final passwordFocus = FocusNode();
  final amountFocus = FocusNode();
  final currencyFocus = FocusNode();
  String _selectedCurrency = '';
  List<DropdownMenuItem<String>> currencyOptions = [];
  final mobileNumberFocus = FocusNode();
  final fifteenAgo = new DateTime.now().subtract(new Duration(minutes: 15));
  @override
  void initState() {
    super.initState();

    controller =
        AnimationController(vsync: this, duration: Duration(milliseconds: 250));
    scaleAnimation =
        CurvedAnimation(parent: controller!, curve: Curves.easeInSine);
    homeBloc = getItInstance<HomeBloc>();
    homeBloc!.add(LoadCurrenciesEvent());
    controller!.addListener(() {
      setState(() {});
    });

    controller!.forward();
  }

  @override
  void dispose() {
    homeBloc!.close();
    controller!.dispose();
    super.dispose();
  }

  next() {
    if (_formKey.currentState!.validate()) {
      CheckCashoutRequestDTO request = new CheckCashoutRequestDTO(
          amount: double.tryParse(amountController.text)!,
          cashierCode: pinController.text,
          currencyCode: _selectedCurrency);
      Navigator.of(context).pop(request);
    } else {}
  }

  validateCashierCode(cashierCode) {
    if (cashierCode == null) {
      return 'Cashier Code cannot be empty';
    } else if (cashierCode.isEmpty) {
      return 'Cashier Code cannot be empty';
    } else if (cashierCode.length < 6) {
      return 'Cashier Code length cannot be less than 6 characters';
    }
  }

  validateAmount(amount) {
    if (amount == null) {
      return 'amount cannot be empty';
    } else if (amount.isEmpty) {
      return 'amount cannot be empty';
    }
    try {
      final double doubleAmount = double.tryParse(amount)!;

      if (doubleAmount == null) {
        return 'Amount is invalid';
      }
      if (doubleAmount == 0) {
        return 'Amount cannot be 0';
      }
    } on Exception {
      return 'Amount is invalid';
    }
  }

  close() {
    Navigator.of(context).pop();
  }

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  void onChangeDropdown(String selectedCurrency) {
    print('This is the selected $selectedCurrency');
    setState(() {
      _selectedCurrency = selectedCurrency;
    });
  }

  popUpSection(HomeState state, BuildContext context) {
    if (state is HomeError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          homeBloc!.emit(HomeErrorDone());
          showErrorMessage(context,
              message: state.errorMessage, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                homeBloc!.add(HomeLoadEvent());
              }
            });
          }
        });
      }
    }
    if (state is CurrenciesLoaded) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          currencyOptions = [];
          currencies = state.currencies;
        });
        if (currencies != null && currencies.length != 0) {
          // set selected currency
          setState(() {
            _selectedCurrency = currencies[0].code;
          });
        }
        currencies.forEach((element) {
          setState(() {
            currencyOptions.add(
              DropdownMenuItem(
                value: '${element.code}',
                child: Text(
                  '${element.name}',
                  style: TextStyle(
                    color: primaryColor,
                    fontSize: SizeConfig.textMultiplier! * 1.6,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            );
          });
        });
        homeBloc!.emit(CurrenciesLoadedDone());
      });
    }
    return SizedBox.shrink();
  }

  bodyContent({required HomeState state}) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: ScaleTransition(
          scale: scaleAnimation!,
          child: Container(
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            height: MediaQuery.of(context).size.height -
                SizeConfig.heightMultiplier! * 30,
            width: MediaQuery.of(context).size.width -
                SizeConfig.widthMultiplier! * 5,
            child: Stack(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    margin: EdgeInsets.all(15.0),
                    height: MediaQuery.of(context).size.height -
                        SizeConfig.heightMultiplier! * 38,
                    width: MediaQuery.of(context).size.width -
                        SizeConfig.widthMultiplier! * 5,
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 5,
                    ),
                    decoration: ShapeDecoration(
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    child: Column(
                      children: <Widget>[
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: close,
                              child: FadeInLeft(
                                duration: Duration(milliseconds: 1250),
                                child: Icon(
                                  Icons.close,
                                  color: primaryColor,
                                  size: SizeConfig.imageSizeMultiplier! * 7,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: MediaQuery.of(context).viewInsets.bottom == 0
                              ? SizeConfig.heightMultiplier! * 3
                              : SizeConfig.heightMultiplier! * 1,
                        ),
                        Text(
                          'Make Cashout',
                          style: TextStyle(
                            color: primaryColor,
                            fontSize: SizeConfig.textMultiplier! * 2.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.widthMultiplier! * 5),
                          child: Text(
                            'To make a cashout. Please enter the Cashier Code and amount you want to cashout.',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: secondaryColor,
                                fontSize: SizeConfig.textMultiplier! * 1.7),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Expanded(
                          child: Form(
                              key: _formKey,
                              child: ListView(
                                children: [
                                  buildCustomTextField(
                                    hintText: 'Enter Cashier Code',
                                    isValidate: true,
                                    validateFunction: validateCashierCode,
                                    controller: pinController,
                                    isNumber: true,
                                    textInputAction: TextInputAction.next,
                                    currentFocusNode: passwordFocus,
                                    focusChangeFunction: changeFocus,
                                    nextFocusNode: amountFocus,
                                  ),
                                  SizedBox(
                                    height: SizeConfig.heightMultiplier! * 1,
                                  ),
                                  Container(
                                    width: SizeConfig.widthMultiplier! * 40,
                                    child: buildCustomSelect(
                                      selectedValue: _selectedCurrency,
                                      selectItems: currencyOptions,
                                      onChangeDropdownItemFunction:
                                          onChangeDropdown,
                                      focusNode: currencyFocus,
                                    ),
                                  ),
                                  SizedBox(
                                    height: SizeConfig.heightMultiplier! * 2,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(bottom: 0),
                                    child: buildCustomTextField(
                                      hintText: 'Enter Amount',
                                      isValidate: true,
                                      validateFunction: validateAmount,
                                      controller: amountController,
                                      isNumber: true,
                                      textInputAction: TextInputAction.done,
                                      currentFocusNode: amountFocus,
                                      // isNumber: true,
                                    ),
                                  ),
                                ],
                              )),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        FadeInUp(
                          duration: Duration(milliseconds: 650),
                          child: GestureDetector(
                            onTap: next,
                            child: buildPillButton(
                              label: 'Next',
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                      ],
                    ),
                  ),
                ),
                MediaQuery.of(context).viewInsets.bottom == 0
                    ? Align(
                        alignment: Alignment.topCenter,
                        child: Container(
                          height: SizeConfig.heightMultiplier! * 12,
                          width: SizeConfig.heightMultiplier! * 12,
                          decoration: BoxDecoration(
                            color: primaryColor,
                            border: Border.all(
                              color: whiteColor,
                              width: SizeConfig.widthMultiplier! * 0.2,
                            ),
                            borderRadius: BorderRadius.circular(
                              SizeConfig.imageSizeMultiplier! * 9,
                            ),
                          ),
                          child: Center(
                            child: Bounce(
                              duration: Duration(milliseconds: 850),
                              child: Icon(
                                BootstrapIcon.shop_window,
                                color: whiteColor,
                                size: SizeConfig.imageSizeMultiplier! * 15,
                              ),
                            ),
                          ),
                        ),
                      )
                    : SizedBox.shrink()
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<HomeBloc>(
      create: (context) => homeBloc!,
      child: BlocBuilder<HomeBloc, HomeState>(
        bloc: homeBloc,
        buildWhen: (HomeState previous, HomeState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is HomeLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              popUpSection(state, context),
            ],
          );
        },
      ),
    );
  }
}
