import 'dart:ui';

import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/widgets/custom_phone_number_field.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl_phone_field/countries.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/navigation_service.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({Key? key}) : super(key: key);

  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  LoginBloc? authBloc;
  bool isAlertboxOpened = false;
  String countryCode = 'zw';
  String countryDial = '+263';
  TextEditingController mobileNumberController = new TextEditingController();

  final mobileNumberFocus = FocusNode();

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  final _formKey = GlobalKey<FormState>();
  goback(context) {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.pop(context);
  }

  updateCountryCode(countryCode, dialCode) {
    setState(() {
      this.countryCode = countryCode;
      this.countryDial = dialCode;
    });
  }

  validateMobileNumber(mobileNumber) {
    Country _selectedCountry = countries.firstWhere((element) =>
        element.code.toUpperCase() == this.countryCode.toUpperCase());

    if (mobileNumber == null) {
      return 'mobile number cannot be empty';
    } else if (mobileNumber.isEmpty) {
      return 'mobile number cannot be empty';
    } else if (mobileNumber.length < _selectedCountry.maxLength ||
        mobileNumber.length > _selectedCountry.minLength) {
      return 'mobile number is not valid';
    }
  }

  resetPassword(BuildContext context) {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate()) {
      authBloc!.add(
        ResetPasswordEvent(
            mobileNumber:
                '${countryDial.substring(1)}${mobileNumberController.text}'),
      );
    }
  }

  goToLoginScreen(context) {
    FocusScope.of(context).requestFocus(FocusNode());
    getItInstance<NavigationService>().navigateTo(RouteList.login);
  }

  @override
  void initState() {
    super.initState();
    authBloc = getItInstance<LoginBloc>();
    authBloc!.add(ForgotPasswordLoadEvent());
  }

  @override
  void dispose() {
    super.dispose();
    authBloc?.close();
  }

  handleLogicStates(LoginState state, BuildContext context) {
    if (state is ResetPasswordError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          authBloc!.emit(ResetPasswordErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            authBloc!.emit(ResetPasswordErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.resetPassword(context);
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => authBloc!,
      child: BlocBuilder<LoginBloc, LoginState>(
        bloc: authBloc,
        buildWhen: (LoginState previous, LoginState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is AuthLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              handleLogicStates(state, context),
            ],
          );
        },
      ),
    );
  }

  bodyContent({required LoginState state}) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(color: whiteColor),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
              child: new Container(
                decoration:
                    new BoxDecoration(color: Colors.white.withOpacity(0.0)),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 5,
                vertical: SizeConfig.heightMultiplier! * 3,
              ),
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Container(
                    width: double.infinity,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () => goback(context),
                                child: Icon(
                                  Ionicons.ion_ios_arrow_back,
                                  size: SizeConfig.imageSizeMultiplier! * 9,
                                  color: whiteColor,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 5,
                          ),
                          Center(
                            child: Image.asset(
                              'assets/images/logo_black.png',
                              height: SizeConfig.heightMultiplier! * 12,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 5,
                          ),
                          Text(
                            'Forgot Password',
                            style: TextStyle(
                              color: blackColor,
                              fontSize: SizeConfig.textMultiplier! * 4,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1.5,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: SizeConfig.widthMultiplier! * 10),
                            child: Text(
                              'Enter your phone number to receive an OTP to use to reset your password',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: blackColor,
                                fontSize: SizeConfig.textMultiplier! * 1.9,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 5,
                          ),
                          buildPhoneNumberField(
                            validateFunction: validateMobileNumber,
                            isValidate: true,
                            updateCountryCodeFunction: updateCountryCode,
                            controller: mobileNumberController,
                            currentFocusNode: mobileNumberFocus,
                            textInputAction: TextInputAction.done,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          GestureDetector(
                            onTap: () => resetPassword(context),
                            child: buildPillButton(
                              label: 'RESET PASSWORD',
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 8,
                  ),
                  Center(
                    child: GestureDetector(
                      onTap: () => goToLoginScreen(context),
                      child: Text(
                        'I REMEMBER MY PASSWORD',
                        style: TextStyle(
                          color: blackColor,
                          fontSize: SizeConfig.textMultiplier! * 1.9,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
