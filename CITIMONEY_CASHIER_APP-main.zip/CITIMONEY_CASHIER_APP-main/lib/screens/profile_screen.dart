import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/blocs/profile/profile_bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/requests/change_password_request_dto.dart';
import 'package:change_money_cashier_app/data/models/requests/update_profile_request.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/screens/drawer_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/utils/string_utils.dart';
import 'package:change_money_cashier_app/widgets/curve_left.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/profile_detail_item.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:change_money_cashier_app/widgets/update_password_bottom_sheet.dart';
import 'package:change_money_cashier_app/widgets/update_profile_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  ProfileBloc? profileBloc;
  LoginBloc? authBloc;
  String? firstName = '';
  String? lastName = '';
  String? email = '';
  String? role = 'ROLE_GUEST';
  String? mobileNumber = '';
  String? mobileNumberCountryCode = '';
  bool isAlertboxOpened = false;
  late String username = 'N/A';
  late String fullName = 'N/A';
  bool isDrawerOpen = false;
  double scaleFactor = 1;
  double xOffset = 0;
  double yOffset = 0;
  goBack() {
    Navigator.pop(context);
  }

  void showUpdatePasswordBottomSheet() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return Container(
              height: MediaQuery.of(context).size.height * 0.7,
              child: UpdatePassswordBottomSheet());
        }).then((value) {
      if (value is ChangePasswordRequestDTO) {
        FocusManager.instance.primaryFocus?.unfocus();
        authBloc!.add(
          ChangePasswordEvent(
            request: value,
          ),
        );
      }
    });
  }

  void showUpdateProfileBottomSheet() {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return Container(
              height: MediaQuery.of(context).size.height * 0.7,
              child: UpdateProfileBottomSheet(
                firstName: this.firstName!,
                lastName: this.lastName!,
                email: this.email != null ? this.email! : null,
                mobileNumber: this.mobileNumber,
                mobileNumberCountryCode: this.mobileNumberCountryCode,
              ));
        }).then((value) {
      if (value is UpdateProfileRequestDTO) {
        FocusManager.instance.primaryFocus?.unfocus();
        profileBloc!.add(
          ProfileUpdateEvent(
            request: value,
          ),
        );
      }
    });
  }

  @override
  void initState() {
    super.initState();
    profileBloc = getItInstance<ProfileBloc>();
    authBloc = getItInstance<LoginBloc>();
    profileBloc!.add(ProfileInitialEvent());
    loadUsername();
  }

  loadUsername() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String firstName = await sharedPreferencesUtil.getFirstName();
    String lastName = await sharedPreferencesUtil.getLastName();
    setState(() {
      this.username = '$firstName';
      this.fullName = '$firstName $lastName';
    });
  }

  openDrawer() {
    setState(() {
      xOffset = SizeConfig.widthMultiplier! * 60;
      yOffset = SizeConfig.heightMultiplier! * 10;
      scaleFactor = 0.8;

      isDrawerOpen = true;
    });
  }

  void closeDrawer() {
    setState(() {
      xOffset = 0;
      yOffset = 0;
      scaleFactor = 1;
      isDrawerOpen = false;
    });
  }

  @override
  void dispose() {
    super.dispose();
    profileBloc?.close();
    authBloc?.close();
  }

  handleLogicStates(
    ProfileState state,
    BuildContext context,
    LoginState authState,
  ) {
    if (authState is LoginChangePasswordError) {
      if (authState.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          authBloc!.emit(LoginChangePasswordErrorDone());
          showErrorMessage(context,
              message: authState.errorMessage!, title: 'Error');
        });
      }
      if (authState.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            authBloc!.emit(LoginChangePasswordErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: authState.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.showUpdatePasswordBottomSheet();
              }
            });
          }
        });
      }
    }
    if (state is LoginChangePasswordDone) {
      showErrorMessage(
        context,
        message: 'Password Updated Successfully',
        title: 'INFO',
        backgroundColor: secondaryColor,
      );
    }
    if (state is ProfileUpdateDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.firstName = state.request.firstName;

          this.lastName = state.request.surname;
          this.email = state.request.email;
          this.mobileNumber = state.request.mobileNumber;
          this.mobileNumberCountryCode = state.request.mobileNumberCountryCode;
        });
      });
      profileBloc!.emit(ProfileErrorDone());
    }
    if (state is ProfileError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          profileBloc!.emit(ProfileErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            profileBloc!.emit(ProfileErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                profileBloc!.add(ProfileInitialEvent());
                // profileBloc!.add(
                //   ProfileUpdateEvent(
                //     request: UpdateProfileRequestDTO(
                //       email: this.email!,
                //       firstName: this.firstName!,
                //       surname: this.lastName!,
                //     ),
                //   ),
                // );
              }
            });
          }
        });
      }
    }
    if (state is ProfileInitialDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.firstName = state.firstName;
          this.role = state.role;
          this.lastName = state.lastName;
          if (state.email != null && state.email.isNotEmpty) {
            this.email = state.email;
          } else {
            this.email = null;
          }
          this.mobileNumber = state.mobileNumber;
          this.mobileNumberCountryCode = state.mobileNumberCountryCode;
        });
        profileBloc!.emit(ProfileReady());
      });
    }
    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => profileBloc!,
        ),
        BlocProvider(
          create: (context) => authBloc!,
        ),
      ],
      child: BlocBuilder<ProfileBloc, ProfileState>(
          bloc: profileBloc!,
          buildWhen: (ProfileState previous, ProfileState current) =>
              previous != current,
          builder: (context, state) {
            return BlocBuilder<LoginBloc, LoginState>(
              bloc: authBloc,
              buildWhen: (LoginState previous, LoginState current) =>
                  previous != current,
              builder: (context, authState) {
                return Stack(
                  children: [
                    bodyContent(state: state),
                    state is ProfileLoading
                        ? LoadingScreen(text: state.loadingText)
                        : SizedBox.shrink(),
                    authState is AuthLoading
                        ? LoadingScreen(text: authState.loadingText)
                        : SizedBox.shrink(),
                    handleLogicStates(state, context, authState),
                  ],
                );
              },
            );
          }),
    );
  }

  bodyContent({required ProfileState state}) {
    return Scaffold(
      backgroundColor: whiteishColor,
      body: Stack(
        children: [
          DrawerScreen(
            closeDrawerFunction: this.closeDrawer,
            pageIndex: 'IS_PROFILE',
            username: this.username,
          ),
          GestureDetector(
            onTap: closeDrawer,
            child: AnimatedContainer(
              duration: Duration(milliseconds: 250),
              transform: Matrix4.translationValues(xOffset, yOffset, 0)
                ..scale(scaleFactor),
              height: MediaQuery.of(context).size.height,
              width: double.infinity,
              decoration: BoxDecoration(
                border: isDrawerOpen
                    ? Border.all(
                        color: whiteColor,
                        width: SizeConfig.widthMultiplier! * 0.3,
                      )
                    : null,
                borderRadius: BorderRadius.circular(
                  isDrawerOpen ? SizeConfig.imageSizeMultiplier! * 8 : 0,
                ),
                color: whiteColor,
              ),
              child: SafeArea(
                child: Stack(
                  children: [
                    Column(
                      children: [
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 4,
                        ),
                        Center(
                          child: Text(
                            'Profile Details',
                            style: TextStyle(
                              color: primaryColor,
                              fontSize: SizeConfig.textMultiplier! * 2.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 5,
                        ),
                        Container(
                          height: SizeConfig.heightMultiplier! * 14,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.transparent,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: primaryColor,
                              width: SizeConfig.textMultiplier! * 0.4,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: primaryColor.withOpacity(0.3),
                                blurRadius: 6.0,
                              ),
                            ],
                          ),
                          child: Container(
                            height: SizeConfig.heightMultiplier! * 14,
                            width: double.infinity,
                            padding: EdgeInsets.all(
                              SizeConfig.imageSizeMultiplier! * 3,
                            ),
                            decoration: BoxDecoration(
                              color: whiteColor,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: primaryColor,
                                width: SizeConfig.textMultiplier! * 0.1,
                              ),
                            ),
                            child: Image.asset(
                              'assets/images/avatar_picture.png',
                              fit: BoxFit.contain,
                            ),

                            //  CircleAvatar(
                            //   backgroundImage: AssetImage(
                            //     'assets/images/avatar_picture.png',

                            //   ),
                            //   radius: SizeConfig.imageSizeMultiplier! * 2,
                            //   backgroundColor: Colors.transparent,
                            // ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 2,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.widthMultiplier! * 5,
                          ),
                          child: Text(
                            '${this.firstName!.capitalize()} ${this.lastName!.capitalize()} ',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: primaryColor,
                              fontSize: SizeConfig.textMultiplier! * 2.6,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 3,
                        ),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                height: this.role != 'ROLE_GUEST'
                                    ? SizeConfig.heightMultiplier! * 45
                                    : SizeConfig.heightMultiplier! * 16,
                                width: double.infinity,
                                margin: EdgeInsets.symmetric(
                                  horizontal: SizeConfig.widthMultiplier! * 5,
                                ),
                                padding: EdgeInsets.only(
                                  right: SizeConfig.widthMultiplier! * 5,
                                  left: SizeConfig.widthMultiplier! * 5,
                                  top: SizeConfig.heightMultiplier! * 1,
                                ),
                                decoration: BoxDecoration(
                                  // boxShadow: [
                                  //   BoxShadow(
                                  //     color: blackColor.withOpacity(0.05),
                                  //     blurRadius: 2.0,
                                  //     spreadRadius: 3.0,
                                  //   )
                                  // ],
                                  color: whiteColor,
                                  borderRadius: BorderRadius.circular(
                                    SizeConfig.imageSizeMultiplier! * 3,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Account Information',
                                      style: TextStyle(
                                        color: secondaryColor,
                                        fontSize:
                                            SizeConfig.textMultiplier! * 2,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    buildProfileDetailItem(
                                      label: 'Full Name',
                                      value:
                                          '${this.firstName!.capitalize()} ${this.lastName!.capitalize()}',
                                    ),
                                    buildProfileDetailItem(
                                      label: 'Email Address',
                                      isValueCapitalized: false,
                                      value:
                                          '${this.email == null || this.email!.isEmpty ? 'N/A' : this.email}',
                                    ),
                                    this.role == 'ROLE_GUEST'
                                        ? SizedBox.shrink()
                                        : buildProfileDetailItem(
                                            label: 'Phone Number',
                                            value:
                                                '+${this.mobileNumber!.isEmpty ? 'N/A' : this.mobileNumber}',
                                          ),
                                    this.role != 'ROLE_GUEST'
                                        ? GestureDetector(
                                            onTap: showUpdateProfileBottomSheet,
                                            child: buildPillButton(
                                              label: 'Update Profile',
                                              labelColor: whiteColor,
                                            ),
                                          )
                                        : SizedBox.shrink(),
                                    this.role != 'ROLE_GUEST'
                                        ? GestureDetector(
                                            onTap:
                                                showUpdatePasswordBottomSheet,
                                            child: buildPillButton(
                                              label: 'Change Password',
                                              backgroundColor: primaryColor,
                                            ),
                                          )
                                        : SizedBox.shrink(),
                                    SizedBox(
                                      height: SizeConfig.heightMultiplier! * 3,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                    buildLeftCurve(
                      leftButtonFunction:
                          isDrawerOpen ? closeDrawer : openDrawer,
                      isOpen: isDrawerOpen,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
