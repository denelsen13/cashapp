import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:change_money_cashier_app/blocs/notification/notification_bloc.dart';
import 'package:change_money_cashier_app/blocs/socket/socket_bloc.dart';
import 'package:change_money_cashier_app/data/models/notification_result_model.dart';
import 'package:change_money_cashier_app/data/models/requests/update_notifications_read_status_request.dart';
import 'package:change_money_cashier_app/data/models/responses/notification_paged_response.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:change_money_cashier_app/screens/profile_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/carbon_icons_icons.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/utils/string_utils.dart';
import 'package:change_money_cashier_app/widgets/curve_left.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/notification_card.dart';
import 'package:change_money_cashier_app/widgets/notification_detail_modal.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/search_box.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:change_money_cashier_app/widgets/update_password_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  _NotificationsScreenState createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen>
    with WidgetsBindingObserver {
  NotificationBloc? notificationBloc;
  SocketBloc? socketBloc;
  bool isSearch = false;
  TextEditingController searchController = new TextEditingController();
  bool isAlertboxOpened = false;
  int pageNumber = 0;
  ScrollController? _controller;
  List<NotificationResultModel> notifications = [];
  List<NotificationResultModel> searchNotifications = [];
  bool isLoading = false;
  NotificationPagedResponse? pagedNotifications =
      NotificationPagedResponse.empty();
  String loadingText = '';
  void showUpdatePasswordBottomSheet() {
    showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (BuildContext bc) {
          return UpdatePassswordBottomSheet();
        }).then((value) => {});
  }

  logout() {
    Navigator.pushReplacementNamed(context, RouteList.login);
  }

  goToProfileScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileScreen(),
      ),
    );
  }

  openNotificationDetails(NotificationResultModel notification) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => NotificationDetailModal(
        notification: notification,
      ),
    ).then((value) {
      if (!notification.readStatus) {
        notificationBloc!.add(
          UpdateSingleNotificationsReadStatusEvent(
            notificationId: notification.id,
          ),
        );
      }
    });
  }

  markAllAsRead() {
    List<int> unReadIds = [];
    this.notifications.forEach((element) {
      if (!element.readStatus) {
        unReadIds.add(element.id);
      }
    });
    if (unReadIds.length > 0) {
      notificationBloc!.add(
        UpdateNotificationsReadStatusEvent(
          request:
              UpdateNotificationsReadStatusRequest(notificationIds: unReadIds),
        ),
      );
    }
  }

  goBack() {
    Navigator.pop(context);
  }

  getNotifications() {
    notificationBloc!.add(
      GetAllNotificationsEvent(
        pageNumber: pageNumber,
      ),
    );
  }

  loadMore() {
    setState(() {
      pageNumber = pageNumber + 1;
    });

    notificationBloc!.add(
      GetMoreNotificationsEvent(
        pageNumber: pageNumber,
      ),
    );
  }

  filterNotifications(String searchQuery) {
    if (searchQuery != null && searchQuery.isNotEmpty) {
      searchNotifications.length = 0;
      this.notifications.forEach((p) {
        if (p.message.containsIgnoreCase(searchQuery)) {
          searchNotifications.add(p);
        }
      });
      setState(() {
        isSearch = true;
      });
    } else {
      setState(() {
        isSearch = false;
      });
    }
  }

  @override
  void initState() {
    _controller = ScrollController();
    super.initState();
    WidgetsBinding.instance!.addObserver(this);
    notificationBloc = getItInstance<NotificationBloc>();
    socketBloc = getItInstance<SocketBloc>();
    notificationBloc!.add(
      GetAllNotificationsEvent(
        pageNumber: this.pageNumber,
      ),
    );
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    socketBloc!.add(UpdateAppStatusSocketEvent(
        isActive: state == AppLifecycleState.resumed));
  }

  handleLogicStates(
    NotificationState state,
    BuildContext context,
    SocketState socketState,
  ) {
    if (socketState is NewNotificationSocketDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.notifications.insert(0, socketState.notification);
        });
      });
      socketBloc!.emit(NewNotificationSocketReceivedDone());
    }
    if (state is UpdateSingleNotificationsReadStatusDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          int foundIndex = this
              .notifications
              .indexWhere((element) => element.id == state.notificationId);
          if (foundIndex != -1) {
            this.notifications[foundIndex].readStatus = true;
          }
        });
      });
      notificationBloc!.emit(FetchUpdatedDone());
    }
    if (state is UpdateNotificationsReadStatusDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.notifications.forEach((element) {
            element.readStatus = true;
          });
        });
      });
      notificationBloc!.emit(FetchUpdatedDone());
    }
    if (state is NotificationsLoading) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.isLoading = true;
          this.loadingText = state.loadingText;
        });
      });
    }
    if (state is GetAllNotificationsDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.pagedNotifications = state.notifications;
          this.notifications = state.notifications.notifications!;
          this.isLoading = false;
        });
      });
      notificationBloc!.emit(FetchUpdatedDone());
    }

    if (state is GetMoreNotificationsDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.pagedNotifications = state.notifications;
          this.notifications.addAll(state.notifications.notifications!);
          this.isLoading = false;
        });
      });
      notificationBloc!.emit(FetchUpdatedDone());
    }

    if (state is NotificationsError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          notificationBloc!.emit(NotificationsErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
          setState(() {
            this.isLoading = false;
          });
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
              this.isLoading = false;
            });
            notificationBloc!.emit(NotificationsErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.getNotifications();
              }
            });
          }
        });
      }
    }
    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => notificationBloc!,
        ),
        BlocProvider(
          create: (context) => socketBloc!,
        ),
      ],
      child: BlocBuilder<NotificationBloc, NotificationState>(
        bloc: notificationBloc,
        buildWhen: (NotificationState previous, NotificationState current) =>
            previous != current,
        builder: (context, state) {
          return BlocBuilder<SocketBloc, SocketState>(
            bloc: socketBloc,
            buildWhen: (SocketState previous, SocketState current) =>
                previous != current,
            builder: (context, socketState) {
              return Stack(
                children: [
                  bodyContent(state: state),
                  state is NotificationsMarkLoading
                      ? LoadingScreen(text: state.loadingText)
                      : SizedBox.shrink(),
                  handleLogicStates(state, context, socketState),
                ],
              );
            },
          );
        },
      ),
    );
  }

  bodyContent({required NotificationState state}) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.dark,
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 2,
                  ),
                  Container(
                    height: SizeConfig.heightMultiplier! * 8,
                    child: Stack(
                      children: [
                        Center(
                          child: Text(
                            'My Notifications',
                            style: TextStyle(
                                color: primaryColor,
                                fontSize: SizeConfig.textMultiplier! * 2.5,
                                fontWeight: FontWeight.w600,
                                height: SizeConfig.heightMultiplier! * 0.13),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: GestureDetector(
                            onTap: goToProfileScreen,
                            child: Container(
                              height: SizeConfig.heightMultiplier! * 5,
                              width: SizeConfig.heightMultiplier! * 5,
                              margin: EdgeInsets.only(
                                  right: SizeConfig.widthMultiplier! * 5),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: whiteColor,
                                border: Border.all(
                                  color: whiteColor,
                                  width: SizeConfig.widthMultiplier! * 0.1,
                                ),
                              ),
                              child: CircleAvatar(
                                backgroundImage: AssetImage(
                                  'assets/images/avatar.png',
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 8,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 8,
                    ),
                    child: buildSearchBox(
                      hintText: 'Search for Notifications',
                      controller: searchController,
                      onChangeFunction: filterNotifications,
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 3,
                  ),
                  (this.notifications.length > 0 &&
                          this.notifications.indexWhere(
                                  (element) => !element.readStatus) !=
                              -1)
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            GestureDetector(
                              onTap: markAllAsRead,
                              child: Padding(
                                padding: EdgeInsets.symmetric(
                                  horizontal: SizeConfig.widthMultiplier! * 5,
                                ),
                                child: Text(
                                  'Mark All as Read',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    color: primaryColor,
                                    fontSize: SizeConfig.textMultiplier! * 2,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : SizedBox.shrink(),
                  this.isLoading
                      ? Container(
                          height: SizeConfig.heightMultiplier! * 40,
                          width: double.infinity,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Image.asset(
                                'assets/images/loading2.gif',
                                width: double.infinity,
                                height: SizeConfig.heightMultiplier! * 30,
                              ),
                              AnimatedTextKit(
                                  repeatForever:
                                      true, //this will ignore [totalRepeatCount]
                                  pause: Duration(seconds: 1),
                                  animatedTexts: [
                                    TypewriterAnimatedText(
                                      loadingText,
                                      textStyle: TextStyle(
                                        fontSize:
                                            2 * SizeConfig.textMultiplier!,
                                        color: primaryColor,
                                      ),
                                    ),
                                    TypewriterAnimatedText(
                                      loadingText,
                                      textStyle: TextStyle(
                                          fontSize:
                                              2 * SizeConfig.textMultiplier!,
                                          color: primaryColor),
                                    ),
                                    TypewriterAnimatedText(
                                      loadingText,
                                      textStyle: TextStyle(
                                        fontSize:
                                            2 * SizeConfig.textMultiplier!,
                                        color: primaryColor,
                                      ),
                                    )
                                  ],
                                  // speed: Duration(milliseconds: 100),

                                  displayFullTextOnTap: true,
                                  stopPauseOnTap: true),
                            ],
                          ),
                        )
                      : SizedBox.shrink(),
                  (this.notifications.length == 0 && !this.isLoading)
                      ? Container(
                          height: SizeConfig.heightMultiplier! * 60,
                          width: double.infinity,
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  CarbonIcons.notification__off,
                                  color: greyColor,
                                  size: SizeConfig.imageSizeMultiplier! * 15,
                                ),
                                SizedBox(
                                  height: SizeConfig.heightMultiplier! * 3,
                                ),
                                Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal:
                                          SizeConfig.widthMultiplier! * 8),
                                  child: Text(
                                    'You do not have any notifications right now',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: greyColor,
                                      fontSize:
                                          SizeConfig.textMultiplier! * 2.5,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        )
                      : !this.isLoading
                          ? Expanded(
                              child: this.isSearch
                                  ? ListView.builder(
                                      padding: EdgeInsets.symmetric(
                                        horizontal:
                                            SizeConfig.widthMultiplier! * 5,
                                        vertical:
                                            SizeConfig.heightMultiplier! * 1,
                                      ),
                                      itemCount:
                                          this.searchNotifications.length + 1,
                                      itemBuilder: (context, index) {
                                        return (index ==
                                                this.searchNotifications.length)
                                            ? !pagedNotifications!.last
                                                ? buildPillButton(
                                                    label: 'Load More')
                                                : SizedBox.shrink()
                                            : GestureDetector(
                                                onTap: () =>
                                                    openNotificationDetails(
                                                        this.searchNotifications[
                                                            index]),
                                                child: buildNotificationsCard(
                                                  isActive: !this
                                                      .searchNotifications[
                                                          index]
                                                      .readStatus,
                                                  time: this
                                                      .searchNotifications[
                                                          index]
                                                      .time,
                                                  message: this
                                                      .searchNotifications[
                                                          index]
                                                      .message,
                                                  title: this
                                                      .searchNotifications[
                                                          index]
                                                      .title,
                                                  index: index,
                                                ),
                                              );
                                      },
                                    )
                                  : ListView.builder(
                                      padding: EdgeInsets.symmetric(
                                        horizontal:
                                            SizeConfig.widthMultiplier! * 5,
                                        vertical:
                                            SizeConfig.heightMultiplier! * 1,
                                      ),
                                      itemCount: this.notifications.length + 1,
                                      itemBuilder: (context, index) {
                                        return (index ==
                                                this.notifications.length)
                                            ? !pagedNotifications!.last
                                                ? GestureDetector(
                                                    onTap: loadMore,
                                                    child: buildPillButton(
                                                      label: 'Load More',
                                                    ),
                                                  )
                                                : SizedBox.shrink()
                                            : GestureDetector(
                                                onTap: () =>
                                                    openNotificationDetails(this
                                                        .notifications[index]),
                                                child: buildNotificationsCard(
                                                  isActive: !this
                                                      .notifications[index]
                                                      .readStatus,
                                                  message: this
                                                      .notifications[index]
                                                      .message,
                                                  title: this
                                                      .notifications[index]
                                                      .title,
                                                  time: this
                                                      .notifications[index]
                                                      .time,
                                                  index: index,
                                                ),
                                              );
                                      },
                                    ),
                            )
                          : SizedBox.shrink()
                ],
              ),
              buildLeftCurve(
                leftButtonFunction: goBack,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
