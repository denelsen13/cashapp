import 'dart:ui';

import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/widgets/custom_phone_number_field.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl_phone_field/countries.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:change_money_cashier_app/data/models/signup_request.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/encoder_util.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  LoginBloc? authBloc;
  bool isAlertboxOpened = false;
  final _formKey = GlobalKey<FormState>();
  String countryCode = 'zw';
  String countryDial = '+263';
  TextEditingController mobileNumberController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  TextEditingController confirmPasswordController = new TextEditingController();
  TextEditingController firstNameController = new TextEditingController();
  TextEditingController lastNameController = new TextEditingController();
  final passwordFocus = FocusNode();
  final confirmPasswordFocus = FocusNode();
  final firstNameFocus = FocusNode();
  final lastNameFocus = FocusNode();
  final mobileNumberFocus = FocusNode();

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  goback(context) {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.pop(context);
  }

  goToLoginScreen(context) {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.pushNamed(
      context,
      RouteList.login,
    );
  }

  signup(context) async {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate()) {
      String appSignature = await SmsAutoFill().getAppSignature;
      SignupRequestDTO request = SignupRequestDTO(
        appSignature: appSignature,
        password: EncoderUtil.threefoldBase64Encode(passwordController.text),
        firstName: firstNameController.text,
        surname: lastNameController.text,
        mobileNumberCountryCode: countryCode.toUpperCase(),
        mobileNumber:
            '${countryDial.substring(1)}${mobileNumberController.text}',
      );
      authBloc!.add(
        SignupEvent(
          request: request,
        ),
      );
    }
  }

  updateCountryCode(countryCode) {
    setState(() {
      this.countryCode = countryCode;
    });
  }

  validateMobileNumber(mobileNumber) {
    print(this.countryCode);
    print("The COuntry Code");
    Country _selectedCountry = countries.firstWhere((element) =>
        element.code.toUpperCase() == this.countryCode.toUpperCase());

    if (mobileNumber == null) {
      return 'mobile number cannot be empty';
    } else if (mobileNumber.isEmpty) {
      return 'mobile number cannot be empty';
    } else if (mobileNumber.length < _selectedCountry.maxLength ||
        mobileNumber.length > _selectedCountry.minLength) {
      return 'mobile number is not valid';
    }
  }

  validateFirstName(name) {
    if (name == null) {
      return 'First Name cannot be empty';
    } else if (name.isEmpty) {
      return 'First Name cannot be empty';
    } else if (name.length < 1) {
      return 'First Name length cannot be less than 1';
    } else if (name.length > 25) {
      return 'First Name length cannot be more than 25';
    }
  }

  validateLastName(name) {
    if (name == null) {
      return 'Last Name cannot be empty';
    } else if (name.isEmpty) {
      return 'Last Name cannot be empty';
    } else if (name.length < 1) {
      return 'Last Name length cannot be less than 1';
    } else if (name.length > 25) {
      return 'Last Name length cannot be more than 25';
    }
  }

  validatePassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
  }

  validateConfirmPassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
    if (this.passwordController.text != pin) {
      return 'passwords dont match';
    }
  }

  @override
  void initState() {
    super.initState();
    authBloc = getItInstance<LoginBloc>();
    authBloc!.add(SignupLoadEvent());

    setState(() {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: primaryColor,
      ));
    });
  }

  @override
  void dispose() {
    super.dispose();
    authBloc?.close();
  }

  handleLogicStates(LoginState state, BuildContext context) {
    if (state is SignupError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          authBloc!.emit(SignupErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            authBloc!.emit(SignupErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.signup(context);
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => authBloc!,
      child: BlocBuilder<LoginBloc, LoginState>(
        bloc: authBloc,
        buildWhen: (LoginState previous, LoginState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is AuthLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              handleLogicStates(state, context),
            ],
          );
        },
      ),
    );
  }

  bodyContent({required LoginState state}) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                  'assets/images/background2.jpg',
                ),
                fit: BoxFit.cover,
              ),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
              child: new Container(
                decoration:
                    new BoxDecoration(color: Colors.white.withOpacity(0.0)),
              ),
            ),
          ),
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(color: primaryColor.withOpacity(0.2)),
          ),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 5,
                vertical: SizeConfig.heightMultiplier! * 2,
              ),
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Container(
                    width: double.infinity,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () => goback(context),
                                child: Icon(
                                  Ionicons.ion_ios_arrow_back,
                                  size: SizeConfig.imageSizeMultiplier! * 9,
                                  color: whiteColor,
                                ),
                              ),
                            ],
                          ),
                          Center(
                            child: Image.asset(
                              'assets/images/logo.png',
                              height: SizeConfig.heightMultiplier! * 12,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          Text(
                            'Sign Up',
                            style: TextStyle(
                              color: whiteColor,
                              fontSize: SizeConfig.textMultiplier! * 4,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          buildCustomTextField(
                            hintText: 'First Name',
                            validateFunction: validateFirstName,
                            isValidate: true,
                            controller: firstNameController,
                            currentFocusNode: firstNameFocus,
                            focusChangeFunction: changeFocus,
                            nextFocusNode: lastNameFocus,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1.5,
                          ),
                          buildCustomTextField(
                            hintText: 'Last Name',
                            validateFunction: validateLastName,
                            isValidate: true,
                            controller: lastNameController,
                            currentFocusNode: lastNameFocus,
                            focusChangeFunction: changeFocus,
                            nextFocusNode: mobileNumberFocus,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1.5,
                          ),
                          buildPhoneNumberField(
                            validateFunction: validateMobileNumber,
                            isValidate: true,
                            updateCountryCodeFunction: updateCountryCode,
                            controller: mobileNumberController,
                            currentFocusNode: mobileNumberFocus,
                            focusChangeFunction: changeFocus,
                            nextFocusNode: passwordFocus,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1.5,
                          ),
                          buildCustomTextField(
                            hintText: 'Password',
                            obsecureText: true,
                            validateFunction: validatePassword,
                            isValidate: true,
                            controller: passwordController,
                            currentFocusNode: passwordFocus,
                            focusChangeFunction: changeFocus,
                            nextFocusNode: confirmPasswordFocus,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1.5,
                          ),
                          buildCustomTextField(
                            hintText: 'Confirm Password',
                            obsecureText: true,
                            validateFunction: validateConfirmPassword,
                            isValidate: true,
                            controller: confirmPasswordController,
                            currentFocusNode: confirmPasswordFocus,
                            textInputAction: TextInputAction.done,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          GestureDetector(
                            onTap: () => signup(context),
                            child: buildPillButton(
                              label: 'SIGN UP',
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
