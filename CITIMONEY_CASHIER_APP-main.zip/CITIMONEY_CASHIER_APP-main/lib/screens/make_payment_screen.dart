import 'package:change_money_cashier_app/screens/profile_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/curve_left.dart';
import 'package:flutter/material.dart';

class MakePaymentScreen extends StatefulWidget {
  const MakePaymentScreen({Key? key}) : super(key: key);

  @override
  State<MakePaymentScreen> createState() => _MakePaymentScreenState();
}

class _MakePaymentScreenState extends State<MakePaymentScreen> {
  goback() {
    Navigator.pop(context);
  }

  goToProfileScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              height: SizeConfig.heightMultiplier! * 100,
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 5,
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 2,
                  ),
                  Container(
                    height: SizeConfig.heightMultiplier! * 8,
                    child: Stack(
                      children: [
                        Center(
                          child: Text(
                            'Make Payment',
                            style: TextStyle(
                                color: primaryColor,
                                fontSize: SizeConfig.textMultiplier! * 2.5,
                                fontWeight: FontWeight.w600,
                                height: SizeConfig.heightMultiplier! * 0.13),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: GestureDetector(
                            onTap: goToProfileScreen,
                            child: Container(
                              height: SizeConfig.heightMultiplier! * 5,
                              width: SizeConfig.heightMultiplier! * 5,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: whiteColor,
                                border: Border.all(
                                  color: whiteColor,
                                  width: SizeConfig.widthMultiplier! * 0.1,
                                ),
                              ),
                              child: CircleAvatar(
                                backgroundImage: AssetImage(
                                  'assets/images/avatar.png',
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            buildLeftCurve(
              leftButtonFunction: goback,
            ),
          ],
        ),
      ),
    );
  }
}
