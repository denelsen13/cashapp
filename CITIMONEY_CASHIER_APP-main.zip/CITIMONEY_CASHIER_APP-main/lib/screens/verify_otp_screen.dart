import 'dart:ui';

import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/widgets/countdown_timer.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sms_autofill/sms_autofill.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';

class VerifyOtpScreen extends StatefulWidget {
  const VerifyOtpScreen({Key? key}) : super(key: key);

  @override
  _VerifyOtpScreenState createState() => _VerifyOtpScreenState();
}

class _VerifyOtpScreenState extends State<VerifyOtpScreen> {
  LoginBloc? authBloc;
  bool isAlertboxOpened = false;
  bool isRegistration = false;
  TextEditingController otpController = new TextEditingController();
  final _formKey = GlobalKey<FormState>();
  int resendCount = 0;
  bool showResendButton = false;
  GlobalKey<CountDownTimerState> countdownKey = GlobalKey();
  getCountDownMilliseconds() {
    if (resendCount == 1) {
      return 15;
    } else if (resendCount == 2) {
      return 30;
    } else if (resendCount == 3) {
      return 60;
    } else if (resendCount == 4) {
      return 90;
    } else if (resendCount == 5) {
      return 120;
    } else if (resendCount == 6) {
      return 300;
    } else if (resendCount == 7) {
      return 3000;
    } else {
      return 60000;
    }
  }

  resetPasswordVerifyOtp() {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate() &&
        otpController.text != null &&
        otpController.text.isNotEmpty &&
        otpController.text.length == 6) {
      authBloc!.add(
        ResetPasswordVerifyOtpEvent(
          otp: otpController.text,
        ),
      );
    }
  }

  verifyOtp(BuildContext context) {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate() &&
        otpController.text != null &&
        otpController.text.isNotEmpty &&
        otpController.text.length == 6) {
      authBloc!.add(
        VerifyOtpEvent(
          otp: otpController.text,
        ),
      );
    }
  }

  processStopWatch() {
    int countDownMilliseconds = getCountDownMilliseconds();
    setState(() {
      showResendButton = false;
    });
    countdownKey.currentState!.startCountdown(countDownMilliseconds);
  }

  resendOtp(BuildContext context) async {
    FocusScope.of(context).requestFocus(FocusNode());
    setState(() {
      this.resendCount = this.resendCount + 1;
    });

    await SmsAutoFill().listenForCode;
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String mobileNumber = await sharedPreferencesUtil.getMobileNumber();
    if (mobileNumber != null && mobileNumber.isNotEmpty) {
      authBloc!.add(
        ResendOtpEvent(
          mobileNumber: mobileNumber,
        ),
      );
      this.processStopWatch();
    }
  }

  goback(context) {
    Navigator.pop(context);
  }

  goToChangePasswordScreen(context) {
    Navigator.pushNamed(
      context,
      RouteList.changePassword,
    );
  }

  goToHomeScreen(context) {
    Navigator.pushNamed(
      context,
      RouteList.home,
    );
  }

  goToLoginScreen(context) {
    Navigator.pushNamed(
      context,
      RouteList.login,
    );
  }

  @override
  void initState() {
    super.initState();
    authBloc = getItInstance<LoginBloc>();
    // this.startListeningForSMS();
    authBloc!.add(VerifyOtpLoadEvent());

    new Future.delayed(Duration.zero, () {
      final isRegistration = ModalRoute.of(context)!.settings.arguments as bool;
      setState(() {
        this.isRegistration = isRegistration;
        this.processStopWatch();
        this.resendCount = this.resendCount + 1;
      });
    });
    setState(() {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
        statusBarColor: primaryColor,
      ));
    });
  }

  @override
  void dispose() async {
    super.dispose();
    authBloc?.close();
    // _stopWatchTimer.onExecute.add(StopWatchExecute.stop);
    // await _stopWatchTimer.dispose();
    SmsAutoFill().unregisterListener();
  }

  startListeningForSMS() async {
    await SmsAutoFill().listenForCode;
  }

  handleLogicStates(LoginState state, BuildContext context) {
    if (state is VerifyOtpError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          authBloc!.emit(LoginErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            authBloc!.emit(LoginErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.isRegistration
                    ? this.verifyOtp(context)
                    : this.resetPasswordVerifyOtp();
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => authBloc!,
      child: BlocBuilder<LoginBloc, LoginState>(
        bloc: authBloc,
        buildWhen: (LoginState previous, LoginState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is AuthLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              handleLogicStates(state, context),
            ],
          );
        },
      ),
    );
  }

  bodyContent({required LoginState state}) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(color: whiteColor),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
              child: new Container(
                decoration:
                    new BoxDecoration(color: Colors.white.withOpacity(0.0)),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 5,
                vertical: SizeConfig.heightMultiplier! * 3,
              ),
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Container(
                    width: double.infinity,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () => goback(context),
                                child: Icon(
                                  Ionicons.ion_ios_arrow_back,
                                  size: SizeConfig.imageSizeMultiplier! * 9,
                                  color: blackColor,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 5,
                          ),
                          Center(
                            child: Image.asset(
                              'assets/images/logo_black.png',
                              height: SizeConfig.heightMultiplier! * 12,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 5,
                          ),
                          Text(
                            'Verify Account',
                            style: TextStyle(
                              color: blackColor,
                              fontSize: SizeConfig.textMultiplier! * 4,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1.5,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: SizeConfig.widthMultiplier! * 10),
                            child: Text(
                              'Stay on screen OTP will autofill else Enter OTP sent to your phone number to verify account',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: blackColor,
                                fontSize: SizeConfig.textMultiplier! * 1.9,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 5,
                          ),
                          PinFieldAutoFill(
                            controller: otpController,
                            cursor: Cursor(
                                color: primaryColor, enabled: true, width: 1),
                            currentCode: "",
                            codeLength: 6,
                            decoration: UnderlineDecoration(
                                colorBuilder: PinListenColorBuilder(
                                  primaryColor,
                                  blackColor,
                                ),
                                textStyle: TextStyle(
                                  color: blackColor,
                                  fontSize: SizeConfig.textMultiplier! * 2.5,
                                )),
                            onCodeChanged: (code) {
                              if (code!.isNotEmpty && code.length == 6) {
                                new Future.delayed(Duration(milliseconds: 150),
                                    () {
                                  this.isRegistration
                                      ? this.verifyOtp(context)
                                      : this.resetPasswordVerifyOtp();
                                });
                              }
                            },
                          ),
                          // buildCustomTextField(
                          //   hintText: 'Enter OTP',
                          //   isNumber: true,
                          // ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          GestureDetector(
                            onTap: this.isRegistration
                                ? () => verifyOtp(context)
                                : () => resetPasswordVerifyOtp(),
                            child: buildPillButton(
                              label: 'VERIFY OTP',
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          GestureDetector(
                            onTap: showResendButton
                                ? () => resendOtp(context)
                                : () {},
                            child: buildPillButton(
                              label: 'Resend OTP',
                              backgroundColor: whiteColor,
                              labelColor:
                                  showResendButton ? primaryColor : greyColor,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          CountDownTimer(
                            key: countdownKey,
                            secondsRemaining: getCountDownMilliseconds(),
                            whenTimeExpires: () {
                              setState(() {
                                showResendButton = true;
                              });
                            },
                            countDownTimerStyle: TextStyle(
                              color: blackColor,
                              fontSize: SizeConfig.textMultiplier! * 2.6,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  !showResendButton
                      ? SizedBox(
                          height: SizeConfig.heightMultiplier! * 22,
                        )
                      : SizedBox(
                          height: SizeConfig.heightMultiplier! * 16,
                        ),
                  // Center(
                  //   child: GestureDetector(
                  //     onTap: () => goToLoginScreen(context),
                  //     child: Text(
                  //       'I REMEMBER MY PASSWORD',
                  //       style: TextStyle(
                  //         color: whiteColor,
                  //         fontSize: SizeConfig.textMultiplier! * 1.9,
                  //         fontWeight: FontWeight.w600,
                  //       ),
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
