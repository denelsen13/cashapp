import 'dart:ui';

import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/home/home_bloc.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/transaction_model.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/screens/login_screen.dart';
import 'package:change_money_cashier_app/screens/profile_screen.dart';
import 'package:change_money_cashier_app/screens/teller_drawer_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/auth_prompt_modal.dart';
import 'package:change_money_cashier_app/widgets/big_pill_button.dart';
import 'package:change_money_cashier_app/widgets/change_account_pin_modal.dart';
import 'package:change_money_cashier_app/widgets/change_issued_banner.dart';
import 'package:change_money_cashier_app/widgets/confirm_withdrawal_modal.dart';
import 'package:change_money_cashier_app/widgets/curve_background.dart';
import 'package:change_money_cashier_app/widgets/float_banner.dart';
import 'package:change_money_cashier_app/widgets/home_top_bar.dart';
import 'package:change_money_cashier_app/widgets/horizontal_transaction_card.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/make_withdrawal_modal.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:change_money_cashier_app/widgets/success_withdrawal_modal.dart';
import 'package:change_money_cashier_app/widgets/teller_horizontal_transaction_card.dart';
import 'package:change_money_cashier_app/widgets/teller_transaction_detail_modal.dart';
import 'package:change_money_cashier_app/widgets/transaction_detail_modal.dart';
import 'package:change_money_cashier_app/widgets/withdrawal_issued_banner.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

class TellerHomeScreen extends StatefulWidget {
  const TellerHomeScreen({Key? key}) : super(key: key);

  @override
  State<TellerHomeScreen> createState() => _TellerHomeScreenState();
}

class _TellerHomeScreenState extends State<TellerHomeScreen> {
  late String username = 'N/A';
  late String fullName = 'N/A';
  late double floatBalance = 0.0;
  double currentBalance = 0.0;
  double totalChangeIssued = 0.0;
  RefreshController _refreshController =
      RefreshController(initialRefresh: false);
  List loadedTransactions = [];
  double sigmaX = 0;
  bool isBlurred = false;
  double sigmaY = 0;
  bool isDrawerOpen = false;
  double scaleFactor = 1;
  double xOffset = 0;
  double yOffset = 0;
  var _tapPosition;
  LoginBloc? loginBloc;
  HomeBloc? homeBloc;
  bool isAlertboxOpened = false; //

  void _storePosition(TapDownDetails details) {
    _tapPosition = details.globalPosition;
  }

  void _onRefresh() async {
    print('Tacallllller');
    // monitor network fetch
    homeBloc!.add(TellerHomeLoadEvent());
    // if failed,use refreshFailed()
  }

  openTransactionDetails(TransactionModel transaction) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => TellerTransactionDetailModal(
        transaction: transaction,
      ),
    ).then((value) {});
  }

  goToWithdrawalScreen() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => MakeWithdrawalModal(),
    ).then((value) {
      //check IssueChange Request
      FocusManager.instance.primaryFocus?.unfocus();
      homeBloc!.add(
        CheckWithdrawalEvent(
          request: value,
        ),
      );
      setState(() {
        isAlertboxOpened = false;
      });
    });
  }

  goToLoginScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LoginScreen(),
      ),
    );
  }

  changeAccountPin({bool isDismmisable = true}) {
    showDialog(
      context: context,
      barrierDismissible: isDismmisable,
      builder: (_) => ChangeAccountPinModal(),
    ).then((value) {
      unBlurbackground();
    });
  }

  openDrawer() {
    setState(() {
      xOffset = SizeConfig.widthMultiplier! * 60;
      yOffset = SizeConfig.heightMultiplier! * 10;
      scaleFactor = 0.8;

      isDrawerOpen = true;
    });
  }

  void closeDrawer() {
    setState(() {
      xOffset = 0;
      yOffset = 0;
      scaleFactor = 1;
      isDrawerOpen = false;
    });
  }

  goToProfileScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileScreen(),
      ),
    );
  }

  void blurbackground() {
    setState(() {
      sigmaX = 5.0;
      sigmaY = 5.0;
      isBlurred = true;
    });
  }

  void unBlurbackground() {
    setState(() {
      sigmaX = 0.0;
      sigmaY = 0.0;
      isBlurred = false;
    });
  }

  reloadHomeData() {
    homeBloc!.add(TellerHomeLoadEvent());
  }

  setTotalChangeIssued() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    final total = await sharedPreferencesUtil.getTotalWithdrawalIssued();

    setState(() {
      totalChangeIssued = total;
      currentBalance = total;
    });
  }

  loadUsername() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String firstName = await sharedPreferencesUtil.getFirstName();
    String lastName = await sharedPreferencesUtil.getLastName();
    setState(() {
      this.username = '$firstName';
      this.fullName = '$firstName $lastName';
    });
  }

  checkResetPinFlag() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    bool shouldResetPin = await sharedPreferencesUtil.getResetPin();

    if (shouldResetPin == true) {
      changeAccountPin(isDismmisable: false);
    }
  }

  @override
  void initState() {
    super.initState();
    loginBloc = getItInstance<LoginBloc>();
    homeBloc = getItInstance<HomeBloc>();
    homeBloc!.add(TellerHomeLoadEvent());
    loadUsername();
    checkResetPinFlag();
  }

  @override
  void dispose() {
    super.dispose();
    loginBloc!.close();
    homeBloc!.close();
    // _refreshController.dispose();
  }

  popUpSection(HomeState state, LoginState loginstate, BuildContext context) {
    if (state is HomeError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          _refreshController.refreshFailed();
          if (state.statusCode == 401) {
            // if (isAlertboxOpened == false) {
            //   setState(() {
            //     isAlertboxOpened = true;
            //   });
            //   showDialog(
            //     context: context,
            //     barrierDismissible: false,
            //     builder: (_) => AuthPromptModal(),
            //   ).then((value) {
            //     setState(() {
            //       isAlertboxOpened = false;
            //     });

            //     homeBloc.emit(HomeReAuthenticating());
            //     loginBloc.add(
            //       LoginRefreshTokenEvent(
            //         pin: value,
            //       ),
            //     );
            //   });
            // }
            loginBloc!.add(LoginLogoutEvent(
                message: 'Session has Expired please login again'));
          } else {
            homeBloc!.emit(HomeErrorDone());
            showErrorMessage(context,
                message: state.errorMessage, title: 'Error');
          }
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          _refreshController.refreshFailed();
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                homeBloc!.add(TellerHomeLoadEvent());
              }
            });
          }
        });
      }
    }
    if (state is ConfirmWithdrawalLoaded) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        homeBloc!.emit(CurrenciesLoadedDone());
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => SuccessWithdrawalModal(
            response: state.response,
          ),
        ).then((value) {
          //check IssueChange Request
          homeBloc!.add(TellerHomeLoadEvent());
          setState(() {
            isAlertboxOpened = false;
          });
        });
      });
    }
    if (state is CheckWithdrawalLoaded) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        homeBloc!.emit(CurrenciesLoadedDone());
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => ConfirmWithdrawalModal(
            response: state.response,
          ),
        ).then((value) {
          //check IssueChange Request
          homeBloc!.add(
            ConfirmWithdrawalEvent(
              request: value,
            ),
          );
          setState(() {
            isAlertboxOpened = false;
          });
        });
      });
    }

    if (state is TellerHomeLoaded) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setTotalChangeIssued();
        _refreshController.refreshCompleted();
        setState(() {
          if (state.transactions != null) {
            loadedTransactions = state.transactions;
            loadedTransactions.sort((a, b) {
              final format = DateFormat("yyyy-MM-dd'T'HH:mm");
              var adate = format
                  .parse(a.dateOfTransaction); //before -> var adate = a.expiry;
              var bdate = format
                  .parse(b.dateOfTransaction); //before -> var bdate = b.expiry;
              return bdate.compareTo(
                  adate); //to get the order other way just switch `adate & bdate`
            });
          }
        });
        homeBloc!.emit(CurrenciesLoadedDone());
      });
    }

    if (loginstate is LoginError) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        if (isAlertboxOpened == false) {
          setState(() {
            isAlertboxOpened = true;
          });
          showErrorMessage(context,
              message: loginstate.errorMessage!, title: 'Error');
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (_) => AuthPromptModal(),
          ).then((value) {
            setState(() {
              isAlertboxOpened = false;
            });
          });
        }
      });
    }
    // if (loginstate is LoginBlocChangePinDone) {
    //   loginBloc.emit(LoginBlocChangePinCompleted());
    //   SchedulerBinding.instance.addPostFrameCallback((_) {
    //     changePinSuccess();
    //   });
    // }
    return SizedBox.shrink();
  }

  bodyContent({required HomeState state}) {
    return Scaffold(
      backgroundColor: whiteColor,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: SmartRefresher(
          enablePullDown: true,
          enablePullUp: false,
          controller: _refreshController,
          onRefresh: _onRefresh,
          child: Stack(
            children: [
              TellerDrawerScreen(
                closeDrawerFunction: this.closeDrawer,
                pageIndex: 'IS_HOME',
                username: this.username,
              ),
              GestureDetector(
                onTap: closeDrawer,
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 250),
                  transform: Matrix4.translationValues(xOffset, yOffset, 0)
                    ..scale(scaleFactor),
                  height: MediaQuery.of(context).size.height,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    border: isDrawerOpen
                        ? Border.all(
                            color: whiteColor,
                            width: SizeConfig.widthMultiplier! * 0.3,
                          )
                        : null,
                    borderRadius: BorderRadius.circular(
                      isDrawerOpen ? SizeConfig.imageSizeMultiplier! * 8 : 0,
                    ),
                    color: whiteColor,
                  ),
                  child: Stack(
                    children: [
                      buildBackgroundCurve(),
                      Container(
                        height: SizeConfig.heightMultiplier! * 23,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: primaryColor,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(
                              SizeConfig.imageSizeMultiplier! * 15,
                            ),
                          ),
                        ),
                      ),
                      SafeArea(
                        child: Container(
                          height: MediaQuery.of(context).size.height,
                          padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.widthMultiplier! * 5,
                          ),
                          width: double.infinity,
                          color: Colors.transparent,
                          child: Column(
                            children: [
                              SizedBox(
                                height: SizeConfig.heightMultiplier! * 3,
                              ),
                              buildHomeTopBar(
                                username: username,
                                openDrawerFunction: openDrawer,
                                closeDrawerFunction: closeDrawer,
                                goToProfileFunction: goToProfileScreen,
                                showDefault: isDrawerOpen,
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier! * 10,
                              ),
                              Text(
                                'Total Withdrawal Issued (Last 24hrs)',
                                style: TextStyle(
                                  color: secondaryColor,
                                  fontSize: SizeConfig.textMultiplier! * 1.7,
                                ),
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier! * 1,
                              ),
                              buildWithdrawalIssuedBanner(
                                  reloadFunction: reloadHomeData,
                                  totalChangeIssued: totalChangeIssued),
                              SizedBox(
                                height: SizeConfig.heightMultiplier! * 2,
                              ),
                              FadeInUp(
                                duration: Duration(milliseconds: 650),
                                child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal:
                                          SizeConfig.widthMultiplier! * 8),
                                  child: GestureDetector(
                                    onTap: goToWithdrawalScreen,
                                    child: buildLargePillButton(
                                        label: 'CONFIRM WITHDRAWAL'),
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier! * 2,
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal:
                                        SizeConfig.widthMultiplier! * 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Recent Transactions',
                                      style: TextStyle(
                                        color: secondaryColor,
                                        fontSize:
                                            SizeConfig.textMultiplier! * 2.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: SizeConfig.heightMultiplier! * 1,
                              ),
                              loadedTransactions.length == 0
                                  ? Padding(
                                      padding: EdgeInsets.only(
                                          top:
                                              SizeConfig.heightMultiplier! * 5),
                                      child: Text(
                                        'No Recent Transactions',
                                        style: TextStyle(
                                          color: secondaryColor,
                                          fontSize:
                                              SizeConfig.textMultiplier! * 1.8,
                                        ),
                                      ),
                                    )
                                  : Expanded(
                                      child: Container(
                                        width: double.infinity,
                                        child: ListView.builder(
                                          padding: EdgeInsets.only(
                                              bottom:
                                                  SizeConfig.heightMultiplier! *
                                                      5),
                                          itemCount: loadedTransactions.length,
                                          itemBuilder:
                                              (BuildContext ctxt, int index) {
                                            return GestureDetector(
                                              onTap: () =>
                                                  openTransactionDetails(
                                                      this.loadedTransactions[
                                                          index]),
                                              child: FadeInDown(
                                                duration: Duration(
                                                    milliseconds:
                                                        650 + (50 * index)),
                                                child:
                                                    buildTellerHorizontalTransactionCard(
                                                  transaction:
                                                      loadedTransactions[index],
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                            ],
                          ),
                        ),
                      ),
                      BackdropFilter(
                          filter: ImageFilter.blur(
                            sigmaX: sigmaX,
                            sigmaY: sigmaY,
                          ),
                          child: Text(
                            'tesxzxcxcxcxc',
                            style: TextStyle(
                              color: Colors.transparent,
                            ),
                          )),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => loginBloc!,
        ),
        BlocProvider(
          create: (context) => homeBloc!,
        ),
      ],
      child: BlocBuilder<HomeBloc, HomeState>(
        bloc: homeBloc,
        buildWhen: (HomeState previous, HomeState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is HomeLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              BlocBuilder<LoginBloc, LoginState>(
                bloc: loginBloc,
                buildWhen: (LoginState previous, LoginState current) =>
                    previous != current,
                builder: (context, loginstate) {
                  return Stack(
                    children: [
                      popUpSection(state, loginstate, context),
                      loginstate is AuthLoading
                          ? LoadingScreen(text: loginstate.loadingText)
                          : SizedBox.shrink(),
                    ],
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
