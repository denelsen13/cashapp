import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/blocs/splash/splash_bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/routes/route_constants.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/navigation_service.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  SplashBloc? splashBloc;
  bool isAlertboxOpened = false;
  goToLogin() {
    getItInstance<NavigationService>().navigateTo(RouteList.login);
  }

  @override
  void initState() {
    super.initState();
    splashBloc = getItInstance<SplashBloc>();
    Future.delayed(const Duration(seconds: 1), () {
      print("Tapindaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
      splashBloc!.add(SplashLoadEvent(context: context));
    });
  }

  @override
  void dispose() {
    super.dispose();
    splashBloc?.close();
  }

  popUpSection(SplashState state, BuildContext context) {
    if (state is SplashError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (state.statusCode == 21 || state.statusCode == 22) {
            splashBloc!.emit(SplashErrorDone());
          } else {
            splashBloc!.emit(SplashErrorDone());
            showErrorMessage(context,
                message: state.errorMessage!, title: 'Error');
          }
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            splashBloc!.emit(SplashErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {}
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  bodyContent({required SplashState state}) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: double.infinity,
      color: whiteColor,
      child: Center(
        child: ElasticIn(
          duration: Duration(milliseconds: 1000),
          child: Image.asset(
            'assets/images/logo_black.png',
            width: SizeConfig.widthMultiplier! * 60,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<SplashBloc>(
      create: (context) => splashBloc!,
      child: BlocBuilder<SplashBloc, SplashState>(
        bloc: splashBloc,
        buildWhen: (SplashState previous, SplashState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is SplashLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              popUpSection(state, context),
            ],
          );
        },
      ),
    );
  }
}
