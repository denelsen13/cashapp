import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/screens/home_screen.dart';
import 'package:change_money_cashier_app/screens/my_withdrawals_screen.dart';
import 'package:change_money_cashier_app/screens/notifications_screen.dart';
import 'package:change_money_cashier_app/screens/profile_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/bootstrap_icon_icons.dart';
import 'package:change_money_cashier_app/utils/icons/feather_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome4_icons.dart';
import 'package:change_money_cashier_app/utils/icons/ionicons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/drawer_menu_item.dart';
import 'package:flutter/material.dart';

class TellerDrawerScreen extends StatefulWidget {
  final Function closeDrawerFunction;
  final String pageIndex;
  final String username;
  TellerDrawerScreen(
      {required this.closeDrawerFunction,
      required this.pageIndex,
      required this.username});

  @override
  State<TellerDrawerScreen> createState() => _TellerDrawerScreenState();
}

class _TellerDrawerScreenState extends State<TellerDrawerScreen> {
  logout() {
    getItInstance<LoginBloc>().add(LoginLogoutEvent());
  }

  goToHomeScreen() {
    widget.closeDrawerFunction();
    if (widget.pageIndex != 'IS_HOME') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HomeScreen(),
        ),
      );
    }
  }

  goToWithdrawalScreen() {
    widget.closeDrawerFunction();
    if (widget.pageIndex != 'IS_WITHDRAWAL') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MyWithdrawalScreen(),
        ),
      );
    }
  }

  goToProfileScreen() {
    widget.closeDrawerFunction();
    if (widget.pageIndex != 'IS_PROFILE') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ProfileScreen(),
        ),
      );
    }
  }

  goToNotificationsScreen() {
    widget.closeDrawerFunction();
    widget.closeDrawerFunction();
    if (widget.pageIndex != 'IS_NOTIFICATION') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => NotificationsScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      child: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          color: primaryColor,
          padding: EdgeInsets.symmetric(
            horizontal: SizeConfig.widthMultiplier! * 5,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: SizeConfig.heightMultiplier! * 2,
              ),
              Container(
                height: SizeConfig.heightMultiplier! * 8,
                width: double.infinity,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundImage: AssetImage('assets/images/avatar.png'),
                      radius: SizeConfig.imageSizeMultiplier! * 7,
                    ),
                    SizedBox(
                      width: SizeConfig.widthMultiplier! * 3,
                    ),
                    Expanded(
                      child: Container(
                        height: SizeConfig.heightMultiplier! * 4,
                        child: Text(
                          '${widget.username}',
                          style: TextStyle(
                            height: SizeConfig.heightMultiplier! * 0.15,
                            color: whiteColor,
                            fontSize: SizeConfig.textMultiplier! * 3,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 5,
              ),
              Expanded(
                child: Container(
                  width: SizeConfig.widthMultiplier! * 75,
                  child: Column(
                    children: [
                      Expanded(
                        child: Column(
                          children: [
                            GestureDetector(
                              onTap: goToHomeScreen,
                              child: buildDrawerMenuItem(
                                label: 'Home',
                                icon: Ionicons.ion_ios_home,
                              ),
                            ),
                            GestureDetector(
                              onTap: goToProfileScreen,
                              child: buildDrawerMenuItem(
                                label: 'Profile',
                                icon: BootstrapIcon.emoji_smile,
                              ),
                            ),
                            GestureDetector(
                              onTap: goToWithdrawalScreen,
                              child: buildDrawerMenuItem(
                                label: 'Withdrawals',
                                icon: FontAwesome4.dollar,
                              ),
                            ),
                            GestureDetector(
                              onTap: goToNotificationsScreen,
                              child: buildDrawerMenuItem(
                                label: 'Notifications',
                                icon: Feather.bell,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: logout,
                        child: buildDrawerMenuItem(
                          label: 'Logout',
                          icon: Feather.log_out,
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 3,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
