import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/carbon_icons_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:flutter/material.dart';

class ExpiryScreen extends StatefulWidget {
  const ExpiryScreen({Key? key}) : super(key: key);

  @override
  State<ExpiryScreen> createState() => _ExpiryScreenState();
}

class _ExpiryScreenState extends State<ExpiryScreen> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery.of(context).size.height,
          width: double.infinity,
          color: primaryColor,
          padding:
              EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier! * 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Image.asset(
              //   'assets/images/qr_image_error.png',
              //   fit: BoxFit.contain,
              //   width: double.infinity,
              //   height: SizeConfig.heightMultiplier! * 35,
              // ),
              Icon(
                CarbonIcons.in_progress__error,
                color: Colors.red,
                size: SizeConfig.imageSizeMultiplier! * 25,
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 3,
              ),
              Center(
                child: ElasticIn(
                    duration: Duration(milliseconds: 1000),
                    child: Text(
                      'This Mobile App has expired and is no longer viable please contact Developer!',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: whiteColor,
                        fontSize: SizeConfig.textMultiplier! * 3,
                        fontWeight: FontWeight.bold,
                      ),
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
