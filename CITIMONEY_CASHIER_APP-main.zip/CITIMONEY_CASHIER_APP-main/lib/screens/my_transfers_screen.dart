import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:change_money_cashier_app/blocs/transaction/transaction_bloc.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/models/enums/transaction_type.dart';
import 'package:change_money_cashier_app/data/models/responses/transaction_paged_response.dart';
import 'package:change_money_cashier_app/data/models/transaction_model.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/screens/drawer_screen.dart';
import 'package:change_money_cashier_app/screens/profile_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/icons/carbon_icons_icons.dart';
import 'package:change_money_cashier_app/utils/icons/font_awesome5_icons.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/utils/string_utils.dart';
import 'package:change_money_cashier_app/widgets/curve_left.dart';
import 'package:change_money_cashier_app/widgets/horizontal_transaction_card.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/search_box.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:change_money_cashier_app/widgets/transaction_detail_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MyIssueChangesScreen extends StatefulWidget {
  const MyIssueChangesScreen({Key? key}) : super(key: key);

  @override
  State<MyIssueChangesScreen> createState() => _MyIssueChangesScreenState();
}

class _MyIssueChangesScreenState extends State<MyIssueChangesScreen> {
  TransactionBloc? transactionBloc;
  bool isSearch = false;
  late String username = 'N/A';
  late String fullName = 'N/A';
  bool isDrawerOpen = false;
  double scaleFactor = 1;
  double xOffset = 0;
  double yOffset = 0;
  TextEditingController searchController = new TextEditingController();
  bool isAlertboxOpened = false;
  int pageNumber = 0;
  ScrollController? _controller;
  List<TransactionModel> transactions = [];
  List<TransactionModel> searchTransactions = [];
  bool isLoading = false;
  TransactionPagedResponse? pagedTransactions =
      TransactionPagedResponse.empty();
  String loadingText = '';
  goback() {
    Navigator.pop(context);
  }

  goToProfileScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfileScreen(),
      ),
    );
  }

  openTransactionDetails(TransactionModel transaction) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => TransactionDetailModal(
        transaction: transaction,
      ),
    ).then((value) {});
  }

  getTransactionType(TransactionType transactionType) {
    if (transactionType == TransactionType.CASH_IN) {
      return 'Cashin';
    }
    if (transactionType == TransactionType.CASH_OUT) {
      return 'Cashout';
    }
    if (transactionType == TransactionType.CHANGE) {
      return 'Change';
    }
    if (transactionType == TransactionType.CHECK_BALANCE) {
      return 'Balance';
    }
    if (transactionType == TransactionType.PAYMENT) {
      return 'IssueChange';
    }
    if (transactionType == TransactionType.TRANSFER) {
      return 'IssueChange';
    }
  }

  goBack() {
    Navigator.pop(context);
  }

  getTransactions() {
    transactionBloc!.add(
      GetAllIssueChangeTransactionsEvent(
        pageNumber: pageNumber,
      ),
    );
  }

  loadMore() {
    setState(() {
      pageNumber = pageNumber + 1;
    });

    transactionBloc!.add(
      GetMoreIssueChangeTransactionsEvent(
        pageNumber: pageNumber,
      ),
    );
  }

  filterTransactions(String searchQuery) {
    if (searchQuery != null && searchQuery.isNotEmpty) {
      searchTransactions.length = 0;
      this.transactions.forEach((p) {
        if (p.customer != null) {
          if (p.customer.firstName.containsIgnoreCase(searchQuery) ||
              p.customer.surname.containsIgnoreCase(searchQuery)) {
            searchTransactions.add(p);
          }
        }
        if (p.merchant != null) {
          if (p.merchant.name.containsIgnoreCase(searchQuery)) {
            if (searchTransactions
                    .firstWhere((element) => element.id == p.id) ==
                null) {
              searchTransactions.add(p);
            }
          }
        }
        if (p.cashier != null) {
          if (p.cashier.firstName.containsIgnoreCase(searchQuery) ||
              p.cashier.surname.containsIgnoreCase(searchQuery)) {
            if (searchTransactions
                    .firstWhere((element) => element.id == p.id) ==
                null) {
              searchTransactions.add(p);
            }
          }
        }
        if (p.transactionType != null) {
          if (this
              .getTransactionType(p.transactionType)
              .containsIgnoreCase(searchQuery)) {
            if (searchTransactions
                    .firstWhere((element) => element.id == p.id) ==
                null) {
              searchTransactions.add(p);
            }
          }
        }
      });
      setState(() {
        isSearch = true;
      });
    } else {
      setState(() {
        isSearch = false;
      });
    }
  }

  @override
  void initState() {
    _controller = ScrollController();
    super.initState();
    transactionBloc = getItInstance<TransactionBloc>();
    transactionBloc!.add(
      GetAllIssueChangeTransactionsEvent(
        pageNumber: this.pageNumber,
      ),
    );
    loadUsername();
  }

  loadUsername() async {
    SharedPreferenceUtil sharedPreferencesUtil =
        getItInstance<SharedPreferenceUtil>();
    String firstName = await sharedPreferencesUtil.getFirstName();
    String lastName = await sharedPreferencesUtil.getLastName();
    setState(() {
      this.username = '$firstName';
      this.fullName = '$firstName $lastName';
    });
  }

  openDrawer() {
    setState(() {
      xOffset = SizeConfig.widthMultiplier! * 60;
      yOffset = SizeConfig.heightMultiplier! * 10;
      scaleFactor = 0.8;

      isDrawerOpen = true;
    });
  }

  void closeDrawer() {
    setState(() {
      xOffset = 0;
      yOffset = 0;
      scaleFactor = 1;
      isDrawerOpen = false;
    });
  }

  handleLogicStates(
    TransactionState state,
    BuildContext context,
  ) {
    if (state is TransactionsLoading) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.isLoading = true;
          this.loadingText = state.loadingText;
        });
      });
    }
    if (state is GetAllIssueChangeTransactionsDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.pagedTransactions = state.transactions;
          this.transactions = state.transactions.transactions!;
          this.isLoading = false;
        });
      });
      transactionBloc!.emit(FetchUpdatedDone());
    }

    if (state is GetMoreIssueChangeTransactionsDone) {
      SchedulerBinding.instance!.addPostFrameCallback((_) {
        setState(() {
          this.pagedTransactions = state.transactions;
          this.transactions.addAll(state.transactions.transactions!);
          this.isLoading = false;
        });
      });
      transactionBloc!.emit(FetchUpdatedDone());
    }

    if (state is TransactionsError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          transactionBloc!.emit(TransactionsErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
          setState(() {
            this.isLoading = false;
          });
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
              this.isLoading = false;
            });
            transactionBloc!.emit(TransactionsErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.getTransactions();
              }
            });
          }
        });
      }
    }
    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<TransactionBloc>(
      create: (context) => transactionBloc!,
      child: BlocBuilder<TransactionBloc, TransactionState>(
        bloc: transactionBloc,
        buildWhen: (TransactionState previous, TransactionState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is TransactionsLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              handleLogicStates(state, context),
            ],
          );
        },
      ),
    );
  }

  bodyContent({required TransactionState state}) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: Stack(
        children: [
          DrawerScreen(
            closeDrawerFunction: this.closeDrawer,
            pageIndex: 'IS_CHANGE_ISSUED',
            username: this.username,
          ),
          GestureDetector(
            onTap: closeDrawer,
            child: AnimatedContainer(
              duration: Duration(milliseconds: 250),
              transform: Matrix4.translationValues(xOffset, yOffset, 0)
                ..scale(scaleFactor),
              height: MediaQuery.of(context).size.height,
              width: double.infinity,
              decoration: BoxDecoration(
                border: isDrawerOpen
                    ? Border.all(
                        color: whiteColor,
                        width: SizeConfig.widthMultiplier! * 0.3,
                      )
                    : null,
                borderRadius: BorderRadius.circular(
                  isDrawerOpen ? SizeConfig.imageSizeMultiplier! * 8 : 0,
                ),
                color: whiteColor,
              ),
              child: SafeArea(
                child: Stack(
                  children: [
                    Container(
                      height: SizeConfig.heightMultiplier! * 100,
                      padding: EdgeInsets.symmetric(
                        horizontal: SizeConfig.widthMultiplier! * 5,
                      ),
                      child: Column(
                        children: [
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Container(
                            height: SizeConfig.heightMultiplier! * 8,
                            child: Stack(
                              children: [
                                Center(
                                  child: Text(
                                    'My IssueChanges',
                                    style: TextStyle(
                                        color: primaryColor,
                                        fontSize:
                                            SizeConfig.textMultiplier! * 2.5,
                                        fontWeight: FontWeight.w600,
                                        height: SizeConfig.heightMultiplier! *
                                            0.13),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.centerRight,
                                  child: GestureDetector(
                                    onTap: goToProfileScreen,
                                    child: Container(
                                      height: SizeConfig.heightMultiplier! * 5,
                                      width: SizeConfig.heightMultiplier! * 5,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: whiteColor,
                                        border: Border.all(
                                          color: whiteColor,
                                          width:
                                              SizeConfig.widthMultiplier! * 0.1,
                                        ),
                                      ),
                                      child: CircleAvatar(
                                        backgroundImage: AssetImage(
                                          'assets/images/avatar.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 8,
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.widthMultiplier! * 8,
                            ),
                            child: buildSearchBox(
                              hintText: 'Search for Transactions',
                              controller: searchController,
                              onChangeFunction: filterTransactions,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          this.isLoading
                              ? Container(
                                  height: SizeConfig.heightMultiplier! * 40,
                                  width: double.infinity,
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Image.asset(
                                        'assets/images/loading2.gif',
                                        width: double.infinity,
                                        height:
                                            SizeConfig.heightMultiplier! * 30,
                                      ),
                                      AnimatedTextKit(
                                          repeatForever:
                                              true, //this will ignore [totalRepeatCount]
                                          pause: Duration(seconds: 1),
                                          animatedTexts: [
                                            TypewriterAnimatedText(
                                              loadingText,
                                              textStyle: TextStyle(
                                                fontSize: 2 *
                                                    SizeConfig.textMultiplier!,
                                                color: primaryColor,
                                              ),
                                            ),
                                            TypewriterAnimatedText(
                                              loadingText,
                                              textStyle: TextStyle(
                                                  fontSize: 2 *
                                                      SizeConfig
                                                          .textMultiplier!,
                                                  color: primaryColor),
                                            ),
                                            TypewriterAnimatedText(
                                              loadingText,
                                              textStyle: TextStyle(
                                                fontSize: 2 *
                                                    SizeConfig.textMultiplier!,
                                                color: primaryColor,
                                              ),
                                            )
                                          ],
                                          // speed: Duration(milliseconds: 100),

                                          displayFullTextOnTap: true,
                                          stopPauseOnTap: true),
                                    ],
                                  ),
                                )
                              : SizedBox.shrink(),
                          (this.transactions.length == 0 && !this.isLoading)
                              ? Container(
                                  height: SizeConfig.heightMultiplier! * 60,
                                  width: double.infinity,
                                  child: Center(
                                    child: Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          FontAwesome5.dollar_sign,
                                          color: greyColor,
                                          size:
                                              SizeConfig.imageSizeMultiplier! *
                                                  15,
                                        ),
                                        SizedBox(
                                          height:
                                              SizeConfig.heightMultiplier! * 3,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.symmetric(
                                              horizontal:
                                                  SizeConfig.widthMultiplier! *
                                                      8),
                                          child: Text(
                                            'You do not have any transactions right now',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color: greyColor,
                                              fontSize:
                                                  SizeConfig.textMultiplier! *
                                                      2.5,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                )
                              : !this.isLoading
                                  ? Expanded(
                                      child: this.isSearch
                                          ? ListView.builder(
                                              padding: EdgeInsets.symmetric(
                                                vertical: SizeConfig
                                                        .heightMultiplier! *
                                                    1,
                                              ),
                                              itemCount: this
                                                      .searchTransactions
                                                      .length +
                                                  1,
                                              itemBuilder: (context, index) {
                                                return (index ==
                                                        this
                                                            .searchTransactions
                                                            .length)
                                                    ? !pagedTransactions!.last
                                                        ? buildPillButton(
                                                            label: 'Load More')
                                                        : SizedBox.shrink()
                                                    : GestureDetector(
                                                        onTap: () =>
                                                            openTransactionDetails(
                                                                this.searchTransactions[
                                                                    index]),
                                                        child: Container(
                                                          margin: EdgeInsets.only(
                                                              bottom: SizeConfig
                                                                      .heightMultiplier! *
                                                                  1),
                                                          child:
                                                              buildHorizontalTransactionCard(
                                                            transaction:
                                                                searchTransactions[
                                                                    index],
                                                          ),
                                                        ));
                                              },
                                            )
                                          : ListView.builder(
                                              padding: EdgeInsets.symmetric(
                                                vertical: SizeConfig
                                                        .heightMultiplier! *
                                                    1,
                                              ),
                                              itemCount:
                                                  this.transactions.length + 1,
                                              itemBuilder: (context, index) {
                                                return (index ==
                                                        this
                                                            .transactions
                                                            .length)
                                                    ? !pagedTransactions!.last
                                                        ? GestureDetector(
                                                            onTap: loadMore,
                                                            child:
                                                                buildPillButton(
                                                              label:
                                                                  'Load More',
                                                            ),
                                                          )
                                                        : SizedBox.shrink()
                                                    : GestureDetector(
                                                        onTap: () =>
                                                            openTransactionDetails(
                                                                this.transactions[
                                                                    index]),
                                                        child: Container(
                                                          margin: EdgeInsets.only(
                                                              bottom: SizeConfig
                                                                      .heightMultiplier! *
                                                                  1),
                                                          child:
                                                              buildHorizontalTransactionCard(
                                                            transaction:
                                                                transactions[
                                                                    index],
                                                          ),
                                                        ),
                                                      );
                                              },
                                            ),
                                    )
                                  : SizedBox.shrink()
                        ],
                      ),
                    ),
                    buildLeftCurve(
                      leftButtonFunction:
                          isDrawerOpen ? closeDrawer : openDrawer,
                      isOpen: isDrawerOpen,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
