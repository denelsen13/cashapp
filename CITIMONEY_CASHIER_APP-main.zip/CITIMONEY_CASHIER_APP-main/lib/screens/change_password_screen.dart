import 'dart:ui';

import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:change_money_cashier_app/data/models/requests/instant_change_password_request_dto.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/encoder_util.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({Key? key}) : super(key: key);

  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  LoginBloc? authBloc;
  bool isAlertboxOpened = false;
  final _formKey = GlobalKey<FormState>();

  TextEditingController passwordController = new TextEditingController();
  TextEditingController confirmPasswordController = new TextEditingController();
  final passwordFocus = FocusNode();
  final confirmPasswordFocus = FocusNode();

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  changePassword(context) async {
    FocusScope.of(context).requestFocus(FocusNode());
    if (_formKey.currentState!.validate()) {
      InstantChangePasswordRequestDTO request = InstantChangePasswordRequestDTO(
        newPassword: EncoderUtil.threefoldBase64Encode(passwordController.text),
      );
      authBloc!.add(
        LoginChangePasswordEvent(
          context: context,
          request: request,
        ),
      );
    }
  }

  validatePassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
  }

  validateConfirmPassword(pin) {
    if (pin == null) {
      return 'password cannot be empty';
    } else if (pin.isEmpty) {
      return 'password cannot be empty';
    } else if (pin.length < 4) {
      return 'password length cannot be less than 4';
    } else if (pin.length > 25) {
      return 'password length cannot be more than 25';
    }
    if (this.passwordController.text != pin) {
      return 'passwords dont match';
    }
  }

  @override
  void initState() {
    super.initState();
    authBloc = getItInstance<LoginBloc>();
    authBloc!.add(ChangePasswordLoadEvent());
  }

  @override
  void dispose() {
    super.dispose();
    authBloc?.close();
  }

  handleLogicStates(LoginState state, BuildContext context) {
    if (state is LoginChangePasswordError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          authBloc!.emit(LoginChangePasswordErrorDone());
          showErrorMessage(context,
              message: state.errorMessage!, title: 'Error');
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            authBloc!.emit(LoginChangePasswordErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                this.changePassword(context);
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => authBloc!,
      child: BlocBuilder<LoginBloc, LoginState>(
        bloc: authBloc,
        buildWhen: (LoginState previous, LoginState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is AuthLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              handleLogicStates(state, context),
            ],
          );
        },
      ),
    );
  }

  bodyContent({required LoginState state}) {
    return Scaffold(
      backgroundColor: whiteishColor,
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(color: whiteColor),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
              child: new Container(
                decoration:
                    new BoxDecoration(color: Colors.white.withOpacity(0.0)),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 5,
                vertical: SizeConfig.heightMultiplier! * 3,
              ),
              child: ListView(
                padding: EdgeInsets.only(
                  top: SizeConfig.heightMultiplier! * 5,
                ),
                children: [
                  Container(
                    width: double.infinity,
                    child: Form(
                      key: _formKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Center(
                            child: Image.asset(
                              'assets/images/logo_black.png',
                              height: SizeConfig.heightMultiplier! * 12,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 13,
                          ),
                          Text(
                            'Change Password',
                            style: TextStyle(
                              color: blackColor,
                              fontSize: SizeConfig.textMultiplier! * 4,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 4,
                          ),
                          buildCustomTextField(
                            hintText: 'New Password',
                            obsecureText: true,
                            isNumber: true,
                            validateFunction: validatePassword,
                            currentFocusNode: passwordFocus,
                            focusChangeFunction: changeFocus,
                            nextFocusNode: confirmPasswordFocus,
                            isValidate: true,
                            controller: passwordController,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          buildCustomTextField(
                            hintText: 'Confirm New Password',
                            obsecureText: true,
                            isNumber: true,
                            validateFunction: validateConfirmPassword,
                            textInputAction: TextInputAction.done,
                            currentFocusNode: confirmPasswordFocus,
                            isValidate: true,
                            controller: confirmPasswordController,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          GestureDetector(
                            onTap: () => changePassword(context),
                            child: buildPillButton(
                              label: 'CHANGE PASSWORD',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
