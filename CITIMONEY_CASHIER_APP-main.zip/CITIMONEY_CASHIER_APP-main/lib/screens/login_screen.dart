import 'dart:ui';

import 'package:animate_do/animate_do.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/di/get_it.dart';
import 'package:change_money_cashier_app/domain/entities/app_error.dart';
import 'package:change_money_cashier_app/screens/forgot_password_screen.dart';
import 'package:change_money_cashier_app/screens/sign_up_screen.dart';
import 'package:change_money_cashier_app/utils/colors.dart';
import 'package:change_money_cashier_app/utils/size_config.dart';
import 'package:change_money_cashier_app/widgets/custom_phone_number_field.dart';
import 'package:change_money_cashier_app/widgets/custom_text_field.dart';
import 'package:change_money_cashier_app/widgets/loading_screen.dart';
import 'package:change_money_cashier_app/widgets/pill_button.dart';
import 'package:change_money_cashier_app/widgets/show_error_message.dart';
import 'package:change_money_cashier_app/widgets/show_network_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  LoginBloc? loginBloc;
  bool isAlertboxOpened = false;
  String _countryCode = 'ZW';
  String _dialCode = '+263';
  final passwordFocus = FocusNode();
  final mobileNumberFocus = FocusNode();
  TextEditingController usernameController = new TextEditingController();
  TextEditingController pinController = new TextEditingController();
  final _formKey = GlobalKey<FormState>();
  goToForgotPasswordScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ForgotPasswordScreen(),
      ),
    );
  }

  goToSignupScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SignupScreen(),
      ),
    );
  }

  updateCountryCode(String countryCode, String dialCode) {
    setState(() {
      _countryCode = countryCode;
      _dialCode = dialCode;
    });
  }

  login(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      loginBloc!.add(
        LoginLoginEvent(
          context: context,
          username: '${_dialCode.substring(1)}${usernameController.text}',
          pin: pinController.text,
        ),
      );
    } else {}
  }

  @override
  void initState() {
    super.initState();
    loginBloc = getItInstance<LoginBloc>();
    loginBloc!.add(LoginLoadEvent());
  }

  @override
  void dispose() {
    super.dispose();
    loginBloc!.close();
  }

  changeFocus(FocusNode focusNode) {
    FocusScope.of(context).requestFocus(focusNode);
  }

  validateUsername(username) {
    if (username == null) {
      return 'phonenumber cannot be empty';
    } else if (username.isEmpty) {
      return 'phonenumber cannot be empty';
    } else if (username.length < 9 || username.length > 9) {
      return 'phonenumber is not valid';
    }
  }

  validatePin(pin) {
    if (pin == null) {
      return 'pin cannot be empty';
    } else if (pin.isEmpty) {
      return 'pin cannot be empty';
    } else if (pin.length < 4) {
      return 'pin length cannot be less than 4';
    }
  }

  popUpSection(LoginState state, BuildContext context) {
    if (state is LoginError) {
      if (state.appErrorType == AppErrorType.api) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (state.statusCode == 21 || state.statusCode == 22) {
            loginBloc!.emit(LoginErrorDone());
          } else {
            loginBloc!.emit(LoginErrorDone());
            showErrorMessage(context,
                message: state.errorMessage!, title: 'Error');
          }
        });
      }
      if (state.appErrorType == AppErrorType.network) {
        SchedulerBinding.instance!.addPostFrameCallback((_) {
          if (isAlertboxOpened == false) {
            setState(() {
              isAlertboxOpened = true;
            });
            loginBloc!.emit(LoginErrorDone());
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (_) => NetworkModal(
                message: state.errorMessage!,
              ),
            ).then((value) {
              setState(() {
                isAlertboxOpened = false;
              });
              if (value == 1) {
                loginBloc!.add(
                  LoginLoginEvent(
                    context: context,
                    username:
                        '${_countryCode.substring(1)}${usernameController.text}',
                    pin: pinController.text,
                  ),
                );
              }
            });
          }
        });
      }
    }

    return SizedBox.shrink();
  }

  bodyContent({required LoginState state}) {
    return Scaffold(
      backgroundColor: whiteColor,
      body: Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
              color: whiteColor,
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 0.5, sigmaY: 0.5),
              child: new Container(
                decoration:
                    new BoxDecoration(color: Colors.white.withOpacity(0.0)),
              ),
            ),
          ),
          SafeArea(
            child: Container(
              height: MediaQuery.of(context).size.height,
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 8,
              ),
              width: double.infinity,
              color: Colors.transparent,
              child: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 5,
                      ),
                      FadeInDown(
                        duration: Duration(milliseconds: 1000),
                        child: Image.asset(
                          'assets/images/logo_black.png',
                          width: SizeConfig.widthMultiplier! * 40,
                        ),
                      ),

                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 15,
                      ),
                      // FadeInLeft(
                      //   duration: Duration(milliseconds: 650),
                      //   child: Image.asset(
                      //     'assets/images/wallet.png',
                      //     width: double.infinity,
                      //   ),
                      // ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 1,
                      ),
                      Text(
                        'Cashier',
                        style: TextStyle(
                            color: blackColor,
                            fontSize: SizeConfig.textMultiplier! * 2),
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 1,
                      ),
                      Text(
                        'Login',
                        style: TextStyle(
                          color: blackColor,
                          fontSize: SizeConfig.textMultiplier! * 2.6,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 1,
                      ),
                      buildPhoneNumberField(
                        isValidate: true,
                        validateFunction: validateUsername,
                        updateCountryCodeFunction: updateCountryCode,
                        controller: usernameController,
                        currentFocusNode: mobileNumberFocus,
                        focusChangeFunction: changeFocus,
                        nextFocusNode: passwordFocus,
                      ),
                      // buildCustomTextField(
                      //   hintText: 'Enter Cashier ID',
                      //   controller: usernameController,
                      //   isValidate: true,
                      //   validateFunction: validateUsername,
                      // ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 0.5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          GestureDetector(
                            onTap: goToForgotPasswordScreen,
                            child: Text(
                              'Forgot Password',
                              style: TextStyle(
                                  color: blackColor,
                                  fontSize: SizeConfig.textMultiplier! * 1.8),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 0.5,
                      ),
                      buildCustomTextField(
                        hintText: 'Enter Pin',
                        obsecureText: true,
                        isValidate: true,
                        validateFunction: validatePin,
                        controller: pinController,
                        isNumber: true,
                        textInputAction: TextInputAction.done,
                        currentFocusNode: passwordFocus,
                      ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 3,
                      ),
                      state is AuthLoading
                          ? FadeInUp(
                              duration: Duration(milliseconds: 650),
                              child: GestureDetector(
                                onTap: () {},
                                child: buildPillButton(
                                  label: 'Logging in...',
                                ),
                              ),
                            )
                          : FadeInUp(
                              duration: Duration(milliseconds: 650),
                              child: GestureDetector(
                                onTap: () => login(context),
                                child: buildPillButton(label: 'Login'),
                              ),
                            ),
                      SizedBox(
                        height: SizeConfig.heightMultiplier! * 3,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => loginBloc!,
      child: BlocBuilder<LoginBloc, LoginState>(
        bloc: loginBloc,
        buildWhen: (LoginState previous, LoginState current) =>
            previous != current,
        builder: (context, state) {
          return Stack(
            children: [
              bodyContent(state: state),
              state is AuthLoading
                  ? LoadingScreen(text: state.loadingText)
                  : SizedBox.shrink(),
              popUpSection(state, context),
            ],
          );
        },
      ),
    );
  }
}
