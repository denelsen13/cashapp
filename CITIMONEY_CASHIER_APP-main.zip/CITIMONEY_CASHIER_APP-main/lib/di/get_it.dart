import 'package:change_money_cashier_app/blocs/home/home_bloc.dart';
import 'package:change_money_cashier_app/blocs/login/login_bloc.dart';
import 'package:change_money_cashier_app/blocs/transaction/transaction_bloc.dart';
import 'package:change_money_cashier_app/data/core/api_client.dart';
import 'package:change_money_cashier_app/data/data_sources/change_money_remote_data_source.dart';
import 'package:change_money_cashier_app/data/data_sources/shared_preference.dart';
import 'package:change_money_cashier_app/data/repositories/auth_repository_impl.dart';
import 'package:change_money_cashier_app/data/repositories/home_repository_impl.dart';
import 'package:change_money_cashier_app/domain/repositories/auth_repository.dart';
import 'package:change_money_cashier_app/domain/repositories/home_repository.dart';
import 'package:change_money_cashier_app/domain/usecases/notifications/get_currencies_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_cashout_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_payment_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_transfer_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/check_withdrawal_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_cashout_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_payment_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_transfer_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/confirm_withdrawal_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_cashins_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_cashouts_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_float_balance_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_issued_changes_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_payments_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_recent_transactions_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_teller_float_balance_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_teller_recent_transactions_usecase.dart';
import 'package:change_money_cashier_app/domain/usecases/transactions/get_withdrawals_usecase.dart';
import 'package:change_money_cashier_app/utils/navigation_service.dart';
import 'package:get_it/get_it.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../blocs/chat/chat_bloc.dart';
import '../blocs/notification/notification_bloc.dart';
import '../blocs/profile/profile_bloc.dart';
import '../blocs/socket/socket_bloc.dart';
import '../blocs/splash/splash_bloc.dart';
import '../data/repositories/chat_messages_repository_impl.dart';
import '../data/repositories/notification_repository_impl.dart';
import '../data/repositories/user_repository_impl.dart';
import '../domain/repositories/chat_messages_repository.dart';
import '../domain/repositories/notification_repository.dart';
import '../domain/repositories/user_repository.dart';
import '../domain/usecases/auth/change_password_usecase.dart';
import '../domain/usecases/auth/instant_change_password_usecase.dart';
import '../domain/usecases/auth/login_usecase.dart';
import '../domain/usecases/auth/resend_otp_usecase.dart';
import '../domain/usecases/auth/reset_password_usecase.dart';
import '../domain/usecases/auth/reset_password_verify_otp_usecase.dart';
import '../domain/usecases/auth/signup_usecase.dart';
import '../domain/usecases/auth/verify_otp_usecase.dart';
import '../domain/usecases/chat/load_all_chat_messages_usecase.dart';
import '../domain/usecases/notifications/load_notifications_usecase.dart';
import '../domain/usecases/notifications/update_notifications_read_status_usecase.dart';
import '../domain/usecases/notifications/update_single_notification_read_status_usecase.dart';
import '../domain/usecases/profile/fetch_profile_usecase.dart';
import '../domain/usecases/profile/update_profile_usecase.dart';

final getItInstance = GetIt.I;
Future init() async {
  // register singletons here
  getItInstance.registerLazySingleton<Client>(() => Client());
  getItInstance
      .registerLazySingleton<NavigationService>(() => NavigationService());
  getItInstance.registerLazySingletonAsync<SharedPreferences>(
      () => SharedPreferences.getInstance());
  getItInstance.registerLazySingleton<SharedPreferenceUtil>(
    () => SharedPreferenceUtil(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ApiClient>(
    () => ApiClient(
      getItInstance(),
    ),
  );

  getItInstance.registerLazySingleton<ChangeMoneyRemoteDataSource>(
    () => ChangeMoneyRemoteDataSourceImpl(
      getItInstance(),
    ),
  );
//register repositories here
  getItInstance.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<UserRepository>(
    () => UserRepositoryImpl(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<NotificationRepository>(
    () => NotificationRepositoryImpl(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ChatMessagesRepository>(
    () => ChatMessagesRepositoryImpl(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<HomeRepository>(
    () => HomeRepositoryImpl(
      getItInstance(),
    ),
  );
  //register usecases here
  getItInstance.registerLazySingleton<LoginUsecase>(
    () => LoginUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetRecentTransactionsUsecase>(
    () => GetRecentTransactionsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetTellerRecentTransactionsUsecase>(
    () => GetTellerRecentTransactionsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetFloatBalanceUsecase>(
    () => GetFloatBalanceUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetTellerFloatBalanceUsecase>(
    () => GetTellerFloatBalanceUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ResetPasswordUsecase>(
    () => ResetPasswordUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<SignupUsecase>(
    () => SignupUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ChangePasswordUsecase>(
    () => ChangePasswordUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<VerifyOtpUsecase>(
    () => VerifyOtpUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<InstantChangePasswordUsecase>(
    () => InstantChangePasswordUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ResetPasswordVerifyOtpUsecase>(
    () => ResetPasswordVerifyOtpUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ResendOtpUsecase>(
    () => ResendOtpUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<UpdateProfileUsecase>(
    () => UpdateProfileUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<FetchProfileUsecase>(
    () => FetchProfileUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<LoadAllNotificationsUsecase>(
    () => LoadAllNotificationsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<UpdateNotificationsReadStatusUsecase>(
    () => UpdateNotificationsReadStatusUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<LoadAllChatMessagesUsecase>(
    () => LoadAllChatMessagesUsecase(
      getItInstance(),
    ),
  );
  getItInstance
      .registerLazySingleton<UpdateSingleNotificationsReadStatusUsecase>(
    () => UpdateSingleNotificationsReadStatusUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetCurrenciesUsecase>(
    () => GetCurrenciesUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<CheckCashoutUsecase>(
    () => CheckCashoutUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<CheckIssueChangeUsecase>(
    () => CheckIssueChangeUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<CheckCashinUsecase>(
    () => CheckCashinUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ConfirmCashoutUsecase>(
    () => ConfirmCashoutUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ConfirmIssueChangeUsecase>(
    () => ConfirmIssueChangeUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ConfirmCashinUsecase>(
    () => ConfirmCashinUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<ConfirmWithdrawalUsecase>(
    () => ConfirmWithdrawalUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<CheckWithdrawalUsecase>(
    () => CheckWithdrawalUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetCashinsUsecase>(
    () => GetCashinsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetPaymentsUsecase>(
    () => GetPaymentsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetWithdrawalsUsecase>(
    () => GetWithdrawalsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetCashoutsUsecase>(
    () => GetCashoutsUsecase(
      getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<GetIssueChangesUsecase>(
    () => GetIssueChangesUsecase(
      getItInstance(),
    ),
  );
  //register blocs here
  getItInstance.registerFactory<LoginBloc>(
    () => LoginBloc(
      loginUsecase: getItInstance(),
      resetPinUsecase: getItInstance(),
      changePinUsecase: getItInstance(),
      signupUsecase: getItInstance(),
      verifyOtpUsecase: getItInstance(),
      instantChangePasswordUsecase: getItInstance(),
      resetPasswordVerifyOtpUsecase: getItInstance(),
      resendOtpUsecase: getItInstance(),
    ),
  );

  getItInstance.registerFactory<SplashBloc>(
    () => SplashBloc(),
  );
  getItInstance.registerFactory<ProfileBloc>(
    () => ProfileBloc(
      fetchProfileUsecase: getItInstance(),
      updateProfileUsecase: getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<NotificationBloc>(
    () => NotificationBloc(
      loadAllNotificationsUsecase: getItInstance(),
      updateNotificationsReadStatusUsecase: getItInstance(),
      updateSingleNotificationsReadStatusUsecase: getItInstance(),
    ),
  );
  getItInstance.registerFactory<ChatBloc>(
    () => ChatBloc(
      loadAllChatMessagesUsecase: getItInstance(),
    ),
  );
  getItInstance.registerLazySingleton<SocketBloc>(
    () => SocketBloc(),
  );
  getItInstance.registerFactory<HomeBloc>(
    () => HomeBloc(
      getFloatBalanceUsecase: getItInstance(),
      getCurrenciesUsecase: getItInstance(),
      getRecentTransactionsUsecase: getItInstance(),
      checkCashoutUsecase: getItInstance(),
      checkIssueChangeUsecase: getItInstance(),
      checkCashinUsecase: getItInstance(),
      confirmCashoutUsecase: getItInstance(),
      confirmIssueChangeUsecase: getItInstance(),
      confirmCashinUsecase: getItInstance(),
      checkWithdrawalUsecase: getItInstance(),
      confirmWithdrawalUsecase: getItInstance(),
      getTellerFloatBalanceUsecase: getItInstance(),
      getTellerRecentTransactionsUsecase: getItInstance(),
    ),
  );
  getItInstance.registerFactory<TransactionBloc>(
    () => TransactionBloc(
      getCashinsUsecase: getItInstance(),
      getCashoutsUsecase: getItInstance(),
      getPaymentsUsecase: getItInstance(),
      getIssueChangesUsecase: getItInstance(),
      getWithdrawalsUsecase: getItInstance(),
    ),
  );
}
