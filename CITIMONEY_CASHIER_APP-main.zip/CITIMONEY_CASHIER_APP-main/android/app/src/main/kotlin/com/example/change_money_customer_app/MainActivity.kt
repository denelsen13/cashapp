package com.example.change_money_customer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
